"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [7050], {
        1160: function(e, n, r) {
            r.d(n, {
                E6: function() {
                    return d
                },
                nw: function() {
                    return S
                },
                GP: function() {
                    return m
                }
            });
            r(83300);
            var t = r(32046),
                i = r(16441),
                o = r(9279),
                u = r(67827);
            var s, c;
            ! function(e) {
                e.SELL = "sell", e.BUY = "buy"
            }(s || (s = {})),
            function(e) {
                e.ERC20 = "erc20", e.EXTERNAL = "external", e.INTERNAL = "internal"
            }(c || (c = {}));
            const f = [{
                name: "sellToken",
                type: "address"
            }, {
                name: "buyToken",
                type: "address"
            }, {
                name: "receiver",
                type: "address"
            }, {
                name: "sellAmount",
                type: "uint256"
            }, {
                name: "buyAmount",
                type: "uint256"
            }, {
                name: "validTo",
                type: "uint32"
            }, {
                name: "appData",
                type: "bytes32"
            }, {
                name: "feeAmount",
                type: "uint256"
            }, {
                name: "kind",
                type: "string"
            }, {
                name: "partiallyFillable",
                type: "bool"
            }, {
                name: "sellTokenBalance",
                type: "string"
            }, {
                name: "buyTokenBalance",
                type: "string"
            }];
            t.id(`Order(${f.map((({name:e,type:n})=>`
                $ {
                    n
                }
                $ {
                    e
                }
                `)).join(",")})`);

            function l(e) {
                return "number" === typeof e ? e : ~~(e.getTime() / 1e3)
            }

            function a(e) {
                switch (e) {
                    case void 0:
                    case c.ERC20:
                    case c.EXTERNAL:
                        return c.ERC20;
                    case c.INTERNAL:
                        return c.INTERNAL;
                    default:
                        throw new Error(`invalid order balance ${e}`)
                }
            }

            function h(e) {
                var n, r;
                if (e.receiver === o.d) throw new Error("receiver cannot be address(0)");
                var t;
                return Object.assign(Object.assign({}, e), {
                    sellTokenBalance: null !== (n = e.sellTokenBalance) && void 0 !== n ? n : c.ERC20,
                    receiver: null !== (r = e.receiver) && void 0 !== r ? r : o.d,
                    validTo: l(e.validTo),
                    appData: (t = e.appData, "number" === typeof t ? `0x${t.toString(16).padStart(64,"0")}` : i.hexZeroPad(t, 32)),
                    buyTokenBalance: a(e.buyTokenBalance)
                })
            }

            function p(e, n, r) {
                return u.E.hash(e, n, r)
            }
            var g = function(e, n, r, t) {
                return new(r || (r = Promise))((function(i, o) {
                    function u(e) {
                        try {
                            c(t.next(e))
                        } catch (n) {
                            o(n)
                        }
                    }

                    function s(e) {
                        try {
                            c(t.throw(e))
                        } catch (n) {
                            o(n)
                        }
                    }

                    function c(e) {
                        var n;
                        e.done ? i(e.value) : (n = e.value, n instanceof r ? n : new r((function(e) {
                            e(n)
                        }))).then(u, s)
                    }
                    c((t = t.apply(e, n || [])).next())
                }))
            };
            i.hexDataSlice(t.id("isValidSignature(bytes32,bytes)"), 0, 4), t.id("GPv2Signing.Scheme.PreSign");
            var d;

            function w(e, n, r, t, o) {
                return g(this, void 0, void 0, (function*() {
                    let u = null;
                    switch (e) {
                        case d.EIP712:
                            if (!("_signTypedData" in n)) throw new Error("signer does not support signing typed data");
                            u = yield n._signTypedData(r, t, o);
                            break;
                        case d.ETHSIGN:
                            u = yield n.signMessage(i.arrayify(p(r, t, o)));
                            break;
                        default:
                            throw new Error("invalid signing scheme")
                    }
                    return i.joinSignature(i.splitSignature(u))
                }))
            }

            function m(e, n, r, t) {
                return g(this, void 0, void 0, (function*() {
                    return {
                        scheme: t,
                        data: yield w(t, r, e, {
                            Order: f
                        }, h(n))
                    }
                }))
            }! function(e) {
                e[e.EIP712 = 0] = "EIP712", e[e.ETHSIGN = 1] = "ETHSIGN", e[e.EIP1271 = 2] = "EIP1271", e[e.PRESIGN = 3] = "PRESIGN"
            }(d || (d = {}));
            var v;
            ! function(e) {
                e[e.PRE = 0] = "PRE", e[e.INTRA = 1] = "INTRA", e[e.POST = 2] = "POST"
            }(v || (v = {}));
            s.SELL, s.BUY, c.ERC20, c.EXTERNAL, c.INTERNAL, c.ERC20, c.INTERNAL, d.EIP712, d.ETHSIGN, d.EIP1271, d.PRESIGN;
            var y, E;
            ! function(e) {
                e[e.Dev = 0] = "Dev", e[e.Prod = 1] = "Prod"
            }(y || (y = {})),
            function(e) {
                e.SellAmountDoesNotCoverFee = "SellAmountDoesNotCoverFee"
            }(E || (E = {}));
            r(86237).s("Mattresses in Berlin!");
            var b = r(84243),
                N = r(2593);

            function O(e) {
                return b.$.encode(["bytes32"], [N.O$.from(t.id(e)).sub(1)])
            }
            O("eip1967.proxy.implementation"), O("eip1967.proxy.admin");
            var A = r(8198);
            new A.vU(["function manageUserBalance((uint8, address, uint256, address, address)[])", "function batchSwap(uint8, (bytes32, uint256, uint256, uint256, bytes)[], address[], (address, bool, address, bool), int256[], uint256)"]);

            function S(e, n) {
                return {
                    name: "Gnosis Protocol",
                    version: "v2",
                    chainId: e,
                    verifyingContract: n
                }
            }
        },
        83300: function(e, n, r) {
            var t = function() {
                if ("undefined" !== typeof self) return self;
                if ("undefined" !== typeof window) return window;
                if ("undefined" !== typeof r.g) return r.g;
                throw new Error("unable to locate global object")
            }();
            e.exports = n = t.fetch, t.fetch && (n.default = t.fetch.bind(r.g)), n.Headers = t.Headers, n.Request = t.Request, n.Response = t.Response
        },
        47568: function(e, n, r) {
            function t(e, n, r, t, i, o, u) {
                try {
                    var s = e[o](u),
                        c = s.value
                } catch (f) {
                    return void r(f)
                }
                s.done ? n(c) : Promise.resolve(c).then(t, i)
            }

            function i(e) {
                return function() {
                    var n = this,
                        r = arguments;
                    return new Promise((function(i, o) {
                        var u = e.apply(n, r);

                        function s(e) {
                            t(u, i, o, s, c, "next", e)
                        }

                        function c(e) {
                            t(u, i, o, s, c, "throw", e)
                        }
                        s(void 0)
                    }))
                }
            }
            r.d(n, {
                Z: function() {
                    return i
                }
            })
        },
        70794: function(e, n, r) {
            var t = /^-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i,
                i = Math.ceil,
                o = Math.floor,
                u = "[BigNumber Error] ",
                s = u + "Number primitive has more than 15 significant digits: ",
                c = 1e14,
                f = 14,
                l = 9007199254740991,
                a = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 1e9, 1e10, 1e11, 1e12, 1e13],
                h = 1e7,
                p = 1e9;

            function g(e) {
                var n = 0 | e;
                return e > 0 || e === n ? n : n - 1
            }

            function d(e) {
                for (var n, r, t = 1, i = e.length, o = e[0] + ""; t < i;) {
                    for (n = e[t++] + "", r = f - n.length; r--; n = "0" + n);
                    o += n
                }
                for (i = o.length; 48 === o.charCodeAt(--i););
                return o.slice(0, i + 1 || 1)
            }

            function w(e, n) {
                var r, t, i = e.c,
                    o = n.c,
                    u = e.s,
                    s = n.s,
                    c = e.e,
                    f = n.e;
                if (!u || !s) return null;
                if (r = i && !i[0], t = o && !o[0], r || t) return r ? t ? 0 : -s : u;
                if (u != s) return u;
                if (r = u < 0, t = c == f, !i || !o) return t ? 0 : !i ^ r ? 1 : -1;
                if (!t) return c > f ^ r ? 1 : -1;
                for (s = (c = i.length) < (f = o.length) ? c : f, u = 0; u < s; u++)
                    if (i[u] != o[u]) return i[u] > o[u] ^ r ? 1 : -1;
                return c == f ? 0 : c > f ^ r ? 1 : -1
            }

            function m(e, n, r, t) {
                if (e < n || e > r || e !== o(e)) throw Error(u + (t || "Argument") + ("number" == typeof e ? e < n || e > r ? " out of range: " : " not an integer: " : " not a primitive number: ") + String(e))
            }

            function v(e) {
                var n = e.c.length - 1;
                return g(e.e / f) == n && e.c[n] % 2 != 0
            }

            function y(e, n) {
                return (e.length > 1 ? e.charAt(0) + "." + e.slice(1) : e) + (n < 0 ? "e" : "e+") + n
            }

            function E(e, n, r) {
                var t, i;
                if (n < 0) {
                    for (i = r + "."; ++n; i += r);
                    e = i + e
                } else if (++n > (t = e.length)) {
                    for (i = r, n -= t; --n; i += r);
                    e += i
                } else n < t && (e = e.slice(0, n) + "." + e.slice(n));
                return e
            }
            var b = function e(n) {
                var r, b, N, O = U.prototype = {
                        constructor: U,
                        toString: null,
                        valueOf: null
                    },
                    A = new U(1),
                    S = 20,
                    T = 4,
                    R = -7,
                    P = 21,
                    I = -1e7,
                    L = 1e7,
                    D = !1,
                    B = 1,
                    x = 0,
                    _ = {
                        prefix: "",
                        groupSize: 3,
                        secondaryGroupSize: 0,
                        groupSeparator: ",",
                        decimalSeparator: ".",
                        fractionGroupSize: 0,
                        fractionGroupSeparator: "\xa0",
                        suffix: ""
                    },
                    C = "0123456789abcdefghijklmnopqrstuvwxyz",
                    k = !0;

                function U(e, n) {
                    var r, i, u, c, a, h, p, g, d = this;
                    if (!(d instanceof U)) return new U(e, n);
                    if (null == n) {
                        if (e && !0 === e._isBigNumber) return d.s = e.s, void(!e.c || e.e > L ? d.c = d.e = null : e.e < I ? d.c = [d.e = 0] : (d.e = e.e, d.c = e.c.slice()));
                        if ((h = "number" == typeof e) && 0 * e == 0) {
                            if (d.s = 1 / e < 0 ? (e = -e, -1) : 1, e === ~~e) {
                                for (c = 0, a = e; a >= 10; a /= 10, c++);
                                return void(c > L ? d.c = d.e = null : (d.e = c, d.c = [e]))
                            }
                            g = String(e)
                        } else {
                            if (!t.test(g = String(e))) return N(d, g, h);
                            d.s = 45 == g.charCodeAt(0) ? (g = g.slice(1), -1) : 1
                        }(c = g.indexOf(".")) > -1 && (g = g.replace(".", "")), (a = g.search(/e/i)) > 0 ? (c < 0 && (c = a), c += +g.slice(a + 1), g = g.substring(0, a)) : c < 0 && (c = g.length)
                    } else {
                        if (m(n, 2, C.length, "Base"), 10 == n && k) return $(d = new U(e), S + d.e + 1, T);
                        if (g = String(e), h = "number" == typeof e) {
                            if (0 * e != 0) return N(d, g, h, n);
                            if (d.s = 1 / e < 0 ? (g = g.slice(1), -1) : 1, U.DEBUG && g.replace(/^0\.0*|\./, "").length > 15) throw Error(s + e)
                        } else d.s = 45 === g.charCodeAt(0) ? (g = g.slice(1), -1) : 1;
                        for (r = C.slice(0, n), c = a = 0, p = g.length; a < p; a++)
                            if (r.indexOf(i = g.charAt(a)) < 0) {
                                if ("." == i) {
                                    if (a > c) {
                                        c = p;
                                        continue
                                    }
                                } else if (!u && (g == g.toUpperCase() && (g = g.toLowerCase()) || g == g.toLowerCase() && (g = g.toUpperCase()))) {
                                    u = !0, a = -1, c = 0;
                                    continue
                                }
                                return N(d, String(e), h, n)
                            }
                        h = !1, (c = (g = b(g, n, 10, d.s)).indexOf(".")) > -1 ? g = g.replace(".", "") : c = g.length
                    }
                    for (a = 0; 48 === g.charCodeAt(a); a++);
                    for (p = g.length; 48 === g.charCodeAt(--p););
                    if (g = g.slice(a, ++p)) {
                        if (p -= a, h && U.DEBUG && p > 15 && (e > l || e !== o(e))) throw Error(s + d.s * e);
                        if ((c = c - a - 1) > L) d.c = d.e = null;
                        else if (c < I) d.c = [d.e = 0];
                        else {
                            if (d.e = c, d.c = [], a = (c + 1) % f, c < 0 && (a += f), a < p) {
                                for (a && d.c.push(+g.slice(0, a)), p -= f; a < p;) d.c.push(+g.slice(a, a += f));
                                a = f - (g = g.slice(a)).length
                            } else a -= p;
                            for (; a--; g += "0");
                            d.c.push(+g)
                        }
                    } else d.c = [d.e = 0]
                }

                function G(e, n, r, t) {
                    var i, o, u, s, c;
                    if (null == r ? r = T : m(r, 0, 8), !e.c) return e.toString();
                    if (i = e.c[0], u = e.e, null == n) c = d(e.c), c = 1 == t || 2 == t && (u <= R || u >= P) ? y(c, u) : E(c, u, "0");
                    else if (o = (e = $(new U(e), n, r)).e, s = (c = d(e.c)).length, 1 == t || 2 == t && (n <= o || o <= R)) {
                        for (; s < n; c += "0", s++);
                        c = y(c, o)
                    } else if (n -= u, c = E(c, o, "0"), o + 1 > s) {
                        if (--n > 0)
                            for (c += "."; n--; c += "0");
                    } else if ((n += o - s) > 0)
                        for (o + 1 == s && (c += "."); n--; c += "0");
                    return e.s < 0 && i ? "-" + c : c
                }

                function M(e, n) {
                    for (var r, t = 1, i = new U(e[0]); t < e.length; t++) {
                        if (!(r = new U(e[t])).s) {
                            i = r;
                            break
                        }
                        n.call(i, r) && (i = r)
                    }
                    return i
                }

                function F(e, n, r) {
                    for (var t = 1, i = n.length; !n[--i]; n.pop());
                    for (i = n[0]; i >= 10; i /= 10, t++);
                    return (r = t + r * f - 1) > L ? e.c = e.e = null : r < I ? e.c = [e.e = 0] : (e.e = r, e.c = n), e
                }

                function $(e, n, r, t) {
                    var u, s, l, h, p, g, d, w = e.c,
                        m = a;
                    if (w) {
                        e: {
                            for (u = 1, h = w[0]; h >= 10; h /= 10, u++);
                            if ((s = n - u) < 0) s += f,
                            l = n,
                            d = (p = w[g = 0]) / m[u - l - 1] % 10 | 0;
                            else if ((g = i((s + 1) / f)) >= w.length) {
                                if (!t) break e;
                                for (; w.length <= g; w.push(0));
                                p = d = 0, u = 1, l = (s %= f) - f + 1
                            } else {
                                for (p = h = w[g], u = 1; h >= 10; h /= 10, u++);
                                d = (l = (s %= f) - f + u) < 0 ? 0 : p / m[u - l - 1] % 10 | 0
                            }
                            if (t = t || n < 0 || null != w[g + 1] || (l < 0 ? p : p % m[u - l - 1]), t = r < 4 ? (d || t) && (0 == r || r == (e.s < 0 ? 3 : 2)) : d > 5 || 5 == d && (4 == r || t || 6 == r && (s > 0 ? l > 0 ? p / m[u - l] : 0 : w[g - 1]) % 10 & 1 || r == (e.s < 0 ? 8 : 7)), n < 1 || !w[0]) return w.length = 0, t ? (n -= e.e + 1, w[0] = m[(f - n % f) % f], e.e = -n || 0) : w[0] = e.e = 0, e;
                            if (0 == s ? (w.length = g, h = 1, g--) : (w.length = g + 1, h = m[f - s], w[g] = l > 0 ? o(p / m[u - l] % m[l]) * h : 0), t)
                                for (;;) {
                                    if (0 == g) {
                                        for (s = 1, l = w[0]; l >= 10; l /= 10, s++);
                                        for (l = w[0] += h, h = 1; l >= 10; l /= 10, h++);
                                        s != h && (e.e++, w[0] == c && (w[0] = 1));
                                        break
                                    }
                                    if (w[g] += h, w[g] != c) break;
                                    w[g--] = 0, h = 1
                                }
                            for (s = w.length; 0 === w[--s]; w.pop());
                        }
                        e.e > L ? e.c = e.e = null : e.e < I && (e.c = [e.e = 0])
                    }
                    return e
                }

                function j(e) {
                    var n, r = e.e;
                    return null === r ? e.toString() : (n = d(e.c), n = r <= R || r >= P ? y(n, r) : E(n, r, "0"), e.s < 0 ? "-" + n : n)
                }
                return U.clone = e, U.ROUND_UP = 0, U.ROUND_DOWN = 1, U.ROUND_CEIL = 2, U.ROUND_FLOOR = 3, U.ROUND_HALF_UP = 4, U.ROUND_HALF_DOWN = 5, U.ROUND_HALF_EVEN = 6, U.ROUND_HALF_CEIL = 7, U.ROUND_HALF_FLOOR = 8, U.EUCLID = 9, U.config = U.set = function(e) {
                    var n, r;
                    if (null != e) {
                        if ("object" != typeof e) throw Error(u + "Object expected: " + e);
                        if (e.hasOwnProperty(n = "DECIMAL_PLACES") && (m(r = e[n], 0, p, n), S = r), e.hasOwnProperty(n = "ROUNDING_MODE") && (m(r = e[n], 0, 8, n), T = r), e.hasOwnProperty(n = "EXPONENTIAL_AT") && ((r = e[n]) && r.pop ? (m(r[0], -p, 0, n), m(r[1], 0, p, n), R = r[0], P = r[1]) : (m(r, -p, p, n), R = -(P = r < 0 ? -r : r))), e.hasOwnProperty(n = "RANGE"))
                            if ((r = e[n]) && r.pop) m(r[0], -p, -1, n), m(r[1], 1, p, n), I = r[0], L = r[1];
                            else {
                                if (m(r, -p, p, n), !r) throw Error(u + n + " cannot be zero: " + r);
                                I = -(L = r < 0 ? -r : r)
                            }
                        if (e.hasOwnProperty(n = "CRYPTO")) {
                            if ((r = e[n]) !== !!r) throw Error(u + n + " not true or false: " + r);
                            if (r) {
                                if ("undefined" == typeof crypto || !crypto || !crypto.getRandomValues && !crypto.randomBytes) throw D = !r, Error(u + "crypto unavailable");
                                D = r
                            } else D = r
                        }
                        if (e.hasOwnProperty(n = "MODULO_MODE") && (m(r = e[n], 0, 9, n), B = r), e.hasOwnProperty(n = "POW_PRECISION") && (m(r = e[n], 0, p, n), x = r), e.hasOwnProperty(n = "FORMAT")) {
                            if ("object" != typeof(r = e[n])) throw Error(u + n + " not an object: " + r);
                            _ = r
                        }
                        if (e.hasOwnProperty(n = "ALPHABET")) {
                            if ("string" != typeof(r = e[n]) || /^.?$|[+\-.\s]|(.).*\1/.test(r)) throw Error(u + n + " invalid: " + r);
                            k = "0123456789" == r.slice(0, 10), C = r
                        }
                    }
                    return {
                        DECIMAL_PLACES: S,
                        ROUNDING_MODE: T,
                        EXPONENTIAL_AT: [R, P],
                        RANGE: [I, L],
                        CRYPTO: D,
                        MODULO_MODE: B,
                        POW_PRECISION: x,
                        FORMAT: _,
                        ALPHABET: C
                    }
                }, U.isBigNumber = function(e) {
                    if (!e || !0 !== e._isBigNumber) return !1;
                    if (!U.DEBUG) return !0;
                    var n, r, t = e.c,
                        i = e.e,
                        s = e.s;
                    e: if ("[object Array]" == {}.toString.call(t)) {
                        if ((1 === s || -1 === s) && i >= -p && i <= p && i === o(i)) {
                            if (0 === t[0]) {
                                if (0 === i && 1 === t.length) return !0;
                                break e
                            }
                            if ((n = (i + 1) % f) < 1 && (n += f), String(t[0]).length == n) {
                                for (n = 0; n < t.length; n++)
                                    if ((r = t[n]) < 0 || r >= c || r !== o(r)) break e;
                                if (0 !== r) return !0
                            }
                        }
                    } else
                    if (null === t && null === i && (null === s || 1 === s || -1 === s)) return !0;
                    throw Error(u + "Invalid BigNumber: " + e)
                }, U.maximum = U.max = function() {
                    return M(arguments, O.lt)
                }, U.minimum = U.min = function() {
                    return M(arguments, O.gt)
                }, U.random = function() {
                    var e = 9007199254740992,
                        n = Math.random() * e & 2097151 ? function() {
                            return o(Math.random() * e)
                        } : function() {
                            return 8388608 * (1073741824 * Math.random() | 0) + (8388608 * Math.random() | 0)
                        };
                    return function(e) {
                        var r, t, s, c, l, h = 0,
                            g = [],
                            d = new U(A);
                        if (null == e ? e = S : m(e, 0, p), c = i(e / f), D)
                            if (crypto.getRandomValues) {
                                for (r = crypto.getRandomValues(new Uint32Array(c *= 2)); h < c;)(l = 131072 * r[h] + (r[h + 1] >>> 11)) >= 9e15 ? (t = crypto.getRandomValues(new Uint32Array(2)), r[h] = t[0], r[h + 1] = t[1]) : (g.push(l % 1e14), h += 2);
                                h = c / 2
                            } else {
                                if (!crypto.randomBytes) throw D = !1, Error(u + "crypto unavailable");
                                for (r = crypto.randomBytes(c *= 7); h < c;)(l = 281474976710656 * (31 & r[h]) + 1099511627776 * r[h + 1] + 4294967296 * r[h + 2] + 16777216 * r[h + 3] + (r[h + 4] << 16) + (r[h + 5] << 8) + r[h + 6]) >= 9e15 ? crypto.randomBytes(7).copy(r, h) : (g.push(l % 1e14), h += 7);
                                h = c / 7
                            }
                        if (!D)
                            for (; h < c;)(l = n()) < 9e15 && (g[h++] = l % 1e14);
                        for (c = g[--h], e %= f, c && e && (l = a[f - e], g[h] = o(c / l) * l); 0 === g[h]; g.pop(), h--);
                        if (h < 0) g = [s = 0];
                        else {
                            for (s = -1; 0 === g[0]; g.splice(0, 1), s -= f);
                            for (h = 1, l = g[0]; l >= 10; l /= 10, h++);
                            h < f && (s -= f - h)
                        }
                        return d.e = s, d.c = g, d
                    }
                }(), U.sum = function() {
                    for (var e = 1, n = arguments, r = new U(n[0]); e < n.length;) r = r.plus(n[e++]);
                    return r
                }, b = function() {
                    var e = "0123456789";

                    function n(e, n, r, t) {
                        for (var i, o, u = [0], s = 0, c = e.length; s < c;) {
                            for (o = u.length; o--; u[o] *= n);
                            for (u[0] += t.indexOf(e.charAt(s++)), i = 0; i < u.length; i++) u[i] > r - 1 && (null == u[i + 1] && (u[i + 1] = 0), u[i + 1] += u[i] / r | 0, u[i] %= r)
                        }
                        return u.reverse()
                    }
                    return function(t, i, o, u, s) {
                        var c, f, l, a, h, p, g, w, m = t.indexOf("."),
                            v = S,
                            y = T;
                        for (m >= 0 && (a = x, x = 0, t = t.replace(".", ""), p = (w = new U(i)).pow(t.length - m), x = a, w.c = n(E(d(p.c), p.e, "0"), 10, o, e), w.e = w.c.length), l = a = (g = n(t, i, o, s ? (c = C, e) : (c = e, C))).length; 0 == g[--a]; g.pop());
                        if (!g[0]) return c.charAt(0);
                        if (m < 0 ? --l : (p.c = g, p.e = l, p.s = u, g = (p = r(p, w, v, y, o)).c, h = p.r, l = p.e), m = g[f = l + v + 1], a = o / 2, h = h || f < 0 || null != g[f + 1], h = y < 4 ? (null != m || h) && (0 == y || y == (p.s < 0 ? 3 : 2)) : m > a || m == a && (4 == y || h || 6 == y && 1 & g[f - 1] || y == (p.s < 0 ? 8 : 7)), f < 1 || !g[0]) t = h ? E(c.charAt(1), -v, c.charAt(0)) : c.charAt(0);
                        else {
                            if (g.length = f, h)
                                for (--o; ++g[--f] > o;) g[f] = 0, f || (++l, g = [1].concat(g));
                            for (a = g.length; !g[--a];);
                            for (m = 0, t = ""; m <= a; t += c.charAt(g[m++]));
                            t = E(t, l, c.charAt(0))
                        }
                        return t
                    }
                }(), r = function() {
                    function e(e, n, r) {
                        var t, i, o, u, s = 0,
                            c = e.length,
                            f = n % h,
                            l = n / h | 0;
                        for (e = e.slice(); c--;) s = ((i = f * (o = e[c] % h) + (t = l * o + (u = e[c] / h | 0) * f) % h * h + s) / r | 0) + (t / h | 0) + l * u, e[c] = i % r;
                        return s && (e = [s].concat(e)), e
                    }

                    function n(e, n, r, t) {
                        var i, o;
                        if (r != t) o = r > t ? 1 : -1;
                        else
                            for (i = o = 0; i < r; i++)
                                if (e[i] != n[i]) {
                                    o = e[i] > n[i] ? 1 : -1;
                                    break
                                } return o
                    }

                    function r(e, n, r, t) {
                        for (var i = 0; r--;) e[r] -= i, i = e[r] < n[r] ? 1 : 0, e[r] = i * t + e[r] - n[r];
                        for (; !e[0] && e.length > 1; e.splice(0, 1));
                    }
                    return function(t, i, u, s, l) {
                        var a, h, p, d, w, m, v, y, E, b, N, O, A, S, T, R, P, I = t.s == i.s ? 1 : -1,
                            L = t.c,
                            D = i.c;
                        if (!L || !L[0] || !D || !D[0]) return new U(t.s && i.s && (L ? !D || L[0] != D[0] : D) ? L && 0 == L[0] || !D ? 0 * I : I / 0 : NaN);
                        for (E = (y = new U(I)).c = [], I = u + (h = t.e - i.e) + 1, l || (l = c, h = g(t.e / f) - g(i.e / f), I = I / f | 0), p = 0; D[p] == (L[p] || 0); p++);
                        if (D[p] > (L[p] || 0) && h--, I < 0) E.push(1), d = !0;
                        else {
                            for (S = L.length, R = D.length, p = 0, I += 2, (w = o(l / (D[0] + 1))) > 1 && (D = e(D, w, l), L = e(L, w, l), R = D.length, S = L.length), A = R, N = (b = L.slice(0, R)).length; N < R; b[N++] = 0);
                            P = D.slice(), P = [0].concat(P), T = D[0], D[1] >= l / 2 && T++;
                            do {
                                if (w = 0, (a = n(D, b, R, N)) < 0) {
                                    if (O = b[0], R != N && (O = O * l + (b[1] || 0)), (w = o(O / T)) > 1)
                                        for (w >= l && (w = l - 1), v = (m = e(D, w, l)).length, N = b.length; 1 == n(m, b, v, N);) w--, r(m, R < v ? P : D, v, l), v = m.length, a = 1;
                                    else 0 == w && (a = w = 1), v = (m = D.slice()).length;
                                    if (v < N && (m = [0].concat(m)), r(b, m, N, l), N = b.length, -1 == a)
                                        for (; n(D, b, R, N) < 1;) w++, r(b, R < N ? P : D, N, l), N = b.length
                                } else 0 === a && (w++, b = [0]);
                                E[p++] = w, b[0] ? b[N++] = L[A] || 0 : (b = [L[A]], N = 1)
                            } while ((A++ < S || null != b[0]) && I--);
                            d = null != b[0], E[0] || E.splice(0, 1)
                        }
                        if (l == c) {
                            for (p = 1, I = E[0]; I >= 10; I /= 10, p++);
                            $(y, u + (y.e = p + h * f - 1) + 1, s, d)
                        } else y.e = h, y.r = +d;
                        return y
                    }
                }(), N = function() {
                    var e = /^(-?)0([xbo])(?=\w[\w.]*$)/i,
                        n = /^([^.]+)\.$/,
                        r = /^\.([^.]+)$/,
                        t = /^-?(Infinity|NaN)$/,
                        i = /^\s*\+(?=[\w.])|^\s+|\s+$/g;
                    return function(o, s, c, f) {
                        var l, a = c ? s : s.replace(i, "");
                        if (t.test(a)) o.s = isNaN(a) ? null : a < 0 ? -1 : 1;
                        else {
                            if (!c && (a = a.replace(e, (function(e, n, r) {
                                    return l = "x" == (r = r.toLowerCase()) ? 16 : "b" == r ? 2 : 8, f && f != l ? e : n
                                })), f && (l = f, a = a.replace(n, "$1").replace(r, "0.$1")), s != a)) return new U(a, l);
                            if (U.DEBUG) throw Error(u + "Not a" + (f ? " base " + f : "") + " number: " + s);
                            o.s = null
                        }
                        o.c = o.e = null
                    }
                }(), O.absoluteValue = O.abs = function() {
                    var e = new U(this);
                    return e.s < 0 && (e.s = 1), e
                }, O.comparedTo = function(e, n) {
                    return w(this, new U(e, n))
                }, O.decimalPlaces = O.dp = function(e, n) {
                    var r, t, i, o = this;
                    if (null != e) return m(e, 0, p), null == n ? n = T : m(n, 0, 8), $(new U(o), e + o.e + 1, n);
                    if (!(r = o.c)) return null;
                    if (t = ((i = r.length - 1) - g(this.e / f)) * f, i = r[i])
                        for (; i % 10 == 0; i /= 10, t--);
                    return t < 0 && (t = 0), t
                }, O.dividedBy = O.div = function(e, n) {
                    return r(this, new U(e, n), S, T)
                }, O.dividedToIntegerBy = O.idiv = function(e, n) {
                    return r(this, new U(e, n), 0, 1)
                }, O.exponentiatedBy = O.pow = function(e, n) {
                    var r, t, s, c, l, a, h, p, g = this;
                    if ((e = new U(e)).c && !e.isInteger()) throw Error(u + "Exponent not an integer: " + j(e));
                    if (null != n && (n = new U(n)), l = e.e > 14, !g.c || !g.c[0] || 1 == g.c[0] && !g.e && 1 == g.c.length || !e.c || !e.c[0]) return p = new U(Math.pow(+j(g), l ? 2 - v(e) : +j(e))), n ? p.mod(n) : p;
                    if (a = e.s < 0, n) {
                        if (n.c ? !n.c[0] : !n.s) return new U(NaN);
                        (t = !a && g.isInteger() && n.isInteger()) && (g = g.mod(n))
                    } else {
                        if (e.e > 9 && (g.e > 0 || g.e < -1 || (0 == g.e ? g.c[0] > 1 || l && g.c[1] >= 24e7 : g.c[0] < 8e13 || l && g.c[0] <= 9999975e7))) return c = g.s < 0 && v(e) ? -0 : 0, g.e > -1 && (c = 1 / c), new U(a ? 1 / c : c);
                        x && (c = i(x / f + 2))
                    }
                    for (l ? (r = new U(.5), a && (e.s = 1), h = v(e)) : h = (s = Math.abs(+j(e))) % 2, p = new U(A);;) {
                        if (h) {
                            if (!(p = p.times(g)).c) break;
                            c ? p.c.length > c && (p.c.length = c) : t && (p = p.mod(n))
                        }
                        if (s) {
                            if (0 === (s = o(s / 2))) break;
                            h = s % 2
                        } else if ($(e = e.times(r), e.e + 1, 1), e.e > 14) h = v(e);
                        else {
                            if (0 === (s = +j(e))) break;
                            h = s % 2
                        }
                        g = g.times(g), c ? g.c && g.c.length > c && (g.c.length = c) : t && (g = g.mod(n))
                    }
                    return t ? p : (a && (p = A.div(p)), n ? p.mod(n) : c ? $(p, x, T, undefined) : p)
                }, O.integerValue = function(e) {
                    var n = new U(this);
                    return null == e ? e = T : m(e, 0, 8), $(n, n.e + 1, e)
                }, O.isEqualTo = O.eq = function(e, n) {
                    return 0 === w(this, new U(e, n))
                }, O.isFinite = function() {
                    return !!this.c
                }, O.isGreaterThan = O.gt = function(e, n) {
                    return w(this, new U(e, n)) > 0
                }, O.isGreaterThanOrEqualTo = O.gte = function(e, n) {
                    return 1 === (n = w(this, new U(e, n))) || 0 === n
                }, O.isInteger = function() {
                    return !!this.c && g(this.e / f) > this.c.length - 2
                }, O.isLessThan = O.lt = function(e, n) {
                    return w(this, new U(e, n)) < 0
                }, O.isLessThanOrEqualTo = O.lte = function(e, n) {
                    return -1 === (n = w(this, new U(e, n))) || 0 === n
                }, O.isNaN = function() {
                    return !this.s
                }, O.isNegative = function() {
                    return this.s < 0
                }, O.isPositive = function() {
                    return this.s > 0
                }, O.isZero = function() {
                    return !!this.c && 0 == this.c[0]
                }, O.minus = function(e, n) {
                    var r, t, i, o, u = this,
                        s = u.s;
                    if (n = (e = new U(e, n)).s, !s || !n) return new U(NaN);
                    if (s != n) return e.s = -n, u.plus(e);
                    var l = u.e / f,
                        a = e.e / f,
                        h = u.c,
                        p = e.c;
                    if (!l || !a) {
                        if (!h || !p) return h ? (e.s = -n, e) : new U(p ? u : NaN);
                        if (!h[0] || !p[0]) return p[0] ? (e.s = -n, e) : new U(h[0] ? u : 3 == T ? -0 : 0)
                    }
                    if (l = g(l), a = g(a), h = h.slice(), s = l - a) {
                        for ((o = s < 0) ? (s = -s, i = h) : (a = l, i = p), i.reverse(), n = s; n--; i.push(0));
                        i.reverse()
                    } else
                        for (t = (o = (s = h.length) < (n = p.length)) ? s : n, s = n = 0; n < t; n++)
                            if (h[n] != p[n]) {
                                o = h[n] < p[n];
                                break
                            } if (o && (i = h, h = p, p = i, e.s = -e.s), (n = (t = p.length) - (r = h.length)) > 0)
                        for (; n--; h[r++] = 0);
                    for (n = c - 1; t > s;) {
                        if (h[--t] < p[t]) {
                            for (r = t; r && !h[--r]; h[r] = n);
                            --h[r], h[t] += c
                        }
                        h[t] -= p[t]
                    }
                    for (; 0 == h[0]; h.splice(0, 1), --a);
                    return h[0] ? F(e, h, a) : (e.s = 3 == T ? -1 : 1, e.c = [e.e = 0], e)
                }, O.modulo = O.mod = function(e, n) {
                    var t, i, o = this;
                    return e = new U(e, n), !o.c || !e.s || e.c && !e.c[0] ? new U(NaN) : !e.c || o.c && !o.c[0] ? new U(o) : (9 == B ? (i = e.s, e.s = 1, t = r(o, e, 0, 3), e.s = i, t.s *= i) : t = r(o, e, 0, B), (e = o.minus(t.times(e))).c[0] || 1 != B || (e.s = o.s), e)
                }, O.multipliedBy = O.times = function(e, n) {
                    var r, t, i, o, u, s, l, a, p, d, w, m, v, y, E, b = this,
                        N = b.c,
                        O = (e = new U(e, n)).c;
                    if (!N || !O || !N[0] || !O[0]) return !b.s || !e.s || N && !N[0] && !O || O && !O[0] && !N ? e.c = e.e = e.s = null : (e.s *= b.s, N && O ? (e.c = [0], e.e = 0) : e.c = e.e = null), e;
                    for (t = g(b.e / f) + g(e.e / f), e.s *= b.s, (l = N.length) < (d = O.length) && (v = N, N = O, O = v, i = l, l = d, d = i), i = l + d, v = []; i--; v.push(0));
                    for (y = c, E = h, i = d; --i >= 0;) {
                        for (r = 0, w = O[i] % E, m = O[i] / E | 0, o = i + (u = l); o > i;) r = ((a = w * (a = N[--u] % E) + (s = m * a + (p = N[u] / E | 0) * w) % E * E + v[o] + r) / y | 0) + (s / E | 0) + m * p, v[o--] = a % y;
                        v[o] = r
                    }
                    return r ? ++t : v.splice(0, 1), F(e, v, t)
                }, O.negated = function() {
                    var e = new U(this);
                    return e.s = -e.s || null, e
                }, O.plus = function(e, n) {
                    var r, t = this,
                        i = t.s;
                    if (n = (e = new U(e, n)).s, !i || !n) return new U(NaN);
                    if (i != n) return e.s = -n, t.minus(e);
                    var o = t.e / f,
                        u = e.e / f,
                        s = t.c,
                        l = e.c;
                    if (!o || !u) {
                        if (!s || !l) return new U(i / 0);
                        if (!s[0] || !l[0]) return l[0] ? e : new U(s[0] ? t : 0 * i)
                    }
                    if (o = g(o), u = g(u), s = s.slice(), i = o - u) {
                        for (i > 0 ? (u = o, r = l) : (i = -i, r = s), r.reverse(); i--; r.push(0));
                        r.reverse()
                    }
                    for ((i = s.length) - (n = l.length) < 0 && (r = l, l = s, s = r, n = i), i = 0; n;) i = (s[--n] = s[n] + l[n] + i) / c | 0, s[n] = c === s[n] ? 0 : s[n] % c;
                    return i && (s = [i].concat(s), ++u), F(e, s, u)
                }, O.precision = O.sd = function(e, n) {
                    var r, t, i, o = this;
                    if (null != e && e !== !!e) return m(e, 1, p), null == n ? n = T : m(n, 0, 8), $(new U(o), e, n);
                    if (!(r = o.c)) return null;
                    if (t = (i = r.length - 1) * f + 1, i = r[i]) {
                        for (; i % 10 == 0; i /= 10, t--);
                        for (i = r[0]; i >= 10; i /= 10, t++);
                    }
                    return e && o.e + 1 > t && (t = o.e + 1), t
                }, O.shiftedBy = function(e) {
                    return m(e, -9007199254740991, l), this.times("1e" + e)
                }, O.squareRoot = O.sqrt = function() {
                    var e, n, t, i, o, u = this,
                        s = u.c,
                        c = u.s,
                        f = u.e,
                        l = S + 4,
                        a = new U("0.5");
                    if (1 !== c || !s || !s[0]) return new U(!c || c < 0 && (!s || s[0]) ? NaN : s ? u : 1 / 0);
                    if (0 == (c = Math.sqrt(+j(u))) || c == 1 / 0 ? (((n = d(s)).length + f) % 2 == 0 && (n += "0"), c = Math.sqrt(+n), f = g((f + 1) / 2) - (f < 0 || f % 2), t = new U(n = c == 1 / 0 ? "5e" + f : (n = c.toExponential()).slice(0, n.indexOf("e") + 1) + f)) : t = new U(c + ""), t.c[0])
                        for ((c = (f = t.e) + l) < 3 && (c = 0);;)
                            if (o = t, t = a.times(o.plus(r(u, o, l, 1))), d(o.c).slice(0, c) === (n = d(t.c)).slice(0, c)) {
                                if (t.e < f && --c, "9999" != (n = n.slice(c - 3, c + 1)) && (i || "4999" != n)) {
                                    +n && (+n.slice(1) || "5" != n.charAt(0)) || ($(t, t.e + S + 2, 1), e = !t.times(t).eq(u));
                                    break
                                }
                                if (!i && ($(o, o.e + S + 2, 0), o.times(o).eq(u))) {
                                    t = o;
                                    break
                                }
                                l += 4, c += 4, i = 1
                            }
                    return $(t, t.e + S + 1, T, e)
                }, O.toExponential = function(e, n) {
                    return null != e && (m(e, 0, p), e++), G(this, e, n, 1)
                }, O.toFixed = function(e, n) {
                    return null != e && (m(e, 0, p), e = e + this.e + 1), G(this, e, n)
                }, O.toFormat = function(e, n, r) {
                    var t, i = this;
                    if (null == r) null != e && n && "object" == typeof n ? (r = n, n = null) : e && "object" == typeof e ? (r = e, e = n = null) : r = _;
                    else if ("object" != typeof r) throw Error(u + "Argument not an object: " + r);
                    if (t = i.toFixed(e, n), i.c) {
                        var o, s = t.split("."),
                            c = +r.groupSize,
                            f = +r.secondaryGroupSize,
                            l = r.groupSeparator || "",
                            a = s[0],
                            h = s[1],
                            p = i.s < 0,
                            g = p ? a.slice(1) : a,
                            d = g.length;
                        if (f && (o = c, c = f, f = o, d -= o), c > 0 && d > 0) {
                            for (o = d % c || c, a = g.substr(0, o); o < d; o += c) a += l + g.substr(o, c);
                            f > 0 && (a += l + g.slice(o)), p && (a = "-" + a)
                        }
                        t = h ? a + (r.decimalSeparator || "") + ((f = +r.fractionGroupSize) ? h.replace(new RegExp("\\d{" + f + "}\\B", "g"), "$&" + (r.fractionGroupSeparator || "")) : h) : a
                    }
                    return (r.prefix || "") + t + (r.suffix || "")
                }, O.toFraction = function(e) {
                    var n, t, i, o, s, c, l, h, p, g, w, m, v = this,
                        y = v.c;
                    if (null != e && (!(l = new U(e)).isInteger() && (l.c || 1 !== l.s) || l.lt(A))) throw Error(u + "Argument " + (l.isInteger() ? "out of range: " : "not an integer: ") + j(l));
                    if (!y) return new U(v);
                    for (n = new U(A), p = t = new U(A), i = h = new U(A), m = d(y), s = n.e = m.length - v.e - 1, n.c[0] = a[(c = s % f) < 0 ? f + c : c], e = !e || l.comparedTo(n) > 0 ? s > 0 ? n : p : l, c = L, L = 1 / 0, l = new U(m), h.c[0] = 0; g = r(l, n, 0, 1), 1 != (o = t.plus(g.times(i))).comparedTo(e);) t = i, i = o, p = h.plus(g.times(o = p)), h = o, n = l.minus(g.times(o = n)), l = o;
                    return o = r(e.minus(t), i, 0, 1), h = h.plus(o.times(p)), t = t.plus(o.times(i)), h.s = p.s = v.s, w = r(p, i, s *= 2, T).minus(v).abs().comparedTo(r(h, t, s, T).minus(v).abs()) < 1 ? [p, i] : [h, t], L = c, w
                }, O.toNumber = function() {
                    return +j(this)
                }, O.toPrecision = function(e, n) {
                    return null != e && m(e, 1, p), G(this, e, n, 2)
                }, O.toString = function(e) {
                    var n, r = this,
                        t = r.s,
                        i = r.e;
                    return null === i ? t ? (n = "Infinity", t < 0 && (n = "-" + n)) : n = "NaN" : (null == e ? n = i <= R || i >= P ? y(d(r.c), i) : E(d(r.c), i, "0") : 10 === e && k ? n = E(d((r = $(new U(r), S + i + 1, T)).c), r.e, "0") : (m(e, 2, C.length, "Base"), n = b(E(d(r.c), i, "0"), 10, e, t, !0)), t < 0 && r.c[0] && (n = "-" + n)), n
                }, O.valueOf = O.toJSON = function() {
                    return j(this)
                }, O._isBigNumber = !0, O[Symbol.toStringTag] = "BigNumber", O[Symbol.for("nodejs.util.inspect.custom")] = O.valueOf, null != n && U.set(n), U
            }();
            n.Z = b
        }
    }
]);