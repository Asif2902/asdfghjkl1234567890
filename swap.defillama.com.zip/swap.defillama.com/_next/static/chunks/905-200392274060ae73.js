"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [905], {
        93390: function(n, e, t) {
            t.d(e, {
                Z: function() {
                    return z
                }
            });
            var o = t(7297),
                i = t(85893),
                r = t(38652),
                a = t(186),
                s = t(28171),
                l = t(68527),
                c = t(97375),
                d = t(26723),
                u = t(61359),
                p = t(38793),
                f = t(47568),
                h = t(26042),
                x = t(69396),
                v = t(70655),
                m = t(62573),
                g = t(17e3),
                b = t(96486),
                w = t(47787),
                k = t(79591),
                j = function() {
                    var n = (0, f.Z)((function(n) {
                        var e, t, o, i, r, a, s, l, c, d, u, p, f;
                        return (0, v.__generator)(this, (function(v) {
                            switch (v.label) {
                                case 0:
                                    return e = n.userId, t = n.chain, o = n.tokensUrlMap, i = n.tokensSymbolsMap, t ? (r = (0, w.is)(t), a = i[t], s = o[t], [4, fetch("https://api.llama.fi/getSwapsHistory/?chain=".concat(r, "&userId=").concat(e)).then((function(n) {
                                        return n.json()
                                    }))]) : [2, []];
                                case 1:
                                    return l = v.sent(), c = (0, b.uniq)(l.map((function(n) {
                                        var e, t;
                                        return [null === (e = n.from) || void 0 === e ? void 0 : e.toLowerCase(), null === (t = n.to) || void 0 === t ? void 0 : t.toLowerCase()]
                                    })).flat()), d = [], c.forEach((function(n) {
                                        a[n] || d.push(n)
                                    })), u = null, d.length ? [4, (0, m.multiCall)({
                                        abi: "erc20:symbol",
                                        chain: r,
                                        calls: d.map((function(n) {
                                            return {
                                                target: n
                                            }
                                        }))
                                    })] : [3, 3];
                                case 2:
                                    p = v.sent(), f = p.output, u = Object.fromEntries(d.map((function(n, e) {
                                        var t;
                                        return [n, null === (t = f[e]) || void 0 === t ? void 0 : t.output]
                                    }))), v.label = 3;
                                case 3:
                                    return [2, l.map((function(n) {
                                        var e, t, o, i, r, l;
                                        return (0, x.Z)((0, h.Z)({}, n), {
                                            fromIcon: s[null === n || void 0 === n || null === (e = n.from) || void 0 === e ? void 0 : e.toLowerCase()] || "/placeholder.png",
                                            toIcon: s[null === n || void 0 === n || null === (t = n.to) || void 0 === t ? void 0 : t.toLowerCase()] || "/placeholder.png",
                                            fromSymbol: a[null === n || void 0 === n || null === (o = n.from) || void 0 === o ? void 0 : o.toLowerCase()] || (null === u || void 0 === u ? void 0 : u[null === n || void 0 === n || null === (i = n.from) || void 0 === i ? void 0 : i.toLowerCase()]),
                                            toSymbol: a[null === n || void 0 === n || null === (r = n.to) || void 0 === r ? void 0 : r.toLowerCase()] || (null === u || void 0 === u ? void 0 : u[null === n || void 0 === n || null === (l = n.to) || void 0 === l ? void 0 : l.toLowerCase()])
                                        })
                                    }))]
                            }
                        }))
                    }));
                    return function(e) {
                        return n.apply(this, arguments)
                    }
                }();
            var y = t(40143);

            function C() {
                var n = (0, o.Z)(["\n\tdisplay: grid;\n\tgrid-row-gap: 4px;\n\tmargin-top: 16px;\n\theight: fit-content;\n\t&.is-selected {\n\t\tborder-color: rgb(31 114 229);\n\t\tbackground-color: rgb(3 11 23);\n\t}\n\n\tbackground-color: #2d3039;\n\tborder: 1px solid #373944;\n\tpadding: 7px 15px 9px;\n\tborder-radius: 8px;\n\tcursor: pointer;\n\n\tanimation: swing-in-left-fwd 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275) both;\n\t@keyframes swing-in-left-fwd {\n\t\t0% {\n\t\t\ttransform: rotateX(100deg);\n\t\t\ttransform-origin: left;\n\t\t\topacity: 0;\n\t\t}\n\t\t100% {\n\t\t\ttransform: rotateX(0);\n\t\t\ttransform-origin: left;\n\t\t\topacity: 1;\n\t\t}\n\t}\n\t.secondary-data {\n\t\topacity: 0;\n\t\ttransition: opacity 0.2s linear;\n\t}\n\t&:hover {\n\t\tbackground-color: #161616;\n\t}\n\t&:hover,\n\t&.is-selected,\n\t&:first-of-type {\n\t\t.secondary-data {\n\t\t\topacity: 1;\n\t\t}\n\t}\n"]);
                return C = function() {
                    return n
                }, n
            }

            function S() {
                var n = (0, o.Z)(["\n\theight: 580px;\n\toverflow: auto;\n\t&::-webkit-scrollbar {\n\t\tdisplay: none;\n\t}\n\t-ms-overflow-style: none;\n\tscrollbar-width: none;\n"]);
                return S = function() {
                    return n
                }, n
            }
            var I = a.ZP.div.withConfig({
                    componentId: "sc-c13a7c6-0"
                })(C()),
                L = a.ZP.div.withConfig({
                    componentId: "sc-c13a7c6-1"
                })(S()),
                Z = function() {
                    return (0, i.jsx)(l.xu, {
                        mt: "200px",
                        display: "flex",
                        justifyContent: "center",
                        children: (0, i.jsx)(l.xv, {
                            fontSize: "20px",
                            fontWeight: "bold",
                            children: "No transaction history"
                        })
                    })
                };

            function A(n) {
                var e = n.tokensUrlMap,
                    t = n.tokensSymbolsMap,
                    o = (0, p.mA)(),
                    r = (0, c.qY)(),
                    a = r.isOpen,
                    f = r.onOpen,
                    h = r.onClose,
                    x = function(n) {
                        var e = n.userId,
                            t = n.tokensUrlMap,
                            o = n.tokensSymbolsMap,
                            i = n.isOpen,
                            r = (0, k.K)().chainName,
                            a = w.zk[r];
                        return (0, g.a)(["getSwapsHistory", e, a], (function() {
                            return j({
                                userId: e,
                                chain: a,
                                tokensUrlMap: t,
                                tokensSymbolsMap: o
                            })
                        }), {
                            enabled: !!e && !!a && i,
                            staleTime: 25e3
                        })
                    }({
                        userId: null === o || void 0 === o ? void 0 : o.address,
                        tokensUrlMap: e,
                        tokensSymbolsMap: t,
                        isOpen: a
                    }),
                    v = x.data,
                    m = x.isLoading;
                return (0, i.jsxs)(i.Fragment, {
                    children: [(0, i.jsx)(d.zx, {
                        onClick: f,
                        borderRadius: "12px",
                        height: "36px",
                        mt: "2px",
                        colorScheme: "twitter",
                        display: {
                            base: "none",
                            sm: "none",
                            lg: "block",
                            md: "block"
                        },
                        children: "History"
                    }), (0, i.jsxs)(u.u_, {
                        isOpen: a,
                        onClose: h,
                        size: "lg",
                        children: [(0, i.jsx)(u.ZA, {}), (0, i.jsxs)(u.hz, {
                            backgroundColor: "#22242A",
                            color: "white",
                            children: [(0, i.jsx)(u.xB, {
                                children: "Swaps History"
                            }), (0, i.jsx)(u.ol, {}), (0, i.jsx)(u.fe, {
                                children: m && (null === o || void 0 === o ? void 0 : o.address) ? (0, i.jsx)(l.xu, {
                                    display: "flex",
                                    height: "580px",
                                    padding: "120px",
                                    children: (0, i.jsx)(y.Z, {})
                                }) : (0, i.jsx)(L, {
                                    children: (null === v || void 0 === v ? void 0 : v.length) ? null === v || void 0 === v ? void 0 : v.map((function(n) {
                                        var e;
                                        return (null === n || void 0 === n ? void 0 : n.route) ? (0, i.jsx)(I, {
                                            onClick: function() {
                                                return window.open(n.txUrl)
                                            },
                                            children: (0, i.jsx)(l.gC, {
                                                children: (0, i.jsxs)(l.Ug, {
                                                    justifyContent: "space-between",
                                                    w: "100%",
                                                    children: [(0, i.jsxs)(l.gC, {
                                                        alignItems: "baseline",
                                                        children: [(0, i.jsxs)("div", {
                                                            style: {
                                                                fontWeight: "500",
                                                                display: "flex"
                                                            },
                                                            children: [(0, i.jsxs)(l.Ug, {
                                                                children: [(0, i.jsx)("img", {
                                                                    src: n.fromIcon,
                                                                    style: {
                                                                        borderRadius: "50%",
                                                                        width: "20px",
                                                                        height: "20px"
                                                                    },
                                                                    alt: "fromIcon"
                                                                }), (0, i.jsx)("img", {
                                                                    src: n.toIcon,
                                                                    style: {
                                                                        borderRadius: "50%",
                                                                        marginLeft: "-4px",
                                                                        width: "20px",
                                                                        height: "20px"
                                                                    },
                                                                    alt: "toIcon"
                                                                })]
                                                            }), (0, i.jsxs)("div", {
                                                                style: {
                                                                    marginLeft: "8px"
                                                                },
                                                                children: [n.fromSymbol, " ", (0, i.jsx)(s.mr, {}), " ", n.toSymbol, " via ", n.aggregator]
                                                            })]
                                                        }), (0, i.jsx)(l.xv, {
                                                            children: new Date(n.createdAt).toLocaleDateString()
                                                        })]
                                                    }), (0, i.jsxs)(l.gC, {
                                                        children: [(0, i.jsxs)(l.xv, {
                                                            w: "100%",
                                                            textAlign: "end",
                                                            color: "red.400",
                                                            children: ["-", Number(null === n || void 0 === n ? void 0 : n.amount).toLocaleString("en", {
                                                                maximumFractionDigits: 5,
                                                                notation: "compact"
                                                            }), " ", n.fromSymbol]
                                                        }), (0, i.jsxs)(l.xv, {
                                                            w: "100%",
                                                            textAlign: "end",
                                                            color: "green.400",
                                                            children: ["+", Number(null === n || void 0 === n || null === (e = n.route) || void 0 === e ? void 0 : e.amount).toLocaleString("en", {
                                                                maximumFractionDigits: 5,
                                                                notation: "compact"
                                                            }), " ", n.toSymbol]
                                                        })]
                                                    })]
                                                })
                                            })
                                        }, n.id) : null
                                    })) : (0, i.jsx)(Z, {})
                                })
                            })]
                        })]
                    })]
                })
            }

            function N() {
                var n = (0, o.Z)(["\n\tposition: absolute;\n\tright: 0px;\n\tz-index: 100;\n\tdisplay: flex;\n\tgap: 8px;\n"]);
                return N = function() {
                    return n
                }, n
            }
            var T = a.ZP.div.withConfig({
                    componentId: "sc-c4f545e2-0"
                })(N()),
                z = function(n) {
                    var e = n.tokenList,
                        t = void 0 === e ? null : e,
                        o = n.tokensUrlMap,
                        a = void 0 === o ? {} : o,
                        s = n.tokensSymbolsMap,
                        l = void 0 === s ? {} : s;
                    return (0, i.jsxs)(T, {
                        children: [(0, i.jsx)(r.NL, {
                            chainStatus: "none"
                        }), t ? (0, i.jsx)(A, {
                            tokensUrlMap: a,
                            tokensSymbolsMap: l
                        }) : null]
                    })
                }
        },
        23103: function(n, e, t) {
            t.d(e, {
                Kt: function() {
                    return f
                },
                Z: function() {
                    return h
                },
                h4: function() {
                    return p
                }
            });
            var o = t(7297),
                i = (t(85893), t(67294), t(186));

            function r() {
                var n = (0, o.Z)(["\n\tposition: fixed;\n\ttop: 0;\n\tleft: 0;\n\tright: 0;\n\tbottom: 0;\n\tbackground: rgba(0, 0, 0, 0.6);\n\tz-index: 150;\n\tdisplay: flex;\n\tjustify-content: center;\n\talign-items: center;\n"]);
                return r = function() {
                    return n
                }, n
            }

            function a() {
                var n = (0, o.Z)(["\n\tdisplay: flex;\n\tflex-direction: column;\n\tmax-width: 540px;\n\theight: 500px;\n\tbackground: ", ";\n\ttop: -50px;\n\tbottom: 0;\n\tleft: 0;\n\tright: 0;\n\tmargin: auto;\n\twidth: 100%;\n\tmargin: 0 20px;\n\tborder: 1px solid #2f333c;\n\tbox-shadow: ", ";\n\tpadding: 16px;\n\tborder-radius: 16px;\n\tz-index: 2;\n\n\tanimation: scale-in-center 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94) both;\n\n\t@keyframes scale-in-center {\n\t\t0% {\n\t\t\ttransform: scale(0);\n\t\t\topacity: 1;\n\t\t}\n\t\t100% {\n\t\t\ttransform: scale(1);\n\t\t\topacity: 1;\n\t\t}\n\t}\n"]);
                return a = function() {
                    return n
                }, n
            }

            function s() {
                var n = (0, o.Z)(["\n\tposition: sticky;\n\ttext-align: center;\n\tjustify-content: center;\n\tdisplay: flex;\n\tmargin-bottom: 8px;\n"]);
                return s = function() {
                    return n
                }, n
            }

            function l() {
                var n = (0, o.Z)(["\n\tdisplay: flex;\n\tgap: 8px;\n\tpadding: 8px 4px;\n\talign-items: center;\n\tborder-bottom: ", ";\n\n\tcursor: pointer;\n\n\t&[data-defaultcursor='true'] {\n\t\tcursor: default;\n\t}\n\n\t&:hover {\n\t\tbackground-color: ", ";\n\t}\n"]);
                return l = function() {
                    return n
                }, n
            }

            function c() {
                var n = (0, o.Z)(["\n\tborder-radius: 50%;\n\twidth: 20px;\n\theight: 20px;\n\taspect-ratio: 1;\n\tflex-shrink: 0;\n\tobject-fit: contain;\n"]);
                return c = function() {
                    return n
                }, n
            }

            function d() {
                var n = (0, o.Z)(["\n\tdisplay: flex;\n\tmargin-right: 8px;\n"]);
                return d = function() {
                    return n
                }, n
            }

            function u() {
                var n = (0, o.Z)(["\n\toverflow-y: scroll;\n"]);
                return u = function() {
                    return n
                }, n
            }
            i.ZP.div.withConfig({
                componentId: "sc-b49748d5-0"
            })(r()), i.ZP.div.withConfig({
                componentId: "sc-b49748d5-1"
            })(a(), (function(n) {
                return n.theme.bg1
            }), (function(n) {
                return "dark" === n.theme.mode ? "10px 0px 50px 10px rgba(26, 26, 26, 0.9);" : "10px 0px 50px 10px rgba(211, 211, 211, 0.9);;"
            }));
            var p = i.ZP.div.withConfig({
                    componentId: "sc-b49748d5-2"
                })(s()),
                f = i.ZP.div.withConfig({
                    componentId: "sc-b49748d5-3"
                })(l(), (function(n) {
                    return "dark" === n.theme.mode ? "1px solid #373944;" : "2px solid #c6cae0;"
                }), (function(n) {
                    return n.hover ? " rgba(246, 246, 246, 0.1);" : "none"
                })),
                h = i.ZP.img.withConfig({
                    componentId: "sc-b49748d5-4"
                })(c());
            i.ZP.div.withConfig({
                componentId: "sc-b49748d5-5"
            })(d()), i.ZP.div.withConfig({
                componentId: "sc-b49748d5-6"
            })(u())
        },
        30882: function(n, e, t) {
            var o = t(85893),
                i = t(97375),
                r = t(64737),
                a = t(26723),
                s = t(4612),
                l = t(67294);
            e.Z = function(n) {
                var e = n.handleSwap,
                    t = n.isUnknownPrice,
                    c = void 0 !== t && t,
                    d = n.isMaxPriceImpact,
                    u = void 0 !== d && d,
                    p = n.isDegenModeEnabled,
                    f = void 0 !== p && p,
                    h = (0, i.qY)(),
                    x = h.isOpen,
                    v = h.onToggle,
                    m = h.onClose,
                    g = u ? "trade" : "confirm",
                    b = (0, l.useState)(""),
                    w = b[0],
                    k = b[1],
                    j = (null === w || void 0 === w ? void 0 : w.toLowerCase()) !== g;
                return (0, o.jsx)(o.Fragment, {
                    children: (0, o.jsxs)(r.J2, {
                        returnFocusOnClose: !1,
                        isOpen: x,
                        onClose: function() {
                            k(""), m()
                        },
                        placement: "top",
                        children: [(0, o.jsx)(r.xo, {
                            children: (0, o.jsx)(a.zx, {
                                colorScheme: "red",
                                onClick: function() {
                                    return v()
                                },
                                children: "Swap"
                            })
                        }), (0, o.jsxs)(r.yk, {
                            children: [(0, o.jsx)(r.QH, {}), (0, o.jsx)(r.us, {}), (0, o.jsx)(r.Yt, {
                                children: "Swap Confirmation."
                            }), c ? (0, o.jsxs)(r.b, {
                                children: ["We can't get price for one of your tokens. ", (0, o.jsx)("br", {}), "Check output amount of the selected route carefully.", (0, o.jsx)(a.zx, {
                                    colorScheme: "red",
                                    onClick: e,
                                    mt: 4,
                                    children: "Swap"
                                })]
                            }) : (0, o.jsxs)(r.b, {
                                children: ["Price impact is too high.", (0, o.jsx)("br", {}), "You'll likely lose money.", (0, o.jsx)("br", {}), f ? null : (0, o.jsxs)(o.Fragment, {
                                    children: ['Type "', g, '" to make a swap.', (0, o.jsx)(s.II, {
                                        placeholder: "Type here...",
                                        mt: "4px",
                                        onChange: function(n) {
                                            return k(n.target.value)
                                        },
                                        value: w
                                    })]
                                }), (0, o.jsx)(a.zx, {
                                    colorScheme: "red",
                                    onClick: e,
                                    mt: 4,
                                    isDisabled: j && !f,
                                    children: "Swap with high slippage"
                                })]
                            })]
                        })]
                    })
                })
            }
        },
        81811: function(n, e, t) {
            t.d(e, {
                Z: function() {
                    return x
                }
            });
            var o = t(26042),
                i = t(69396),
                r = t(9279),
                a = t(2593),
                s = t(21046),
                l = t(67294),
                c = t(38793),
                d = t(2347),
                u = t(47787),
                p = ["0xdAC17F958D2ee523a2206206994597C13D831ec7".toLowerCase(), "0x5A98FcBEA516Cf06857215779Fd812CA3beF1B32".toLowerCase()],
                f = {
                    fantom: !0,
                    arbitrum: !0
                },
                h = function(n, e) {
                    return e ? function() {
                        return n({
                            recklesslySetUnpreparedOverrides: e
                        })
                    } : n
                },
                x = function(n, e, t) {
                    var x, v, m = (0, l.useState)(!1),
                        g = m[0],
                        b = m[1],
                        w = (0, l.useState)(!1),
                        k = w[0],
                        j = w[1],
                        y = (0, l.useState)(!1),
                        C = y[0],
                        S = y[1],
                        I = (0, c.LN)(),
                        L = (0, c.mA)(),
                        Z = L.address,
                        A = L.isConnected,
                        N = function(n, e, t) {
                            var o = (0, c.mA)(),
                                i = o.address,
                                s = o.isConnected,
                                l = !!n && p.includes(null === n || void 0 === n ? void 0 : n.toLowerCase()),
                                u = (0, c.do)({
                                    address: n,
                                    abi: d.em,
                                    functionName: "allowance",
                                    args: [i, e],
                                    watch: !0,
                                    enabled: s && !!e && n !== r.d
                                }),
                                f = u.data,
                                h = u.refetch,
                                x = u.isRefetching,
                                v = l && f && t && !Number.isNaN(Number(t)) && f.lt(a.O$.from(t)) && !f.eq(0);
                            return {
                                allowance: f,
                                shouldRemoveApproval: v,
                                refetch: h,
                                isRefetching: x
                            }
                        }(n, e, t),
                        T = N.allowance,
                        z = N.shouldRemoveApproval,
                        O = N.refetch,
                        M = Number(t) ? t : "0",
                        F = (0, c.PJ)({
                            address: n,
                            abi: d.em,
                            functionName: "approve",
                            args: [e, M ? a.O$.from(M) : s.Bz],
                            enabled: A && !!e && !!n
                        }),
                        R = F.config,
                        _ = F.data,
                        U = z || !(null === _ || void 0 === _ || null === (x = _.request) || void 0 === x ? void 0 : x.gasLimit) || f[I.chain.network] ? null : {
                            gasLimit: null === _ || void 0 === _ || null === (v = _.request) || void 0 === v ? void 0 : v.gasLimit.mul(140).div(100)
                        },
                        W = (0, c.PJ)({
                            address: n,
                            abi: d.em,
                            functionName: "approve",
                            args: [e, s.Bz],
                            enabled: A && !!e && !!n
                        }).config,
                        D = (0, c.PJ)({
                            address: n,
                            abi: d.em,
                            functionName: "approve",
                            args: [e, a.O$.from("0")],
                            enabled: A && !!e && !!n && z
                        }).config,
                        P = (0, c.GG)((0, i.Z)((0, o.Z)({}, R), {
                            onSuccess: function(n) {
                                b(!0), n.wait().then((function() {
                                    O()
                                })).catch((function(n) {
                                    return console.log(n)
                                })).finally((function() {
                                    b(!1)
                                }))
                            }
                        })),
                        E = P.write,
                        B = P.isLoading,
                        G = (0, c.GG)((0, i.Z)((0, o.Z)({}, W), {
                            onSuccess: function(n) {
                                j(!0), n.wait().then((function() {
                                    O()
                                })).catch((function(n) {
                                    return console.log(n)
                                })).finally((function() {
                                    j(!1)
                                }))
                            }
                        })),
                        q = G.write,
                        H = G.isLoading,
                        Q = (0, c.GG)((0, i.Z)((0, o.Z)({}, D), {
                            onSuccess: function(n) {
                                S(!0), n.wait().then((function() {
                                    O()
                                })).catch((function(n) {
                                    return console.log(n)
                                })).finally((function() {
                                    S(!1)
                                }))
                            }
                        })),
                        Y = Q.write,
                        J = Q.isLoading;
                    return n === r.d || (null === n || void 0 === n ? void 0 : n.toLowerCase()) === u.cB.toLowerCase() ? {
                        isApproved: !0
                    } : Z && T ? T.toString() === s.Bz.toString() || M && T.gte(a.O$.from(M)) ? {
                        isApproved: !0,
                        allowance: T
                    } : {
                        isApproved: !1,
                        approve: h(E, U),
                        approveInfinite: h(q, U),
                        approveReset: h(Y, U),
                        isLoading: B || g,
                        isConfirmingApproval: g,
                        isInfiniteLoading: H || k,
                        isConfirmingInfiniteApproval: k,
                        isResetLoading: J || C,
                        isConfirmingResetApproval: C,
                        allowance: T,
                        shouldRemoveApproval: z
                    } : {
                        isApproved: !1
                    }
                }
        },
        91463: function(n, e, t) {
            t.d(e, {
                w: function() {
                    return M
                }
            });
            var o = t(85893),
                i = t(68527),
                r = t(4612),
                a = t(26723),
                s = t(70794),
                l = t(67294),
                c = t(44868),
                d = t(77501),
                u = t(47787),
                p = t(14924),
                f = t(26042),
                h = t(69396),
                x = t(19485),
                v = t(30077),
                m = t(61359),
                g = t(97375),
                b = t(28171),
                w = t(23103),
                k = t(38793),
                j = t(47398),
                y = t(10362),
                C = t(85945),
                S = t(25675),
                I = t.n(S),
                L = {
                    src: "/_next/static/media/coingecko.a50d6aa4.svg",
                    height: 276,
                    width: 276
                },
                Z = t(47257),
                A = t(27434),
                N = function(n) {
                    var e, t, r, s = n.chain,
                        l = n.token,
                        c = n.onClick,
                        d = null === (e = Z.k.find((function(n) {
                            return n.id == s.id
                        }))) || void 0 === e || null === (t = e.blockExplorers) || void 0 === t ? void 0 : t.default,
                        u = l.isMultichain;
                    return (0, o.jsxs)(w.Kt, {
                        "data-defaultcursor": !!l.isGeckoToken,
                        onClick: function() {
                            return !l.isGeckoToken && c(l)
                        },
                        children: [(0, o.jsx)(w.Z, {
                            src: l.logoURI,
                            onError: function(n) {
                                return n.currentTarget.src = l.logoURI2 || "/placeholder.png"
                            }
                        }), (0, o.jsxs)(i.xv, {
                            display: "flex",
                            flexDir: "column",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            children: [(0, o.jsx)(j.u, {
                                label: "This token could have been affected by the multichain hack.",
                                bg: "black",
                                color: "white",
                                isDisabled: !u,
                                children: (0, o.jsxs)(i.xv, {
                                    as: "span",
                                    whiteSpace: "nowrap",
                                    textOverflow: "ellipsis",
                                    overflow: "hidden",
                                    color: u ? "orange.200" : "white",
                                    children: ["".concat(l.name, " (").concat(l.symbol, ")"), l.isMultichain ? (0, o.jsx)(b.ii, {
                                        color: "orange.200",
                                        style: {
                                            marginLeft: "0.4em"
                                        }
                                    }) : null]
                                })
                            }), l.isGeckoToken && (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsxs)(i.xv, {
                                    as: "span",
                                    display: "flex",
                                    alignItems: "center",
                                    textColor: "gray.400",
                                    justifyContent: "flex-start",
                                    gap: "4px",
                                    fontSize: "0.75rem",
                                    children: [(0, o.jsx)("span", {
                                        children: "via CoinGecko"
                                    }), (0, o.jsx)(I(), {
                                        src: L,
                                        height: "14px",
                                        width: "14px",
                                        objectFit: "contain",
                                        alt: "",
                                        unoptimized: !0
                                    })]
                                }), d && (0, o.jsx)("a", {
                                    href: "".concat(d.url, "/address/").concat(l.address),
                                    target: "_blank",
                                    rel: "noreferrer noopener",
                                    style: {
                                        fontSize: "0.75rem",
                                        textDecoration: "underline"
                                    },
                                    children: "View on ".concat(d.name)
                                })]
                            })]
                        }), l.balanceUSD ? (0, o.jsxs)("div", {
                            style: {
                                marginRight: 0,
                                marginLeft: "auto"
                            },
                            children: [(l.amount / Math.pow(10, l.decimals)).toFixed(3), (0, o.jsxs)("span", {
                                style: {
                                    fontSize: 12
                                },
                                children: [" (~$", null === (r = l.balanceUSD) || void 0 === r ? void 0 : r.toFixed(3), ")"]
                            })]
                        }) : null, l.isGeckoToken && (0, o.jsx)(j.u, {
                            label: "This token doesn't appear on active token list(s). Make sure this is the token that you want to trade.",
                            bg: "black",
                            color: "white",
                            children: (0, o.jsx)(a.zx, {
                                fontSize: "0.875rem",
                                fontWeight: 500,
                                ml: "auto",
                                colorScheme: "orange",
                                onClick: function() {
                                    return c(l)
                                },
                                leftIcon: (0, o.jsx)(b.ii, {}),
                                flexShrink: 0,
                                children: (0, o.jsx)("span", {
                                    style: {
                                        position: "relative",
                                        top: "1px"
                                    },
                                    children: "Import Token"
                                })
                            })
                        })]
                    }, l.value)
                },
                T = function(n) {
                    var e, t = n.address,
                        r = n.selectedChain,
                        s = n.onClick,
                        l = (0, k.dQ)({
                            address: t,
                            chainId: r.id,
                            enabled: !("string" !== typeof t || 42 !== t.length || !r)
                        }),
                        c = l.data,
                        d = l.isLoading,
                        u = l.isError,
                        x = (0, C.NL)();
                    return (0, o.jsxs)(i.kC, {
                        alignItems: "center",
                        mt: "16px",
                        p: "8px",
                        gap: "8px",
                        justifyContent: "space-between",
                        flexWrap: "wrap",
                        borderBottom: "1px solid #373944",
                        children: [(0, o.jsx)(w.Z, {
                            src: "https://token-icons.llamao.fi/icons/tokens/".concat(null !== (e = null === r || void 0 === r ? void 0 : r.id) && void 0 !== e ? e : 1, "/").concat(t, "?h=20&w=20"),
                            onError: function(n) {
                                return n.currentTarget.src = "/placeholder.png"
                            }
                        }), (0, o.jsx)(i.xv, {
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            overflow: "hidden",
                            children: d ? "Loading..." : (null === c || void 0 === c ? void 0 : c.name) ? "".concat(c.name, " (").concat(c.symbol, ")") : t.slice(0, 4) + "..." + t.slice(-4)
                        }), (0, o.jsx)(a.zx, {
                            height: 38,
                            marginLeft: "auto",
                            onClick: function() {
                                var n;
                                u || (! function(n) {
                                    var e = JSON.parse(localStorage.getItem("savedTokens") || "{}"),
                                        t = e[n.chainId] || [],
                                        o = (0, h.Z)((0, f.Z)({}, e), (0, p.Z)({}, n.chainId, t.concat(n)));
                                    localStorage.setItem("savedTokens", JSON.stringify(o))
                                }((0, h.Z)((0, f.Z)({
                                    address: t
                                }, c || {}), {
                                    label: null === c || void 0 === c ? void 0 : c.symbol,
                                    value: t,
                                    chainId: null === r || void 0 === r ? void 0 : r.id,
                                    logoURI: "https://token-icons.llamao.fi/icons/tokens/".concat(null !== (n = null === r || void 0 === r ? void 0 : r.id) && void 0 !== n ? n : 1, "/").concat(t, "?h=20&w=20")
                                })), x.invalidateQueries({
                                    queryKey: ["savedTokens", null === r || void 0 === r ? void 0 : r.id]
                                }), s({
                                    address: t,
                                    label: null === c || void 0 === c ? void 0 : c.symbol,
                                    value: t
                                }))
                            },
                            disabled: u,
                            children: "Add token"
                        }), u && (0, o.jsx)(i.xv, {
                            fontSize: "0.75rem",
                            color: "red",
                            w: "100%",
                            textAlign: "center",
                            children: "This address is not a contract on ".concat(r.value)
                        })]
                    }, t)
                },
                z = function(n) {
                    var e = n.isOpen,
                        t = n.onClose,
                        a = n.data,
                        s = n.onClick,
                        c = n.selectedChain,
                        d = (0, l.useState)(""),
                        u = d[0],
                        p = d[1],
                        f = (0, y.N)(u, 300),
                        h = (0, l.useMemo)((function() {
                            return f ? null === a || void 0 === a ? void 0 : a.filter((function(n) {
                                var e, t;
                                return !(!n.symbol || !(null === (e = n.symbol.toLowerCase()) || void 0 === e ? void 0 : e.includes(f.toLowerCase()))) || (!(!n.address || n.address.toLowerCase() !== f.toLowerCase()) || !(!n.name || !(null === (t = n.name.toLowerCase()) || void 0 === t ? void 0 : t.includes(f.toLowerCase()))))
                            })) : a
                        }), [f, a]),
                        g = (0, l.useRef)(),
                        b = (0, v.MG)({
                            count: h.length,
                            getScrollElement: function() {
                                return g.current
                            },
                            estimateSize: function(n) {
                                return h[n].isGeckoToken ? 72 : 40
                            },
                            overscan: 10
                        });
                    return (0, o.jsxs)(m.u_, {
                        isCentered: !0,
                        isOpen: e,
                        onClose: t,
                        children: [(0, o.jsx)(m.ZA, {}), (0, o.jsxs)(m.hz, {
                            display: "flex",
                            flexDir: "column",
                            maxW: "540px",
                            maxH: "500px",
                            w: "100%",
                            h: "100%",
                            p: "16px",
                            borderRadius: "16px",
                            bg: "#212429",
                            color: "white",
                            children: [(0, o.jsxs)(w.h4, {
                                children: [(0, o.jsx)(i.xv, {
                                    fontWeight: 500,
                                    color: "#FAFAFA",
                                    fontSize: 20,
                                    children: "Select Token"
                                }), (0, o.jsx)(m.ol, {
                                    bg: "none",
                                    pos: "absolute",
                                    top: "-4px",
                                    right: "-8px",
                                    onClick: t
                                })]
                            }), (0, o.jsx)("div", {
                                children: (0, o.jsx)(r.II, {
                                    bg: "#141619",
                                    placeholder: "Search... (Symbol or Address)",
                                    _focusVisible: {
                                        outline: "none"
                                    },
                                    onChange: function(n) {
                                        var e;
                                        p(null === n || void 0 === n || null === (e = n.target) || void 0 === e ? void 0 : e.value)
                                    },
                                    autoFocus: !0
                                })
                            }), x.isAddress(u) && 0 === h.length ? (0, o.jsx)(T, {
                                address: u,
                                onClick: s,
                                selectedChain: c
                            }) : null, (0, o.jsx)("div", {
                                ref: g,
                                className: "List",
                                style: {
                                    height: "390px",
                                    overflow: "auto",
                                    marginTop: "24px"
                                },
                                children: (0, o.jsx)("div", {
                                    style: {
                                        height: "".concat(b.getTotalSize(), "px"),
                                        width: "100%",
                                        position: "relative"
                                    },
                                    children: b.getVirtualItems().map((function(n) {
                                        return (0, o.jsx)("div", {
                                            style: {
                                                position: "absolute",
                                                top: 0,
                                                left: 0,
                                                width: "100%",
                                                height: h[n.index].isGeckoToken ? "72px" : "40px",
                                                transform: "translateY(".concat(n.start, "px)")
                                            },
                                            children: (0, o.jsx)(N, {
                                                token: h[n.index],
                                                onClick: s,
                                                chain: c
                                            })
                                        }, n.index + h[n.index].address)
                                    }))
                                })
                            })]
                        })]
                    })
                },
                O = function(n) {
                    var e = n.tokens,
                        t = n.onClick,
                        r = n.token,
                        s = n.selectedChain,
                        l = (0, g.qY)(),
                        c = l.isOpen,
                        d = l.onOpen,
                        u = l.onClose;
                    return (0, o.jsxs)(o.Fragment, {
                        children: [(0, o.jsxs)(a.zx, {
                            display: "flex",
                            gap: "6px",
                            flexWrap: "nowrap",
                            alignItems: "center",
                            w: "100%",
                            borderRadius: "8px",
                            bg: "#222429",
                            _hover: {
                                bg: "#2d3037"
                            },
                            maxW: {
                                base: "128px",
                                md: "9rem"
                            },
                            p: "12px",
                            onClick: function() {
                                return d()
                            },
                            children: [r && (0, o.jsx)(w.Z, {
                                src: r.logoURI,
                                onError: function(n) {
                                    return n.currentTarget.src = r.logoURI2 || "/placeholder.png"
                                }
                            }), (0, o.jsx)(j.u, {
                                label: "This token could have been affected by the multichain hack.",
                                bg: "black",
                                color: "white",
                                isDisabled: !(null === r || void 0 === r ? void 0 : r.isMultichain),
                                children: (null === r || void 0 === r ? void 0 : r.isMultichain) ? (0, o.jsx)(b.ii, {
                                    color: "orange.200"
                                }) : (0, o.jsx)(o.Fragment, {})
                            }), (0, o.jsx)(i.xv, {
                                as: "span",
                                color: "white",
                                overflow: "hidden",
                                whiteSpace: "nowrap",
                                textOverflow: "ellipsis",
                                fontWeight: 400,
                                children: r ? r.symbol : "Select Token"
                            }), (0, o.jsx)(A.Z, {
                                size: 16,
                                style: {
                                    marginLeft: "auto"
                                }
                            })]
                        }), c ? (0, o.jsx)(z, {
                            isOpen: c,
                            onClose: u,
                            data: e,
                            onClick: function(n) {
                                t(n), u()
                            },
                            selectedChain: s
                        }) : null]
                    })
                };

            function M(n) {
                var e = n.amount,
                    t = n.setAmount,
                    l = n.type,
                    p = n.tokens,
                    f = n.token,
                    h = n.onSelectTokenChange,
                    x = n.selectedChain,
                    v = n.balance,
                    m = n.onMaxClick,
                    g = n.tokenPrice,
                    b = n.priceImpact,
                    w = n.placeholder,
                    k = n.customSelect,
                    j = n.disabled,
                    y = void 0 !== j && j,
                    C = e && g && !Number.isNaN(Number((0, d.d)(e))) && !Number.isNaN(Number(g)) ? (0, s.Z)((0, d.d)(e)).times(g).toFixed(2) : null;
                return (0, o.jsxs)(i.kC, {
                    flexDir: "column",
                    gap: "8px",
                    bg: "#141619",
                    color: "white",
                    borderRadius: "12px",
                    p: ["8px", "8px", "16px", "16px"],
                    border: "1px solid transparent",
                    _focusWithin: {
                        border: "1px solid white"
                    },
                    children: [(0, o.jsx)(i.xv, {
                        fontSize: "0.875rem",
                        fontWeight: 400,
                        color: "#a2a2a2",
                        whiteSpace: "nowrap",
                        minH: "1.375rem",
                        children: "amountIn" === l ? "You sell" : "You buy"
                    }), (0, o.jsxs)(i.kC, {
                        flexDir: {
                            md: "row"
                        },
                        gap: {
                            base: "12px",
                            md: "8px"
                        },
                        children: [(0, o.jsx)(i.xu, {
                            pos: "relative",
                            children: (0, o.jsx)(r.II, {
                                disabled: y,
                                type: "text",
                                value: e,
                                focusBorderColor: "transparent",
                                border: "none",
                                bg: "#141619",
                                color: "white",
                                _focusVisible: {
                                    outline: "none"
                                },
                                fontSize: "2.25rem",
                                p: "0",
                                placeholder: w && String(w) || "0",
                                _placeholder: {
                                    color: "#5c5c5c"
                                },
                                onChange: function(n) {
                                    var e, o = function(n) {
                                        var e = /(?=(?!^)\d{3}(?:\b|(?:\d{3})+)\b)/g;
                                        n.includes(".") && (e = /(?=(?!^)\d{3}(?:\b|(?:\d{3})+)\b\.)/g);
                                        return n.replace(e, " ")
                                    }(null === (e = n.target.value.replace(/[^0-9.,]/g, "")) || void 0 === e ? void 0 : e.replace(/,/g, "."));
                                    t("amountOut" === l ? ["", o] : [o, ""])
                                },
                                overflow: "hidden",
                                whiteSpace: "nowrap",
                                textOverflow: "ellipsis"
                            })
                        }), k || (0, o.jsx)(O, {
                            tokens: p,
                            token: f,
                            onClick: h,
                            selectedChain: x
                        })]
                    }), (0, o.jsxs)(i.kC, {
                        alignItems: "center",
                        justifyContent: "space-between",
                        flexWrap: "wrap",
                        gap: "8px",
                        minH: "1.375rem",
                        children: [(0, o.jsx)(i.xv, {
                            fontSize: "0.875rem",
                            fontWeight: 300,
                            color: "#a2a2a2",
                            overflow: "hidden",
                            whiteSpace: "nowrap",
                            textOverflow: "ellipsis",
                            children: C && (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)("span", {
                                    children: "~$".concat((0, c.yb)(C))
                                }), (0, o.jsx)(i.xv, {
                                    as: "span",
                                    color: b >= u.gS ? "red.500" : b >= u.Aw ? "yellow.500" : "#a2a2a2",
                                    children: b && !Number.isNaN(b) ? " (-".concat(b.toFixed(2), "%)") : ""
                                })]
                            })
                        }), (0, o.jsx)(i.kC, {
                            alignItems: "center",
                            justifyContent: "flex-start",
                            flexWrap: "nowrap",
                            gap: "8px",
                            children: v && (0, o.jsxs)(o.Fragment, {
                                children: [(0, o.jsx)(i.xv, {
                                    fontSize: "0.875rem",
                                    fontWeight: 300,
                                    color: "#a2a2a2",
                                    children: "Balance: ".concat(Number(v).toFixed(4))
                                }), m && (0, o.jsx)(a.zx, {
                                    onClick: m,
                                    p: "0",
                                    minH: 0,
                                    minW: 0,
                                    h: "fit-content",
                                    bg: "none",
                                    _hover: {
                                        bg: "none"
                                    },
                                    fontSize: "0.875rem",
                                    fontWeight: 500,
                                    color: "#1f72e5",
                                    children: "Max"
                                })]
                            })
                        })]
                    })]
                })
            }
        },
        15773: function(n, e, t) {
            t.d(e, {
                t: function() {
                    return s
                }
            });
            var o = t(85893),
                i = t(61359),
                r = t(68527),
                a = t(28171),
                s = function(n) {
                    var e = n.open,
                        t = n.setOpen,
                        s = n.link;
                    return (0, o.jsxs)(i.u_, {
                        isCentered: !0,
                        motionPreset: "slideInBottom",
                        closeOnOverlayClick: !0,
                        isOpen: e,
                        onClose: function() {
                            return t(!1)
                        },
                        children: [(0, o.jsx)(i.ZA, {}), (0, o.jsxs)(i.hz, {
                            children: [(0, o.jsx)(i.ol, {
                                color: "white"
                            }), (0, o.jsxs)(i.fe, {
                                display: "flex",
                                gap: "8px",
                                flexDir: "column",
                                alignItems: "center",
                                marginY: "4rem",
                                color: "white",
                                children: [(0, o.jsxs)("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    width: "80",
                                    height: "80",
                                    viewBox: "0 0 24 24",
                                    fill: "none",
                                    stroke: "currentColor",
                                    strokeWidth: "0.5",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    children: [(0, o.jsx)("circle", {
                                        cx: "12",
                                        cy: "12",
                                        r: "10"
                                    }), (0, o.jsx)("polyline", {
                                        points: "16 12 12 8 8 12"
                                    }), (0, o.jsx)("line", {
                                        x1: "12",
                                        y1: "16",
                                        x2: "12",
                                        y2: "8"
                                    })]
                                }), (0, o.jsx)(r.xv, {
                                    as: "h1",
                                    fontSize: "xl",
                                    fontWeight: "600",
                                    children: "Transaction Submitted"
                                })]
                            }), (0, o.jsxs)(r.rU, {
                                href: s,
                                isExternal: !0,
                                fontSize: "lg",
                                textAlign: "center",
                                padding: "6px 1rem",
                                borderRadius: "0.375rem",
                                bg: "#a2cdff",
                                margin: "0 1rem 1rem",
                                color: "black",
                                _hover: {
                                    textDecoration: "none"
                                },
                                children: ["View on explorer ", (0, o.jsx)(a.h0, {
                                    mx: "2px"
                                })]
                            })]
                        })]
                    })
                }
        },
        85399: function(n, e, t) {
            t.d(e, {
                a: function() {
                    return i
                },
                k: function() {
                    return r
                }
            });
            var o = t(67294),
                i = function(n) {
                    var e = new Date(n).getTime(),
                        t = (0, o.useState)(e - (new Date).getTime()),
                        i = t[0],
                        r = t[1];
                    (0, o.useEffect)((function() {
                        var n = setInterval((function() {
                            r(e - (new Date).getTime())
                        }), 1e3);
                        return function() {
                            return clearInterval(n)
                        }
                    }), [e]);
                    var a = Math.floor(i % 6e4 / 1e3);
                    return a < 0 || Number.isNaN(a) ? 0 : a
                };

            function r(n) {
                var e = (0, o.useState)(n),
                    t = e[0],
                    i = e[1],
                    r = (0, o.useState)(!1),
                    s = r[0],
                    l = r[1];
                (0, o.useEffect)((function() {
                    if (s) {
                        i(n);
                        var e = setInterval((function() {
                            i((function(n) {
                                return n - 1e3
                            }))
                        }), 1e3);
                        return function() {
                            return clearInterval(e)
                        }
                    }
                }), [n]);
                return {
                    countdown: a(t),
                    start: function() {
                        return l(!0)
                    },
                    isStarted: s
                }
            }
            var a = function(n) {
                return {
                    days: s(n / 864e5),
                    hours: s(n % 864e5 / 36e5),
                    minutes: s(n % 36e5 / 6e4),
                    seconds: s(n % 6e4 / 1e3)
                }
            };

            function s(n) {
                return n > 0 ? Math.floor(n) : Math.ceil(n)
            }
        },
        10362: function(n, e, t) {
            t.d(e, {
                N: function() {
                    return i
                }
            });
            var o = t(67294);

            function i(n, e) {
                var t = (0, o.useState)(n),
                    i = t[0],
                    r = t[1];
                return (0, o.useEffect)((function() {
                    var t = setTimeout((function() {
                        r(n)
                    }), e);
                    return function() {
                        clearTimeout(t)
                    }
                }), [n, e]), i
            }
        },
        83319: function(n, e, t) {
            t.d(e, {
                _: function() {
                    return r
                }
            });
            var o = t(82670),
                i = t(67294);

            function r(n, e) {
                var t = (0, i.useState)((function() {
                        try {
                            var t = window.localStorage.getItem(n);
                            return t ? JSON.parse(t) : e
                        } catch (o) {
                            return console.log(o), e
                        }
                    })),
                    r = t[0],
                    a = t[1];
                return [r, function(e) {
                    try {
                        var t = (0, o.Z)(e, Function) ? e(r) : e;
                        a(t), window.localStorage.setItem(n, JSON.stringify(t))
                    } catch (i) {
                        console.log(i)
                    }
                }]
            }
        },
        79591: function(n, e, t) {
            t.d(e, {
                K: function() {
                    return l
                }
            });
            var o = t(9279),
                i = t(11163),
                r = t(67294),
                a = t(38793),
                s = (0, t(45002).Mk)();

            function l() {
                var n = (0, i.useRouter)(),
                    e = (0, a.mA)().isConnected,
                    t = (0, a.LN)().chain,
                    l = n.query,
                    c = l.chain,
                    d = l.from,
                    u = l.to,
                    p = "string" === typeof c ? c.toLowerCase() : "ethereum",
                    f = "string" === typeof d ? d.toLowerCase() : null,
                    h = "string" === typeof u ? u.toLowerCase() : null;
                return (0, r.useEffect)((function() {
                    if (n.isReady && !c) {
                        var i = t ? s.find((function(n) {
                            return n.chainId === t.id
                        })) : null;
                        e && t && i && !t.unsupported ? n.push({
                            pathname: "/",
                            query: {
                                chain: i.value,
                                from: o.d
                            }
                        }, void 0, {
                            shallow: !0
                        }) : n.push({
                            pathname: "/",
                            query: {
                                chain: "ethereum",
                                from: o.d
                            }
                        }, void 0, {
                            shallow: !0
                        })
                    }
                }), [c, t, e, n]), {
                    chainName: p,
                    fromTokenAddress: f,
                    toTokenAddress: h
                }
            }
        },
        23217: function(n, e, t) {
            t.d(e, {
                K: function() {
                    return g
                },
                s: function() {
                    return m
                }
            });
            var o = t(47568),
                i = t(828),
                r = t(70655),
                a = t(17e3),
                s = t(82169),
                l = t(61744),
                c = t(64146),
                d = t(9279),
                u = t(56371),
                p = t(2347),
                f = t(38793),
                h = t(47787),
                x = t(38673),
                v = function() {
                    var n = (0, o.Z)((function(n) {
                        var e, t, o, a, d, f, h, x, v;
                        return (0, r.__generator)(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    e = n.rpcUrl, t = n.address, o = n.token, r.label = 1;
                                case 1:
                                    return r.trys.push([1, 5, , 6]), a = new s.r(e), o ? [3, 3] : [4, a.getBalance(t)];
                                case 2:
                                    return [2, {
                                        value: d = r.sent(),
                                        formatted: l.formatEther(d)
                                    }];
                                case 3:
                                    return f = new c.CH((0, u.getAddress)(o), p.em, a), [4, Promise.all([f.balanceOf((0, u.getAddress)(t)), f.decimals()])];
                                case 4:
                                    return h = i.Z.apply(void 0, [r.sent(), 2]), x = h[0], v = h[1], [2, {
                                        value: x,
                                        formatted: l.formatUnits(x, v),
                                        decimals: v
                                    }];
                                case 5:
                                    return r.sent(), [2, null];
                                case 6:
                                    return [2]
                            }
                        }))
                    }));
                    return function(e) {
                        return n.apply(this, arguments)
                    }
                }(),
                m = function() {
                    var n = (0, o.Z)((function(n) {
                        var e, t, o, i, a;
                        return (0, r.__generator)(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    e = n.address, t = n.chainId, o = n.token, r.label = 1;
                                case 1:
                                    return r.trys.push([1, 3, , 4]), e && t ? 0 === (i = Object.values(x.W2[t] || {})).length ? [2, null] : [4, Promise.any(i.map((function(n) {
                                        return v({
                                            rpcUrl: n,
                                            address: e,
                                            token: o
                                        })
                                    })))] : [2, null];
                                case 2:
                                    return [2, r.sent()];
                                case 3:
                                    return a = r.sent(), console.log(a), [2, null];
                                case 4:
                                    return [2]
                            }
                        }))
                    }));
                    return function(e) {
                        return n.apply(this, arguments)
                    }
                }(),
                g = function(n) {
                    var e = n.address,
                        t = n.chainId,
                        o = n.token,
                        i = (0, f.mA)().isConnected,
                        r = [d.d, h.cB.toLowerCase()].includes(null === o || void 0 === o ? void 0 : o.toLowerCase()) ? null : o,
                        s = !!(t && i && o),
                        l = (0, f.KQ)({
                            address: e,
                            token: r,
                            watch: !0,
                            chainId: t,
                            enabled: s
                        }),
                        c = (0, a.a)(["balance", e, t, o, !l.isLoading && !l.data], (function() {
                            return m({
                                address: e,
                                chainId: t,
                                token: o
                            })
                        }), {
                            refetchInterval: 1e4,
                            enabled: s && !l.isLoading && !l.data
                        });
                    return s ? l.isLoading || l.data ? l : c : {
                        isLoading: !1,
                        isSuccess: !1,
                        data: null
                    }
                }
        },
        77501: function(n, e, t) {
            t.d(e, {
                d: function() {
                    return o
                }
            });
            var o = function(n) {
                return n.toString().trim().split(" ").join("")
            }
        },
        63862: function(n, e, t) {
            t.d(e, {
                K: function() {
                    return a
                },
                h: function() {
                    return i
                }
            });
            var o = t(70794),
                i = function(n) {
                    var e, t, i, r, a, s, l, c, d, u, p = n.tokens.fromToken,
                        f = n.tokens.toToken,
                        h = null !== (c = null !== (l = null === (e = n.rawQuote) || void 0 === e ? void 0 : e.inAmount) && void 0 !== l ? l : null === (t = n.rawQuote) || void 0 === t ? void 0 : t.inputAmount) && void 0 !== c ? c : null === (i = n.rawQuote) || void 0 === i ? void 0 : i.sellAmount,
                        x = null !== (u = null !== (d = null === (r = n.rawQuote) || void 0 === r ? void 0 : r.outAmount) && void 0 !== d ? d : null === (a = n.rawQuote) || void 0 === a ? void 0 : a.outputAmount) && void 0 !== u ? u : null === (s = n.rawQuote) || void 0 === s ? void 0 : s.buyAmount;
                    return {
                        title: "Transaction Success",
                        description: "Swapped ".concat(h ? (0, o.Z)(h).div(Math.pow(10, Number(p.decimals || 18))).toFixed(3) : "", " ").concat(p.symbol, " for ").concat(x ? (0, o.Z)(x).div(Math.pow(10, Number(f.decimals || 18))).toFixed(3) : "", " ").concat(f.symbol, " via ").concat(n.adapter),
                        status: "success",
                        duration: 1e4,
                        isClosable: !0,
                        position: "top-right",
                        containerStyle: {
                            width: "100%",
                            maxWidth: "300px"
                        }
                    }
                },
                r = ["<minTotalAmountOut", "ERR_LIMIT_OUT", "Return amount is not enough", "Received amount of tokens are less then expected"],
                a = function(n) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        t = r.some((function(e) {
                            var t;
                            return null === n || void 0 === n || null === (t = n.reason) || void 0 === t ? void 0 : t.includes(e)
                        })),
                        o = "Someting went wrong";
                    return e ? o = "Transaction Failed" : t ? o = "Slippage is too low, try again with higher slppage" : (null === n || void 0 === n ? void 0 : n.reason) && (o = n.reason), {
                        title: "Transaction Failed",
                        description: o,
                        status: "error",
                        duration: 1e4,
                        isClosable: !0,
                        position: "top-right",
                        containerStyle: {
                            width: "100%",
                            maxWidth: "300px"
                        }
                    }
                }
        }
    }
]);