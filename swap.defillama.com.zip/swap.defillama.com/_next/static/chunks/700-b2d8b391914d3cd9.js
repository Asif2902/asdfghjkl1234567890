"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [700], {
        85417: function(n, t) {
            t.Z = {
                src: "/_next/static/media/loader.268d236d.png",
                height: 3668,
                width: 3667,
                blurDataURL: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAVFBMVEWBgdbQ4v9NM6VaWvGhnfCajM7I2v9CNsT///9fXPZbU920sfNUSM0PAH1mUbJRPK+RjNmysv95acfZ4v9NQcry/P9OP8X09P9aTM2Lf9ZnZPPc2/8GZpkCAAAAFXRSTlMB2uY0/v4xM/7j3/7lMzLW5jLm5uXKxFwkAAAACXBIWXMAACHVAAAh1QEEnLSdAAAAQklEQVR4nCXLSRKAIBDAwLDOACpuuP7/nxblKX0JIMMu0OtLdiA2qPrkSEfQszz5h78qsr5NbzvBsrU2j32LxkT4AFAnAl/8s5G0AAAAAElFTkSuQmCC",
                blurWidth: 8,
                blurHeight: 8
            }
        },
        40143: function(n, t, e) {
            var i = e(26042),
                a = e(69396),
                r = e(7297),
                o = e(85893),
                u = e(186),
                c = e(85417);

            function s() {
                var n = (0, r.Z)(["\n\tmargin: 0 auto;\n\tmargin-top: 72px;\n"]);
                return s = function() {
                    return n
                }, n
            }

            function l() {
                var n = (0, r.Z)(["\n\tmargin-top: 8px;\n\tfont-size: 20px;\n\tfont-weight: 500;\n\ttext-align: center;\n\tpadding-left: 8px;\n"]);
                return l = function() {
                    return n
                }, n
            }

            function d() {
                var n = (0, r.Z)(["\n\twidth: 120px;\n\theight: 120px;\n\t-webkit-animation: spin 3s linear infinite;\n\t-moz-animation: spin 3s linear infinite;\n\tanimation: spin 3s linear infinite;\n\t@-moz-keyframes spin {\n\t\t100% {\n\t\t\t-moz-transform: rotate(360deg);\n\t\t}\n\t}\n\t@-webkit-keyframes spin {\n\t\t100% {\n\t\t\t-webkit-transform: rotate(360deg);\n\t\t}\n\t}\n\t@keyframes spin {\n\t\t100% {\n\t\t\t-webkit-transform: rotate(360deg);\n\t\t\ttransform: rotate(360deg);\n\t\t}\n\t}\n"]);
                return d = function() {
                    return n
                }, n
            }
            var p = u.ZP.div.withConfig({
                    componentId: "sc-e2e9d7df-0"
                })(s()),
                m = u.ZP.div.withConfig({
                    componentId: "sc-e2e9d7df-1"
                })(l()),
                f = u.ZP.img.withConfig({
                    componentId: "sc-e2e9d7df-2"
                })(d());
            t.Z = function(n) {
                return (0, o.jsxs)(p, (0, a.Z)((0, i.Z)({}, n), {
                    children: [(0, o.jsx)(f, {
                        src: c.Z.src
                    }), (0, o.jsx)(m, {
                        children: "Loading..."
                    })]
                }))
            }
        },
        51175: function(n, t, e) {
            e.d(t, {
                Z: function() {
                    return T
                }
            });
            var i = e(26042),
                a = e(69396),
                r = e(99534),
                o = e(7297),
                u = e(85893),
                c = (e(67294), e(9008)),
                s = e.n(c),
                l = e(186),
                d = 50.75,
                p = 87.5;

            function m() {
                var n = (0, o.Z)(["\n\tbody, #__next {\n\t\tbackground-color: ", ";\n\t}\n\n  #__next {\n    display: flex;\n    flex-direction: column;\n    width: 100%;\n    min-height: 100%;\n    position: relative;\n    color: ", ";\n    isolation: isolate;\n\n    ", " {\n      flex-direction: row;\n    }\n  }\n\n  a, input, button, textarea, select {\n    &:focus-visible {\n      outline: 1px solid ", ";\n    }\n  }\n\n  .visually-hidden {\n    position: absolute;\n    width: 1px;\n    height: 1px;\n    padding: 0;\n    margin: -1px;\n    overflow: hidden;\n    clip: rect(0, 0, 0, 0);\n    white-space: nowrap;\n    border-width: 0;\n  }\n\n\t.tooltip-trigger {\n\t\tcolor: ", ";\n\t\tdisplay: flex;\n\t\talign-items: center;\n\t\tpadding: 0;\n\n\t\t:focus-visible {\n\t\t\toutline-offset: 2px;\n\t\t}\n\t}\n\n\t.tooltip-trigger a {\n\t\tdisplay: flex;\n\t}\n"]);
                return m = function() {
                    return n
                }, n
            }

            function f(n) {
                var t = n.children;
                return (0, u.jsx)(l.f6, {
                    theme: y("dark"),
                    children: t
                })
            }
            var h = function(n, t) {
                    return new URLSearchParams(window.location.search).get(n) || t
                },
                y = function(n) {
                    return {
                        mode: n ? "dark" : "light",
                        text1: n ? h("text1", "#FAFAFA") : "#1F1F1F",
                        text2: n ? h("text2", "#C3C5CB") : "#565A69",
                        text3: n ? h("text3", "#6C7284") : "#888D9B",
                        text4: n ? h("text4", "#565A69") : "#C3C5CB",
                        text5: n ? h("text5", "#2C2F36") : "#EDEEF2",
                        white: "#FFFFFF",
                        bg1: n ? h("bg1", "#212429") : "#FAFAFA",
                        bg2: n ? h("bg2", "#2C2F36") : "#F7F8FA",
                        bg3: n ? h("bg3", "#40444F") : "#EDEEF2",
                        bg4: n ? h("bg4", "#565A69") : "#CED0D9",
                        bg5: n ? h("bg5", "#565A69") : "#888D9B",
                        bg6: n ? h("bg6", "rgb(20 22 25)") : "#FFFFFF",
                        bg7: n ? h("bg7", "rgba(7,14,15,0.7)") : "rgba(252,252,251,1)",
                        background: n ? h("background", "#22242A") : "#ffffff",
                        advancedBG: n ? h("advancedBG", "rgba(0,0,0,0.1)") : "rgba(255,255,255,0.4)",
                        divider: n ? h("divider", "rgba(43, 43, 43, 0.435)") : "rgba(43, 43, 43, 0.035)",
                        primary1: n ? h("primary1", "#2172E5") : "#445ed0",
                        red1: h("red1", "#FF6871"),
                        green1: h("green1", "#27AE60"),
                        link: h("link", "#2172E5"),
                        blue: h("blue", "#2f80ed"),
                        shadowSm: "0 1px 2px 0 rgb(0 0 0 / 0.05)",
                        shadow: "0 1px 3px 0 rgb(0 0 0 / 0.1), 0 1px 2px -1px rgb(0 0 0 / 0.1)",
                        shadowMd: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
                        shadowLg: "0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1)",
                        bpSm: "".concat(30, "rem"),
                        bpMed: "".concat(d, "rem"),
                        bpLg: "".concat(64, "rem"),
                        bpXl: "".concat(p, "rem"),
                        bp2Xl: "".concat(96, "rem"),
                        maxSm: "@media screen and (max-width: ".concat(30, "rem)"),
                        maxMed: "@media screen and (max-width: ".concat(d, "rem)"),
                        maxLg: "@media screen and (max-width: ".concat(64, "rem)"),
                        maxXl: "@media screen and (max-width: ".concat(p, "rem)"),
                        minSm: "@media screen and (min-width: ".concat(30, "rem)"),
                        minMed: "@media screen and (min-width: ".concat(d, "rem)"),
                        minLg: "@media screen and (min-width: ".concat(64, "rem)"),
                        minXl: "@media screen and (min-width: ".concat(p, "rem)"),
                        min2Xl: "@media screen and (min-width: ".concat(96, "rem)"),
                        breakpoints: ["".concat(30, "rem"), "".concat(d, "rem"), "".concat(64, "rem"), "".concat(p, "rem")]
                    }
                },
                v = (0, l.vJ)(m(), (function(n) {
                    return n.theme.background
                }), (function(n) {
                    return n.theme.text1
                }), (function(n) {
                    return n.theme.minLg
                }), (function(n) {
                    return n.theme.text1
                }), (function(n) {
                    return n.theme.text1
                })),
                g = e(99655),
                b = function() {
                    return (0, u.jsxs)(g.bZ, {
                        status: "warning",
                        justifyContent: "center",
                        fontWeight: "bold",
                        display: ["none", "none", "flex", "flex"],
                        children: [(0, u.jsx)(g.zM, {
                            mr: "4px"
                        }), "Please make sure you are on swap.defillama.com - check the URL carefully."]
                    })
                };

            function x() {
                var n = (0, o.Z)(["\n\tflex: 1;\n\tdisplay: flex;\n\tflex-direction: column;\n\tmargin: 16px;\n\tisolation: isolate;\n\n\t@media screen and (min-width: ", ") {\n\t\tmargin: 28px;\n\t}\n"]);
                return x = function() {
                    return n
                }, n
            }

            function A() {
                var n = (0, o.Z)(["\n\tflex: 1;\n\tdisplay: flex;\n\tflex-direction: column;\n\tgap: 28px;\n\twidth: 100%;\n\tmin-height: 100%;\n\tmargin: 0 auto;\n\tcolor: ", ";\n"]);
                return A = function() {
                    return n
                }, n
            }
            var w = l.ZP.div.withConfig({
                    componentId: "sc-889ee977-0"
                })(x(), (function(n) {
                    return n.theme.bpLg
                })),
                k = l.ZP.main.withConfig({
                    componentId: "sc-889ee977-1"
                })(A(), (function(n) {
                    return n.theme.text1
                }));

            function T(n) {
                var t = n.title,
                    e = n.children,
                    o = (0, r.Z)(n, ["title", "children"]);
                return (0, u.jsxs)(u.Fragment, {
                    children: [(0, u.jsx)(s(), {
                        children: (0, u.jsx)("title", {
                            children: t
                        })
                    }), (0, u.jsx)(b, {}), (0, u.jsxs)(f, {
                        children: [(0, u.jsx)(v, {}), (0, u.jsx)(w, {
                            children: (0, u.jsx)(k, (0, a.Z)((0, i.Z)({}, o), {
                                children: e
                            }))
                        })]
                    })]
                })
            }
        },
        20047: function(n, t, e) {
            e.d(t, {
                R: function() {
                    return y
                }
            });
            var i = e(47568),
                a = e(26042),
                r = e(828),
                o = e(70655),
                u = e(17e3),
                c = e(47787),
                s = e(38673),
                l = "0x0000000000000000000000000000000000000000";

            function d(n) {
                return "gnosis" === n ? "xdai" : n
            }
            var p = function(n, t) {
                var e = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                    i = new AbortController,
                    r = fetch(n, (0, a.Z)({
                        signal: i.signal
                    }, e)),
                    o = setTimeout((function() {
                        return i.abort()
                    }), t);
                return r.finally((function() {
                    return clearTimeout(o)
                }))
            };

            function m(n) {
                return f.apply(this, arguments)
            }

            function f() {
                return (f = (0, i.Z)((function(n) {
                    var t, e, i, a, r, u, s, m, f, h, y, v, g, b, x, A, w, k;
                    return (0, o.__generator)(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                t = n.chain, e = n.fromToken, i = n.toToken, o.label = 1;
                            case 1:
                                return o.trys.push([1, 5, , 6]), [4, Promise.allSettled([p("https://api.coingecko.com/api/v3/simple/price?ids=".concat(c.r8[t], "&vs_currencies=usd"), 600).then((function(n) {
                                    return n.json()
                                })), p("https://api.coingecko.com/api/v3/simple/token_price/".concat(c.LD[t], "?contract_addresses=").concat(e, "%2C").concat(i, "&vs_currencies=usd"), 600).then((function(n) {
                                    return n.json()
                                }))])];
                            case 2:
                                return "fulfilled" === (s = o.sent())[0].status && (a = null === (m = s[0].value) || void 0 === m || null === (f = m[c.r8[t]]) || void 0 === f ? void 0 : f.usd, r = e === l ? a : void 0, u = i === l ? a : void 0), "fulfilled" === s[1].status && (r = r || (null === (h = s[1].value[e]) || void 0 === h ? void 0 : h.usd), u = u || (null === (y = s[1].value[i]) || void 0 === y ? void 0 : y.usd)), v = [], g = d(t), a || v.push("".concat(g, ":").concat(l)), r || v.push("".concat(g, ":").concat(e)), u || v.push("".concat(g, ":").concat(i)), v.length > 0 ? [4, fetch("https://coins.llama.fi/prices/current/".concat(v.join(","))).then((function(n) {
                                    return n.json()
                                }))] : [3, 4];
                            case 3:
                                w = o.sent().coins, a = a || (null === (b = w["".concat(g, ":").concat(l)]) || void 0 === b ? void 0 : b.price), r = r || (null === (x = w["".concat(g, ":").concat(e)]) || void 0 === x ? void 0 : x.price), u = u || (null === (A = w["".concat(g, ":").concat(i)]) || void 0 === A ? void 0 : A.price), o.label = 4;
                            case 4:
                                return [2, {
                                    gasTokenPrice: a,
                                    fromTokenPrice: r,
                                    toTokenPrice: u
                                }];
                            case 5:
                                return k = o.sent(), console.log(k), [2, {
                                    gasTokenPrice: a,
                                    fromTokenPrice: r,
                                    toTokenPrice: u
                                }];
                            case 6:
                                return [2]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function h() {
                return (h = (0, i.Z)((function(n) {
                    var t, e, i, a, u, c, l, p, f, h, y;
                    return (0, o.__generator)(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                t = n.chain, e = n.fromToken, i = n.toToken, o.label = 1;
                            case 1:
                                return o.trys.push([1, 3, , 4]), e && i && t ? (a = d(t), [4, Promise.all([m({
                                    chain: t,
                                    fromToken: e,
                                    toToken: i
                                }), s.a[a].getFeeData()])]) : [2, {}];
                            case 2:
                                return u = r.Z.apply(void 0, [o.sent(), 2]), c = u[0], l = c.gasTokenPrice, p = c.fromTokenPrice, f = c.toTokenPrice, h = u[1], [2, {
                                    gasTokenPrice: l,
                                    fromTokenPrice: p,
                                    toTokenPrice: f,
                                    gasPriceData: h
                                }];
                            case 3:
                                return y = o.sent(), console.log(y), [2, {}];
                            case 4:
                                return [2]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function y(n) {
                var t = n.chain,
                    e = n.fromToken,
                    i = n.toToken,
                    r = n.skipRefetch;
                return (0, u.a)(["gasPrice", t, e, i], (function() {
                    return function(n) {
                        return h.apply(this, arguments)
                    }({
                        chain: t,
                        fromToken: e,
                        toToken: i
                    })
                }), (0, a.Z)({}, r ? {
                    refetchOnMount: !1,
                    refetchInterval: 3e5,
                    refetchOnWindowFocus: !1,
                    refetchOnReconnect: !1,
                    refetchIntervalInBackground: !1
                } : {
                    refetchInterval: 2e4
                }))
            }
        },
        4385: function(n, t, e) {
            e.d(t, {
                DA: function() {
                    return f
                },
                Yu: function() {
                    return h
                },
                N4: function() {
                    return v
                }
            });
            var i = e(47568),
                a = e(70655),
                r = e(28375),
                o = e(96486),
                u = e(35324),
                c = e(64146),
                s = e(38673),
                l = [{
                    inputs: [{
                        internalType: "address",
                        name: "_owner",
                        type: "address"
                    }],
                    stateMutability: "nonpayable",
                    type: "constructor"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "DecimalsUpdated",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "GasPriceUpdated",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "L1BaseFeeUpdated",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "OverheadUpdated",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "previousOwner",
                        type: "address"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "newOwner",
                        type: "address"
                    }],
                    name: "OwnershipTransferred",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "ScalarUpdated",
                    type: "event"
                }, {
                    inputs: [],
                    name: "decimals",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "gasPrice",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "bytes",
                        name: "_data",
                        type: "bytes"
                    }],
                    name: "getL1Fee",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "bytes",
                        name: "_data",
                        type: "bytes"
                    }],
                    name: "getL1GasUsed",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "l1BaseFee",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "overhead",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "owner",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "renounceOwnership",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    name: "scalar",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_decimals",
                        type: "uint256"
                    }],
                    name: "setDecimals",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_gasPrice",
                        type: "uint256"
                    }],
                    name: "setGasPrice",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_baseFee",
                        type: "uint256"
                    }],
                    name: "setL1BaseFee",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_overhead",
                        type: "uint256"
                    }],
                    name: "setOverhead",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_scalar",
                        type: "uint256"
                    }],
                    name: "setScalar",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "address",
                        name: "newOwner",
                        type: "address"
                    }],
                    name: "transferOwnership",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }],
                d = "0x420000000000000000000000000000000000000F",
                p = function() {
                    var n = (0, i.Z)((function(n) {
                        var t, e, i;
                        return (0, a.__generator)(this, (function(a) {
                            switch (a.label) {
                                case 0:
                                    t = s.a.optimism, e = new c.CH(d, l, t), a.label = 1;
                                case 1:
                                    return a.trys.push([1, 3, , 4]), [4, e.getL1Fee(n)];
                                case 2:
                                    return [2, a.sent() / 1e18];
                                case 3:
                                    return i = a.sent(), console.log(i), [2, "Unknown"];
                                case 4:
                                    return [2]
                            }
                        }))
                    }));
                    return function(t) {
                        return n.apply(this, arguments)
                    }
                }(),
                m = e(59067),
                f = 25e3;

            function h(n) {
                return y.apply(this, arguments)
            }

            function y() {
                return (y = (0, i.Z)((function(n) {
                    var t, e, i, r, c, s, l, d, f, h, y, v, g, b, x, A, w;
                    return (0, a.__generator)(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                if (t = n.adapter, e = n.chain, i = n.from, r = n.to, c = n.amount, s = n.extra, l = void 0 === s ? {} : s, !e || !i || !r || !c && !l.amountOut || "0" === c && "0" === l.amountOut) return [2, {
                                    price: null,
                                    name: t.name,
                                    airdrop: !t.token,
                                    fromAmount: c,
                                    txData: "",
                                    l1Gas: 0,
                                    tx: {},
                                    isOutputAvailable: !1
                                }];
                                a.label = 1;
                            case 1:
                                return a.trys.push([1, 9, , 10]), h = l.amountOut && "0" !== l.amountOut, v = c, g = l.isPrivacyEnabled || m.cn[t.name] ? (0, o.partial)(u.T, t.name) : t.getQuote, t.isOutputAvailable ? [4, g(e, i, r, c, l)] : [3, 3];
                            case 2:
                                return y = a.sent(), v = y.amountIn, [3, 6];
                            case 3:
                                return !h || t.isOutputAvailable ? [3, 4] : [2, {
                                    price: null,
                                    name: t.name,
                                    airdrop: !t.token,
                                    fromAmount: c,
                                    txData: "",
                                    l1Gas: 0,
                                    tx: {},
                                    isOutputAvailable: !1
                                }];
                            case 4:
                                return [4, g(e, i, r, c, l)];
                            case 5:
                                y = a.sent(), a.label = 6;
                            case 6:
                                if (!v) throw Error("amountIn is not defined");
                                return x = null !== (b = null === t || void 0 === t || null === (d = t.getTxData) || void 0 === d ? void 0 : d.call(t, y)) && void 0 !== b ? b : "", A = 0, "optimism" !== e ? [3, 8] : [4, p(x)];
                            case 7:
                                A = a.sent(), a.label = 8;
                            case 8:
                                return [2, {
                                    price: y,
                                    l1Gas: A,
                                    txData: x,
                                    tx: null === t || void 0 === t || null === (f = t.getTx) || void 0 === f ? void 0 : f.call(t, y),
                                    name: t.name,
                                    airdrop: !t.token,
                                    fromAmount: v,
                                    isOutputAvailable: t.isOutputAvailable
                                }];
                            case 9:
                                return w = a.sent(), console.error(w), [2, {
                                    price: null,
                                    l1Gas: 0,
                                    name: t.name,
                                    airdrop: !t.token,
                                    fromAmount: c,
                                    txData: "",
                                    tx: {},
                                    isOutputAvailable: !1
                                }];
                            case 10:
                                return [2]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function v(n) {
                var t, e, i, a, u, c = n.chain,
                    s = n.from,
                    l = n.to,
                    d = n.amount,
                    p = n.extra,
                    y = void 0 === p ? {} : p,
                    v = n.disabledAdapters,
                    g = void 0 === v ? [] : v,
                    b = n.customRefetchInterval,
                    x = (0, r.h)({
                        queries: m.j$.filter((function(n) {
                            return void 0 !== n.chainToId[c] && !g.includes(n.name)
                        })).map((function(n) {
                            return {
                                queryKey: ["routes", n.name, c, s, l, d, JSON.stringify((0, o.omit)(y, "amount"))],
                                queryFn: function() {
                                    return h({
                                        adapter: n,
                                        chain: c,
                                        from: s,
                                        to: l,
                                        amount: d,
                                        extra: y
                                    })
                                },
                                refetchInterval: b || f,
                                refetchOnWindowFocus: !1,
                                refetchIntervalInBackground: !1
                            }
                        }))
                    }),
                    A = null !== (e = null === x || void 0 === x ? void 0 : x.filter((function(n) {
                        return "success" === n.status
                    }))) && void 0 !== e ? e : [],
                    w = null !== (i = null === x || void 0 === x ? void 0 : x.filter((function(n) {
                        return "success" === n.status && !!n.data && n.data.price
                    }))) && void 0 !== i ? i : [],
                    k = null !== (a = null === (t = null === x || void 0 === x ? void 0 : x.map((function(n, t) {
                        return [m.j$[t].name, n]
                    }))) || void 0 === t ? void 0 : t.filter((function(n) {
                        return "loading" === n[1].status
                    }))) && void 0 !== a ? a : [];
                return {
                    isLoaded: 0 === k.length,
                    isLoading: !(A.length >= 1),
                    data: null !== (u = null === w || void 0 === w ? void 0 : w.map((function(n) {
                        return n.data
                    }))) && void 0 !== u ? u : [],
                    refetch: function() {
                        return null === x || void 0 === x ? void 0 : x.forEach((function(n) {
                            return n.refetch()
                        }))
                    },
                    lastFetched: (0, o.first)(A.filter((function(n) {
                        return n.isSuccess && !n.isFetching && n.dataUpdatedAt > 0
                    })).sort((function(n, t) {
                        return n.dataUpdatedAt - t.dataUpdatedAt
                    })).map((function(n) {
                        return n.dataUpdatedAt
                    }))) || null,
                    loadingRoutes: k
                }
            }
        }
    }
]);