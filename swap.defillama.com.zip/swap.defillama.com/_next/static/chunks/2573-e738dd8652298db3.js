"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [2573], {
        35530: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.default = {
                "erc20:symbol": {
                    constant: !0,
                    inputs: [],
                    name: "symbol",
                    outputs: [{
                        internalType: "string",
                        name: "",
                        type: "string"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                },
                "erc20:decimals": {
                    constant: !0,
                    inputs: [],
                    name: "decimals",
                    outputs: [{
                        internalType: "uint8",
                        name: "",
                        type: "uint8"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                },
                "erc20:balanceOf": {
                    constant: !0,
                    inputs: [{
                        internalType: "address",
                        name: "account",
                        type: "address"
                    }],
                    name: "balanceOf",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                },
                "erc20:totalSupply": {
                    constant: !0,
                    inputs: [],
                    name: "totalSupply",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    payable: !1,
                    stateMutability: "view",
                    type: "function"
                }
            }
        },
        13724: function(t, e, r) {
            var n = this && this.__assign || function() {
                    return n = Object.assign || function(t) {
                        for (var e, r = 1, n = arguments.length; r < n; r++)
                            for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                        return t
                    }, n.apply(this, arguments)
                },
                o = this && this.__spreadArray || function(t, e, r) {
                    if (r || 2 === arguments.length)
                        for (var n, o = 0, a = e.length; o < a; o++) !n && o in e || (n || (n = Array.prototype.slice.call(e, 0, o)), n[o] = e[o]);
                    return t.concat(n || Array.prototype.slice.call(e))
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var a = r(833);

            function i(t) {
                return a.BigNumber.isBigNumber(t) || "number" === typeof t
            }

            function s(t) {
                var e = n({}, t);
                return Array.isArray(t) && (e = o([], t, !0)), Object.keys(t).forEach((function(r) {
                    i(t[r]) ? e[r] = t[r].toString() : "object" === typeof t[r] ? e[r] = s(t[r]) : e[r] = t[r]
                })), e
            }
            e.default = function(t) {
                var e;
                return "string" === typeof t || "boolean" === typeof t ? t : i(t) ? t.toString() : (e = s(t)) instanceof Array && 1 === e.length ? e[0] : e
            }
        },
        62573: function(t, e, r) {
            var n = r(83454),
                o = this && this.__assign || function() {
                    return o = Object.assign || function(t) {
                        for (var e, r = 1, n = arguments.length; r < n; r++)
                            for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                        return t
                    }, o.apply(this, arguments)
                },
                a = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                i = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                },
                s = this && this.__spreadArray || function(t, e, r) {
                    if (r || 2 === arguments.length)
                        for (var n, o = 0, a = e.length; o < a; o++) !n && o in e || (n || (n = Array.prototype.slice.call(e, 0, o)), n[o] = e[o]);
                    return t.concat(n || Array.prototype.slice.call(e))
                },
                c = this && this.__importDefault || function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.multiCall = e.call = void 0;
            var u = c(r(35530)),
                l = r(63239),
                h = r(36142),
                p = c(r(94987)),
                f = c(r(13724)),
                d = r(33705),
                m = r(46507),
                b = ["string", "address", "bool", "int", "int8", "int16", "int32", "int64", "int128", "int256", "uint", "uint8", "uint16", "uint32", "uint64", "uint128", "uint256"];
            s([], b, !0).forEach((function(t) {
                return b.push(t + "[]")
            }));
            var v = n.env.SDK_MULTICALL_CHUNK_SIZE ? +n.env.SDK_MULTICALL_CHUNK_SIZE : 500;

            function y(t) {
                var e = t;
                if ("string" === typeof e && void 0 === (e = u.default[e])) {
                    var r = t.split(":"),
                        n = r[0],
                        a = r[1];
                    if (!b.includes(n) || !a) {
                        var i = new l.ethers.utils.Interface([t]).format(l.ethers.utils.FormatTypes.json);
                        return JSON.parse(i)[0]
                    }
                    e = {
                        constant: !0,
                        inputs: [],
                        name: a,
                        outputs: [{
                            internalType: n,
                            name: "",
                            type: n
                        }],
                        payable: !1,
                        stateMutability: "view",
                        type: "function"
                    }
                }
                return o({
                    type: "function"
                }, e)
            }

            function k(t) {
                return void 0 === t ? [] : "object" === typeof t ? t : [t]
            }

            function g(t) {
                var e = t.block;
                if ("string" === typeof e && "latest" !== e) {
                    if (e = +e, isNaN(e)) throw new Error("Invalid block: " + t.block);
                    t.block = e
                }
            }
            e.call = function(t) {
                var e;
                return a(this, void 0, void 0, (function() {
                    var r, n, o, a, s, c, u;
                    return i(this, (function(i) {
                        switch (i.label) {
                            case 0:
                                return g(t), r = y(t.abi), n = k(t.params), o = new l.ethers.utils.Interface([r]), a = l.ethers.utils.FunctionFragment.from(r), s = o.encodeFunctionData(a, n), [4, (0, h.getProvider)(t.chain).call({
                                    to: t.target,
                                    data: s
                                }, null !== (e = t.block) && void 0 !== e ? e : "latest")];
                            case 1:
                                return c = i.sent(), u = o.decodeFunctionResult(a, c), [2, {
                                    output: (0, f.default)(u)
                                }]
                        }
                    }))
                }))
            }, e.multiCall = function(t) {
                var e, r;
                return a(this, void 0, void 0, (function() {
                    var n, o, a, s, c, u, l;
                    return i(this, (function(i) {
                        switch (i.label) {
                            case 0:
                                if (g(t), n = null !== (e = t.chain) && void 0 !== e ? e : "ethereum", !t.calls) throw new Error("Missing calls parameter");
                                if (t.target && !t.target.startsWith("0x")) throw new Error("Invalid target: " + t.target);
                                return t.calls.length ? (o = t.chunkSize, t.chunkSize || (o = v), a = y(t.abi), s = t.calls.map((function(e) {
                                    var r;
                                    return {
                                        params: k(e.params),
                                        contract: null !== (r = e.target) && void 0 !== r ? r : t.target
                                    }
                                })), [4, (0, m.runInPromisePool)({
                                    items: (0, m.sliceIntoChunks)(s, o),
                                    concurrency: 20,
                                    processor: function(e) {
                                        return (0, p.default)(a, e, n, t.block)
                                    }
                                })]) : [2, {
                                    output: []
                                }];
                            case 1:
                                return c = i.sent(), u = [].concat.apply([], c), (l = u.filter((function(t) {
                                    return !t.success
                                }))).length && (0, d.debugLog)("[chain: ".concat(null !== (r = t.chain) && void 0 !== r ? r : "ethereum", "] Failed multicalls:"), l.map((function(t) {
                                    return t.input
                                }))), [2, {
                                    output: u
                                }]
                        }
                    }))
                }))
            }
        },
        94987: function(t, e, r) {
            var n = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                o = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                },
                a = this && this.__importDefault || function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.networkSupportsMulticall = e.AGGREGATE_SELECTOR = e.MULTICALL_ADDRESS_OPTIMISM = e.MULTICALL_ADDRESS_AURORA = e.MULTICALL_ADDRESS_MOONRIVER = e.MULTICALL_ADDRESS_AVAX = e.MULTICALL_ADDRESS_ARBITRUM = e.MULTICALL_ADDRESS_HARMONY = e.MULTICALL_ADDRESS_HECO = e.MULTICALL_ADDRESS_XDAI = e.MULTICALL_ADDRESS_FANTOM = e.MULTICALL_ADDRESS_BSC = e.MULTICALL_ADDRESS_POLYGON = e.MULTICALL_ADDRESS_GOERLI = e.MULTICALL_ADDRESS_RINKEBY = e.MULTICALL_ADDRESS_KOVAN = e.MULTICALL_ADDRESS_MAINNET = void 0;
            var i = r(63239),
                s = r(56371),
                c = r(36142),
                u = a(r(13724)),
                l = r(44764),
                h = r(33705),
                p = r(46507);

            function f(t, r, a) {
                return n(this, void 0, void 0, (function() {
                    var u, b, v, y, k, g, w, _, E = this;
                    return o(this, (function(A) {
                        switch (A.label) {
                            case 0:
                                if (!m(r)) return [3, 7];
                                A.label = 1;
                            case 1:
                                return A.trys.push([1, 4, , 7]), u = i.ethers.utils.defaultAbiCoder.encode([s.ParamType.fromObject({
                                    components: [{
                                        name: "target",
                                        type: "address"
                                    }, {
                                        name: "callData",
                                        type: "bytes"
                                    }],
                                    name: "data",
                                    type: "tuple[]"
                                })], [t.map((function(t) {
                                    return [t.to, t.data]
                                }))]), [4, d(r)];
                            case 2:
                                return b = A.sent(), v = e.AGGREGATE_SELECTOR + u.substr(2), y = {
                                    to: b,
                                    data: v
                                }, [4, (0, l.call)((0, c.getProvider)(r), y, null !== a && void 0 !== a ? a : "latest", r)];
                            case 3:
                                return k = A.sent(), g = i.ethers.utils.defaultAbiCoder.decode(["uint256", "bytes[]"], k), g[0], [2, g[1]];
                            case 4:
                                return A.sent(), t.length > 10 ? (w = Math.ceil(t.length / 5), _ = (0, p.sliceIntoChunks)(t, w), (0, h.debugLog)("Multicall failed, call size: ".concat(t.length, ", splitting into smaller chunks and trying again, new call size: ").concat(_[0].length)), [4, (0, p.runInPromisePool)({
                                    items: _,
                                    concurrency: 2,
                                    processor: function(t) {
                                        return f(t, r, a)
                                    }
                                })]) : [3, 6];
                            case 5:
                                return [2, A.sent().flat()];
                            case 6:
                                return (0, h.debugLog)("Multicall failed, defaulting to single transactions..."), [3, 7];
                            case 7:
                                return [2, (0, p.runInPromisePool)({
                                    items: t,
                                    concurrency: m(r) ? 2 : 10,
                                    processor: function(t) {
                                        var e = t.to,
                                            i = t.data;
                                        return n(E, void 0, void 0, (function() {
                                            var t, n;
                                            return o(this, (function(o) {
                                                switch (o.label) {
                                                    case 0:
                                                        t = null, o.label = 1;
                                                    case 1:
                                                        return o.trys.push([1, 3, , 4]), [4, (0, l.call)((0, c.getProvider)(r), {
                                                            to: e,
                                                            data: i
                                                        }, null !== a && void 0 !== a ? a : "latest", r)];
                                                    case 2:
                                                        return t = o.sent(), [3, 4];
                                                    case 3:
                                                        return n = o.sent(), (0, h.debugLog)(n), [3, 4];
                                                    case 4:
                                                        return [2, t]
                                                }
                                            }))
                                        }))
                                    }
                                })]
                        }
                    }))
                }))
            }

            function d(t) {
                return n(this, void 0, void 0, (function() {
                    var e, r, n;
                    return o(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                return [4, (0, c.getProvider)(t).getNetwork()];
                            case 1:
                                if (e = o.sent(), null === (r = b(e.chainId))) throw n = "multicall is not available on the network ".concat(e.chainId), console.error(n), new Error(n);
                                return [2, r]
                        }
                    }))
                }))
            }

            function m(t) {
                return null !== b((0, c.getProvider)(t).network.chainId)
            }

            function b(t) {
                switch (t) {
                    case 1:
                    case 10001:
                        return e.MULTICALL_ADDRESS_MAINNET;
                    case 42:
                        return e.MULTICALL_ADDRESS_KOVAN;
                    case 4:
                        return e.MULTICALL_ADDRESS_RINKEBY;
                    case 5:
                        return e.MULTICALL_ADDRESS_GOERLI;
                    case 137:
                        return e.MULTICALL_ADDRESS_POLYGON;
                    case 56:
                        return e.MULTICALL_ADDRESS_BSC;
                    case 250:
                        return e.MULTICALL_ADDRESS_FANTOM;
                    case 100:
                        return e.MULTICALL_ADDRESS_XDAI;
                    case 128:
                        return e.MULTICALL_ADDRESS_HECO;
                    case 16666e5:
                        return e.MULTICALL_ADDRESS_HARMONY;
                    case 42161:
                        return e.MULTICALL_ADDRESS_ARBITRUM;
                    case 43114:
                        return e.MULTICALL_ADDRESS_AVAX;
                    case 1285:
                        return e.MULTICALL_ADDRESS_MOONRIVER;
                    case 1313161554:
                        return e.MULTICALL_ADDRESS_AURORA;
                    case 10:
                        return e.MULTICALL_ADDRESS_OPTIMISM;
                    case 25:
                        return "0x5e954f5972EC6BFc7dECd75779F10d848230345F";
                    case 288:
                        return "0x80Ae459D058436ecB4e043ac48cfd209B578CBF0";
                    case 43288:
                        return "0x92C5b5B66988E6B8931a8CD3faa418b42003DF2F";
                    case 56288:
                        return "0x31cCe73DA4365342bd081F6a748AAdb7c7a49b7E";
                    case 4689:
                        return "0x5a6787fc349665c5b0c4b93126a0b62f14935731";
                    case 82:
                        return "0x59177c9e5d0488e21355816094a047bdf8f14ebe";
                    case 11297108109:
                        return "0xfFE2FF36c5b8D948f788a34f867784828aa7415D";
                    case 416:
                        return "0x834a005DDCF990Ba1a79f259e840e58F2D14F49a";
                    case 246:
                    case 336:
                    case 592:
                    case 269:
                    case 321:
                    case 20:
                    case 122:
                    case 42220:
                    case 42262:
                    case 39797:
                    case 1284:
                    case 30:
                    case 1088:
                    case 1e4:
                    case 2001:
                    case 9001:
                    case 106:
                    case 888:
                    case 24:
                    case 108:
                    case 361:
                    case 57:
                    case 61:
                    case 70:
                    case 61:
                    case 60:
                    case 66:
                    case 19:
                    case 1030:
                    case 333999:
                    case 7700:
                    case 62621:
                    case 9e5:
                    case 1231:
                    case 2152:
                    case 50:
                    case 52:
                        return "0x18fA376d92511Dd04090566AB6144847c03557d8";
                    case 40:
                        return "0x74D01B798F0aEdc39548D3EA5fC922B291293b95";
                    case 2222:
                        return "0x30A62aA52Fa099C4B227869EB6aeaDEda054d121";
                    case 47805:
                        return "0x9eE9904815B80C39C1a27294E69a8626EAa7952d";
                    case 87:
                        return "0x7A5a7579eb8DdEd352848cFDD0a5530C4e56FF7f";
                    case 32520:
                        return "0x5AE90c229d7A8AFc12bFa263AC672548aEb1D765";
                    case 820:
                    case 199:
                        return "0xB2fB6dA40DF36CcFFDc3B0F99df4871C7b86FCe7";
                    case 2e3:
                        return "0x8856C24Ba82F737CFb99Ec4785CEe4d48A842F33";
                    case 71402:
                    case 8217:
                        return "0xcA11bde05977b3631167028862bE2a173976CA11";
                    case 96:
                        return "0xcc515Aa7eE9Be4491c98DE68ee2147F0A063759D";
                    case 42170:
                        return "0x2fe78f55c39dc437c4c025f8a1ffc54edb4a34c3";
                    case 55555:
                        return "0x5CCBA81867AE1F9d470a9514fb9B175E84D47979";
                    case 530:
                        return "0xC43a7181654639556e4caca1bf9219C14a106401";
                    case 1818:
                        return "0x28d2ebdb36369db1c51355cdc0898754d1a1c3c5";
                    case 1234:
                        return "0x176CcFFbAB792Aaa0da7C430FE20a7106d969f66";
                    case 53935:
                        return "0x5b24224dC16508DAD755756639E420817DD4c99E";
                    case 3e3:
                        return "0xe6d0cEE385992029Cb64C94A2dF6d0331937B2C8";
                    case 55:
                        return "0xd0dd5446f58D6f4F4A669f289E4268c1b12AEc31";
                    case 420420:
                        return "0x781bB181833986C78238228F9AF0891829AF922B";
                    case 2002:
                        return "0x61EEE5a6c13c358101487f3b7c7Dd9863590C350";
                    case 20402:
                        return "0xF8D7509aD8570b16dAd163A3841684f660fD9242";
                    case 14:
                        return "0x336897CAe2791048DA77EEa2A43BFB96342b9CE1";
                    case 383414847825:
                        return "0x23c65A0E1aF27EFd46B60c43998682e1e322C6f6";
                    default:
                        return null
                }
            }
            e.MULTICALL_ADDRESS_MAINNET = "0xeefba1e63905ef1d7acba5a8513c70307c1ce441", e.MULTICALL_ADDRESS_KOVAN = "0x2cc8688c5f75e365aaeeb4ea8d6a480405a48d2a", e.MULTICALL_ADDRESS_RINKEBY = "0x42ad527de7d4e9d9d011ac45b31d8551f8fe9821", e.MULTICALL_ADDRESS_GOERLI = "0x77dca2c955b15e9de4dbbcf1246b4b85b651e50e", e.MULTICALL_ADDRESS_POLYGON = "0x95028E5B8a734bb7E2071F96De89BABe75be9C8E", e.MULTICALL_ADDRESS_BSC = "0x1Ee38d535d541c55C9dae27B12edf090C608E6Fb", e.MULTICALL_ADDRESS_FANTOM = "0xb828C456600857abd4ed6C32FAcc607bD0464F4F", e.MULTICALL_ADDRESS_XDAI = "0xb5b692a88BDFc81ca69dcB1d924f59f0413A602a", e.MULTICALL_ADDRESS_HECO = "0xc9a9F768ebD123A00B52e7A0E590df2e9E998707", e.MULTICALL_ADDRESS_HARMONY = "0xFE4980f62D708c2A84D3929859Ea226340759320", e.MULTICALL_ADDRESS_ARBITRUM = "0x842eC2c7D803033Edf55E478F461FC547Bc54EB2", e.MULTICALL_ADDRESS_AVAX = "0xdf2122931FEb939FB8Cf4e67Ea752D1125e18858", e.MULTICALL_ADDRESS_MOONRIVER = "0xe05349d6fE12602F6084550995B247a5C80C0E2C", e.MULTICALL_ADDRESS_AURORA = "0xe0e3887b158F7F9c80c835a61ED809389BC08d1b", e.MULTICALL_ADDRESS_OPTIMISM = "0xD0E99f15B24F265074747B2A1444eB02b9E30422", e.AGGREGATE_SELECTOR = "0x252dba42", e.default = function(t, e, r, a) {
                return n(this, void 0, void 0, (function() {
                    var n, s;
                    return o(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                return n = new i.ethers.utils.Interface([t]), s = Object.values(n.functions)[0], [4, f(e.map((function(t) {
                                    var e = n.encodeFunctionData(s, t.params);
                                    return {
                                        to: t.contract,
                                        data: e
                                    }
                                })), r, a)];
                            case 1:
                                return [2, o.sent().map((function(t, r) {
                                    var o;
                                    try {
                                        o = (0, u.default)(n.decodeFunctionResult(s, t))
                                    } catch (a) {
                                        o = null
                                    }
                                    return {
                                        input: {
                                            params: e[r].params,
                                            target: e[r].contract
                                        },
                                        success: null !== o,
                                        output: o
                                    }
                                }))]
                        }
                    }))
                }))
            }, e.networkSupportsMulticall = m
        },
        44764: function(t, e, r) {
            var n = r(83454),
                o = this && this.__assign || function() {
                    return o = Object.assign || function(t) {
                        for (var e, r = 1, n = arguments.length; r < n; r++)
                            for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                        return t
                    }, o.apply(this, arguments)
                },
                a = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                i = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.call = void 0;
            var s = r(17187),
                c = r(33705),
                u = n.env.LLAMA_SDK_MAX_PARALLEL ? +n.env.LLAMA_SDK_MAX_PARALLEL : 100,
                l = {},
                h = new s.EventEmitter;
            h.setMaxListeners(5e5), e.call = function t(e, r, n, p, f) {
                var d;
                return void 0 === f && (f = {
                    retry: !0
                }), a(this, void 0, void 0, (function() {
                    function a() {
                        if (b.activeWorkers--, b.queue.length) {
                            var t = b.pickFromTop ? b.queue.shift() : b.queue.pop();
                            b.pickFromTop = !b.pickFromTop, h.emit(t)
                        }
                    }
                    var m, b, v, y, k, g, w;
                    return i(this, (function(i) {
                        switch (i.label) {
                            case 0:
                                return m = null === (d = f.retry) || void 0 === d || d, p || (p = "noChain"), b = function(t) {
                                    l[t] || (l[t] = {
                                        activeWorkers: 0,
                                        queue: [],
                                        requestCount: 0,
                                        pickFromTop: !0
                                    });
                                    return l[t]
                                }(p), v = b.requestCount++, y = "".concat(p, "-").concat(v), b.activeWorkers > u ? (b.queue.push(y), [4, (0, s.once)(h, y)]) : [3, 2];
                            case 1:
                                i.sent(), i.label = 2;
                            case 2:
                                b.activeWorkers++, c.DEBUG_ENABLED && (k = b.queue.length > 100 ? 50 : 10, v % k === 0 && (0, c.debugLog)("chain: ".concat(p, " request #: ").concat(v, " queue: ").concat(b.queue.length, " active requests: ").concat(b.activeWorkers))), i.label = 3;
                            case 3:
                                return i.trys.push([3, 5, , 6]), [4, e.call(r, n)];
                            case 4:
                                return g = i.sent(), a(), [3, 6];
                            case 5:
                                if (w = i.sent(), a(), m) return [2, t(e, r, n, p, o(o({}, f), {
                                    retry: !1
                                }))];
                                throw w;
                            case 6:
                                return [2, g]
                        }
                    }))
                }))
            }
        },
        25216: function(t, e, r) {
            var n = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                o = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.getBlock = e.getCurrentBlocks = e.getBlocks = e.getChainBlocks = e.chainsForBlocks = void 0;
            var a = r(36142),
                i = r(46507);
            e.chainsForBlocks = ["avax", "bsc", "polygon", "xdai", "fantom", "arbitrum"];

            function s(t, r) {
                return void 0 === r && (r = e.chainsForBlocks), n(this, void 0, void 0, (function() {
                    var e, a, i = this;
                    return o(this, (function(s) {
                        switch (s.label) {
                            case 0:
                                return e = {}, a = function(r) {
                                    return n(i, void 0, void 0, (function() {
                                        var n, a;
                                        return o(this, (function(o) {
                                            switch (o.label) {
                                                case 0:
                                                    return n = e, a = r, [4, u(r, t)];
                                                case 1:
                                                    return [2, n[a] = o.sent().block]
                                            }
                                        }))
                                    }))
                                }, [4, Promise.all(r.map(a))];
                            case 1:
                                return s.sent(), [2, e]
                        }
                    }))
                }))
            }
            e.getChainBlocks = s, e.getBlocks = function(t, e) {
                return void 0 === e && (e = void 0), n(this, void 0, void 0, (function() {
                    var r, n, a;
                    return o(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                return e = null === e || void 0 === e ? void 0 : e.filter((function(t) {
                                    return "ethereum" !== t
                                })), [4, Promise.all([u("ethereum", t), s(t, e)])];
                            case 1:
                                return r = o.sent(), n = r[0], (a = r[1]).ethereum = n.block, [2, {
                                    ethereumBlock: n.block,
                                    chainBlocks: a
                                }]
                        }
                    }))
                }))
            }, e.getCurrentBlocks = function(t) {
                return void 0 === t && (t = void 0), n(this, void 0, void 0, (function() {
                    var e, r;
                    return o(this, (function(n) {
                        switch (n.label) {
                            case 0:
                                return t && (t = t.filter((function(t) {
                                    return "ethereum" !== t
                                }))), [4, u("ethereum")];
                            case 1:
                                return [4, s((e = n.sent()).timestamp, t)];
                            case 2:
                                return (r = n.sent()).ethereum = e.number, [2, {
                                    timestamp: e.timestamp,
                                    ethereumBlock: e.number,
                                    chainBlocks: r
                                }]
                        }
                    }))
                }))
            };
            var c = {
                current: {}
            };

            function u(t, e) {
                return void 0 === e && (e = void 0), n(this, void 0, void 0, (function() {
                    return o(this, (function(r) {
                        if (!e) {
                            if ("ethereum" !== t) throw new Error("Timestamp  is missing!!!");
                            return c.current || (c.current = {}), c.current.ethereum || (c.current.ethereum = function() {
                                return n(this, void 0, void 0, (function() {
                                    var t, e;
                                    return o(this, (function(r) {
                                        switch (r.label) {
                                            case 0:
                                                return [4, (t = (0, a.getProvider)("ethereum")).getBlockNumber()];
                                            case 1:
                                                return e = r.sent(), [2, t.getBlock(e - 5)]
                                        }
                                    }))
                                }))
                            }()), [2, c.current.ethereum]
                        }
                        return c[e] || (c[e] = {}), c[e][t] || (c[e][t] = function() {
                            return n(this, void 0, void 0, (function() {
                                var r, n;
                                return o(this, (function(o) {
                                    switch (o.label) {
                                        case 0:
                                            r = 0, o.label = 1;
                                        case 1:
                                            if (!(r < 5)) return [3, 6];
                                            o.label = 2;
                                        case 2:
                                            return o.trys.push([2, 4, , 5]), [4, (0, i.lookupBlock)(e, {
                                                chain: t
                                            })];
                                        case 3:
                                            return [2, o.sent()];
                                        case 4:
                                            if (n = o.sent(), 4 === r) throw n;
                                            return [3, 5];
                                        case 5:
                                            return r++, [3, 1];
                                        case 6:
                                            return [2]
                                    }
                                }))
                            }))
                        }()), [2, c[e][t]]
                    }))
                }))
            }
            e.getBlock = u
        },
        52699: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.humanizeNumber = void 0, e.humanizeNumber = function(t) {
                for (var e = 0, r = [
                        [Math.pow(10, 9), "B"],
                        [Math.pow(10, 6), "M"],
                        [Math.pow(10, 3), "k"]
                    ]; e < r.length; e++) {
                    var n = r[e],
                        o = n[0],
                        a = n[1];
                    if (t > o) return "".concat((t / o).toFixed(2), " ").concat(a)
                }
                return t.toString()
            }
        },
        36142: function(t, e, r) {
            var n = r(83454);
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.setProvider = e.ETHER_ADDRESS = e.handleDecimals = e.TEN = e.getProvider = e.providers = void 0;
            var o = r(63239);

            function a(t, e, r) {
                var a, i, s;
                return n.env.HISTORICAL ? (1 === r && console.log("RPC providers set to historical, only the first RPC provider will be used"), new o.ethers.providers.StaticJsonRpcProvider(null === (i = null !== (a = n.env[t.toUpperCase() + "_RPC"]) && void 0 !== a ? a : e) || void 0 === i ? void 0 : i.split(",")[0], {
                    name: t,
                    chainId: r
                })) : new o.ethers.providers.FallbackProvider((null !== (s = n.env[t.toUpperCase() + "_RPC"]) && void 0 !== s ? s : e).split(",").map((function(e, n) {
                    return {
                        provider: new o.ethers.providers.StaticJsonRpcProvider(e, {
                            name: t,
                            chainId: r
                        }),
                        priority: n
                    }
                })), 1)
            }
            e.providers = {
                ethereum: a("ethereum", "https://eth-mainnet.gateway.pokt.network/v1/5f3453978e354ab992c4da79,https://cloudflare-eth.com/,https://main-light.eth.linkpool.io/,https://api.mycryptoapi.com/eth", 1),
                bsc: a("bsc", "https://bsc-dataseed.binance.org/,https://bsc-dataseed1.defibit.io/,https://bsc-dataseed1.ninicoin.io/,https://bsc-dataseed2.defibit.io/,https://bsc-dataseed2.ninicoin.io/", 56),
                polygon: a("polygon", "https://polygon-rpc.com/,https://rpc-mainnet.maticvigil.com/", 137),
                heco: a("heco", "https://http-mainnet.hecochain.com", 128),
                fantom: a("fantom", "https://rpc.ankr.com/fantom,https://rpc.ftm.tools/,https://rpcapi.fantom.network", 250),
                rsk: a("rsk", "https://public-node.rsk.co", 30),
                tomochain: a("tomochain", "https://rpc.tomochain.com", 88),
                xdai: a("xdai", "https://rpc.ankr.com/gnosis,https://xdai-archive.blockscout.com", 100),
                avax: a("avax", "https://api.avax.network/ext/bc/C/rpc,https://rpc.ankr.com/avalanche", 43114),
                wan: a("wan", "https://gwan-ssl.wandevs.org:56891", 888),
                harmony: a("harmony", "https://harmony-0-rpc.gateway.pokt.network,https://api.harmony.one,https://api.s0.t.hmny.io", 16666e5),
                thundercore: a("thundercore", "https://mainnet-rpc.thundercore.com", 108),
                okexchain: a("okexchain", "https://exchainrpc.okex.org", 66),
                optimism: a("optimism", "https://mainnet.optimism.io/", 10),
                arbitrum: a("arbitrum", "https://arb1.arbitrum.io/rpc", 42161),
                kcc: a("kcc", "https://rpc-mainnet.kcc.network", 321),
                celo: a("celo", "https://forno.celo.org", 42220),
                iotex: a("iotex", "https://babel-api.mainnet.iotex.io", 4689),
                moonriver: a("moonriver", "https://rpc.api.moonriver.moonbeam.network/,https://moonriver.api.onfinality.io/public", 1285),
                shiden: a("shiden", "https://evm.shiden.astar.network,https://shiden.api.onfinality.io/public,https://rpc.shiden.astar.network:8545", 336),
                palm: a("palm", "https://palm-mainnet.infura.io/v3/3a961d6501e54add9a41aa53f15de99b", 11297108109),
                energyweb: a("energyweb", "https://rpc.energyweb.org", 246),
                energi: a("energi", "https://nodeapi.energi.network", 39797),
                songbird: a("songbird", "https://songbird.towolabs.com/rpc", 19),
                hpb: a("hpb", "https://hpbnode.com", 269),
                gochain: a("gochain", "https://rpc.gochain.io", 60),
                ethereumclassic: a("ethereumclassic", "https://www.ethercluster.com/etc,https://blockscout.com/etc/mainnet/api/eth-rpc", 61),
                xdaiarb: a("xdaiarb", "https://arbitrum.xdaichain.com", 200),
                kardia: a("kardia", "https://rpc.kardiachain.io/", 24),
                fuse: a("fuse", "https://rpc.fuse.io", 122),
                smartbch: a("smartbch", "https://global.uat.cash,https://smartbch.greyh.at,https://smartbch.fountainhead.cash/mainnet", 1e4),
                elastos: a("elastos", "https://api.elastos.io/eth,https://api.trinity-tech.cn/eth", 20),
                hoo: a("hoo", "https://http-mainnet.hoosmartchain.com", 70),
                fusion: a("fusion", "https://mainnet.anyswap.exchange,https://mainway.freemoon.xyz/gate", 32659),
                aurora: a("aurora", "https://mainnet.aurora.dev", 1313161554),
                ronin: a("ronin", "https://api.roninchain.com/rpc", 2020),
                boba: a("boba", "https://mainnet.boba.network/", 288),
                boba_avax: a("boba_avax", "https://avax.boba.network/", 43288),
                boba_bnb: a("boba_bnb", "https://bnb.boba.network/", 56288),
                cronos: a("cronos", "https://cronosrpc-1.xstaking.sg,https://evm.cronos.org,https://rpc.vvs.finance,https://evm-cronos.crypto.org", 25),
                polis: a("polis", "https://rpc.polis.tech", 333999),
                zyx: a("zyx", "https://rpc-6.zyx.network,https://rpc-4.zyx.network,https://rpc-1.zyx.network/,https://rpc-2.zyx.network/,https://rpc-3.zyx.network/,https://rpc-5.zyx.network/", 55),
                telos: a("telos", "https://mainnet.telos.net/evm,https://rpc1.eu.telos.net/evm,https://rpc1.us.telos.net/evm", 40),
                metis: a("metis", "https://andromeda.metis.io/?owner=1088", 1088),
                ubiq: a("ubiq", "https://rpc.octano.dev", 8),
                velas: a("velas", "https://evmexplorer.velas.com/rpc", 106),
                callisto: a("callisto", "https://rpc.callisto.network,https://clo-geth.0xinfra.com/", 820),
                klaytn: a("klaytn", "https://public-node-api.klaytnapi.com/v1/cypress", 8217),
                csc: a("csc", "https://rpc.coinex.net/,https://rpc1.coinex.net/,https://rpc2.coinex.net/,https://rpc3.coinex.net/,https://rpc4.coinex.net/", 52),
                nahmii: a("nahmii", "https://l2.nahmii.io/", 5551),
                liquidchain: a("xlc", "https://rpc.liquidchain.net/,https://rpc.xlcscan.com/", 5050),
                meter: a("meter", "https://rpc.meter.io", 82),
                theta: a("theta", "https://eth-rpc-api.thetatoken.org/rpc", 361),
                oasis: a("oasis", "https://emerald.oasis.dev/", 42262),
                syscoin: a("syscoin", "https://rpc.ankr.com/syscoin,https://rpc.syscoin.org", 57),
                moonbeam: a("moonbeam", "https://rpc.api.moonbeam.network", 1284),
                curio: a("curio", "https://mainnet-api.skalenodes.com/v1/fit-betelgeuse", 836542336838601),
                astar: a("astar", "https://evm.astar.network/,https://rpc.astar.network:8545,https://astar.api.onfinality.io/public", 592),
                godwoken_v1: a("godwoken", "https://v1.mainnet.godwoken.io/rpc", 71402),
                godwoken: a("godwoken", "https://mainnet.godwoken.io/rpc", 71394),
                evmos: a("evmos", ["https://evmos-mainnet.public.blastapi.io", "https://eth.bd.evmos.org:8545/", "https://evmos-json-rpc.stakely.io", "https://evmos-mainnet.gateway.pokt.network/v1/lb/627586ddea1b320039c95205", "https://jsonrpc-evmos-ia.cosmosia.notional.ventures", "https://evmos-evm.publicnode.com", "https://jsonrpc-evmos.goldenratiostaking.net"].join(","), 9001),
                conflux: a("conflux", "https://evm.confluxrpc.com", 1030),
                milkomeda: a("milkomeda", "https://rpc-mainnet-cardano-evm.c1.milkomeda.com", 2001),
                milkomeda_a1: a("milkomeda_a1", "https://rpc-mainnet-algorand-rollup.a1.milkomeda.com", 2002),
                dfk: a("dfk", "https://subnets.avax.network/defi-kingdoms/dfk-chain/rpc", 53935),
                crab: a("crab", "https://crab-rpc.darwinia.network", 44),
                bittorrent: a("bittorrent", ["https://rpc.ankr.com/bttc", "https://bttc.trongrid.io/", "https://rpc.bittorrentchain.io", "https://rpc.bt.io"].join(","), 199),
                findora: a("findora", "https://prod-mainnet.prod.findora.org:8545", 2152),
                candle: a("candle", "https://candle-rpc.com,https://rpc.cndlchain.com", 534),
                lachain: a("lachain", "https://rpc-mainnet.lachain.io", 225),
                reichain: a("reichain", "https://rei-rpc.moonrhythm.io", 55555),
                rei: a("rei", "https://rpc.rei.network", 47805),
                clv: a("clv", "https://api-para.clover.finance", 1024),
                echelon: a("echelon", "https://rpc.ech.network,https://evm.ech.network,https://draco.ech.network", 3e3),
                multivac: a("multivac", "https://rpc.mtv.ac,https://rpc-eu.mtv.ac", 62621),
                kava: a("kava", "https://evm.kava.io", 2222),
                sx: a("sx", "https://rpc.sx.technology", 416),
                karura_evm: a("karura_evm", "https://eth-rpc-karura.aca-api.network", 686),
                nova: a("nova", "http://dataseed-0.rpc.novanetwork.io:8545,https://rpc.novanetwork.io:9070", 87),
                ontology_evm: a("ontology_evm", "https://dappnode1.ont.io:10339", 58),
                jfin: a("jfin", "https://rpc.jfinchain.com/", 3501),
                bitkub: a("bitkub", "https://rpc.bitkubchain.io/", 96),
                bitgert: a("bitgert", "https://rpc.icecreamswap.com,https://nodes.vefinetwork.org/bitgert", 32520),
                canto: a("canto", "https://jsonrpc.canto.nodestake.top,https://canto.evm.chandrastation.com/", 7700),
                dogechain: a("dogechain", "https://dogechain-sj.ankr.com,https://dogechain.ankr.com,https://rpc.dogechain.dog,https://rpc01-sg.dogechain.dog,https://rpc02-sg.dogechain.dog,https://rpc03-sg.dogechain.dog", 2e3),
                posi: a("posi", "https://api.posichain.org,https://api.s0.posichain.org", 9e5),
                arbitrum_nova: a("arbitrum_nova", "https://nova.arbitrum.io/rpc", 42170),
                ultron: a("ultron", "https://ultron-rpc.net", 1231),
                tombchain: a("tombchain", "https://rpc.tombchain.com/", 6969),
                vision: a("vision", "https://infragrid.v.network/ethereum/compatible", 888888),
                ethpow: a("ethpow", "https://mainnet.ethereumpow.org/", 10001),
                functionx: a("functionx", "https://fx-json-web3.functionx.io:8545", 530),
                xdc: a("xdc", "https://rpc.xinfin.network,https://rpc1.xinfin.network,https://erpc.xinfin.network", 50),
                cube: a("cube", "https://http-mainnet.cube.network/", 1818),
                kekchain: a("kekchain", "https://mainnet.kekchain.com", 420420),
                step: a("step", "https://rpc.step.network/", 1234),
                muuchain: a("muu", "https://mainnet-rpc.muuchain.com", 20402),
                dexit: a("dexit", "https://dxt.dexit.network", 877),
                empire: a("empire", "https://rpc.empirenetwork.io", 3693),
                flare: a("flare", "https://flare-api.flare.network/ext/C/rpc", 14),
                tlchain: a("tlchain", "https://mainnet-rpc.tlchain.live", 5177),
                zeniq: a("zeniq", "https://smart1.zeniq.network:9545,https://smart2.zeniq.network:9545,https://smar31.zeniq.network:9545", 383414847825)
            }, e.getProvider = function(t) {
                return void 0 === t && (t = "ethereum"), e.providers[t]
            }, e.TEN = o.BigNumber.from(10), e.handleDecimals = function(t, r) {
                return void 0 === r ? t.toString() : t.div(e.TEN.pow(r)).toString()
            }, e.ETHER_ADDRESS = "0x0000000000000000000000000000000000000000", e.setProvider = function(t, r) {
                e.providers[t] = r
            }
        },
        55966: function(t, e, r) {
            var n = this && this.__createBinding || (Object.create ? function(t, e, r, n) {
                    void 0 === n && (n = r);
                    var o = Object.getOwnPropertyDescriptor(e, r);
                    o && !("get" in o ? !e.__esModule : o.writable || o.configurable) || (o = {
                        enumerable: !0,
                        get: function() {
                            return e[r]
                        }
                    }), Object.defineProperty(t, n, o)
                } : function(t, e, r, n) {
                    void 0 === n && (n = r), t[n] = e[r]
                }),
                o = this && this.__setModuleDefault || (Object.create ? function(t, e) {
                    Object.defineProperty(t, "default", {
                        enumerable: !0,
                        value: e
                    })
                } : function(t, e) {
                    t.default = e
                }),
                a = this && this.__importStar || function(t) {
                    if (t && t.__esModule) return t;
                    var e = {};
                    if (null != t)
                        for (var r in t) "default" !== r && Object.prototype.hasOwnProperty.call(t, r) && n(e, t, r);
                    return o(e, t), e
                },
                i = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                s = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.humanizeNumber = e.blocks = e.sumChainTvls = e.removeTokenBalance = e.mergeBalances = e.sumSingleBalance = e.sumMultiBalanceOf = void 0;
            var c = r(63239),
                u = a(r(25216));
            e.blocks = u;
            var l = a(r(52699));

            function h(t, e, r, n) {
                if (i(r), 0 !== +r) {
                    if (n && (e = "".concat(n, ":").concat(e)), "object" === typeof r) {
                        if ("function" !== typeof r.toString) throw new Error("Invalid balance value:" + r);
                        r = r.toString()
                    }
                    if ("number" === typeof r || t[e] && "number" === typeof t[e]) {
                        if ("number" !== typeof(o = +(t.hasOwnProperty(e) ? t[e] : 0)) || isNaN(o)) throw new Error("Trying to merge token balance and coingecko amount for ".concat(e, " current balance: ").concat(r, " previous balance: ").concat(t[e]));
                        i(a = o + +r), t[e] = a
                    } else {
                        var o, a;
                        i(+(a = (o = c.BigNumber.from(t.hasOwnProperty(e) ? t[e] : "0")).add(c.BigNumber.from(r)).toString())), t[e] = a
                    }
                }

                function i(t) {
                    if ([null, void 0].includes(t) || isNaN(+t)) throw new Error("Invalid balance: ".concat(r))
                }
            }

            function p(t, e) {
                Object.entries(e).forEach((function(e) {
                    h(t, e[0], e[1])
                }))
            }
            e.humanizeNumber = l, e.sumMultiBalanceOf = function(t, e, r, n) {
                void 0 === r && (r = !0), void 0 === n && (n = function(t) {
                    return t
                }), e.output.map((function(e) {
                    var o;
                    if (e.success) {
                        var a = n(e.input.target),
                            i = e.output;
                        if (c.BigNumber.from(i).lte(0)) return;
                        t[a] = c.BigNumber.from(null !== (o = t[a]) && void 0 !== o ? o : 0).add(i).toString()
                    } else if (r) throw console.error(e), new Error("balanceOf multicall failed")
                }))
            }, e.sumSingleBalance = h, e.mergeBalances = p, e.removeTokenBalance = function(t, e, r) {
                void 0 === r && (r = !1);
                var n = new RegExp(e, r ? void 0 : "i");
                return Object.keys(t).forEach((function(e) {
                    n.test(e) && delete t[e]
                })), t
            }, e.sumChainTvls = function(t) {
                var e = this;
                return function(r, n, o, a) {
                    return i(e, void 0, void 0, (function() {
                        var e, c = this;
                        return s(this, (function(u) {
                            switch (u.label) {
                                case 0:
                                    return e = {}, [4, Promise.all(t.map((function(t) {
                                        return i(c, void 0, void 0, (function() {
                                            var i;
                                            return s(this, (function(s) {
                                                switch (s.label) {
                                                    case 0:
                                                        return [4, t(r, n, o, a)];
                                                    case 1:
                                                        return i = s.sent(), p(e, i), [2]
                                                }
                                            }))
                                        }))
                                    })))];
                                case 1:
                                    return u.sent(), [2, e]
                            }
                        }))
                    }))
                }
            }
        },
        33705: function(t, e, r) {
            var n = r(83454);
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.debugLog = e.DEBUG_ENABLED = void 0, e.DEBUG_ENABLED = "true" === n.env.SDK_DEBUG || n.env.LLAMA_DEBUG_MODE, e.debugLog = function() {
                for (var t = [], r = 0; r < arguments.length; r++) t[r] = arguments[r];
                e.DEBUG_ENABLED && console.log.apply(console, t)
            }
        },
        46507: function(t, e, r) {
            var n = this && this.__assign || function() {
                    return n = Object.assign || function(t) {
                        for (var e, r = 1, n = arguments.length; r < n; r++)
                            for (var o in e = arguments[r]) Object.prototype.hasOwnProperty.call(e, o) && (t[o] = e[o]);
                        return t
                    }, n.apply(this, arguments)
                },
                o = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                a = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                },
                i = this && this.__importDefault || function(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.normalizeBalances = e.normalizePrefixes = e.normalizeAddress = e.getLogs = e.lookupBlock = e.getLatestBlock = e.sliceIntoChunks = e.runInPromisePool = void 0;
            var s = r(36142),
                c = i(r(83300)),
                u = r(63239),
                l = r(55966),
                h = r(33705),
                p = i(r(16759));
            e.runInPromisePool = p.default, e.sliceIntoChunks = function(t, e) {
                void 0 === e && (e = 100);
                for (var r = [], n = 0; n < t.length; n += e) {
                    var o = t.slice(n, n + e);
                    r.push(o)
                }
                return r
            };
            var f = {
                    getBlock: function(t) {
                        return o(void 0, void 0, void 0, (function() {
                            return a(this, (function(e) {
                                return [2, (0, c.default)("https://api.data.kava.io/blocks/".concat(t)).then((function(t) {
                                    return t.json()
                                })).then((function(t) {
                                    return {
                                        number: Number(t.block.header.height),
                                        timestamp: Math.round(Date.parse(t.block.header.time) / 1e3)
                                    }
                                }))]
                            }))
                        }))
                    }
                },
                d = {
                    getBlock: function(t) {
                        return o(void 0, void 0, void 0, (function() {
                            return a(this, (function(e) {
                                return [2, (0, c.default)("https://lcd.terra.dev/blocks/".concat(t)).then((function(t) {
                                    return t.json()
                                })).then((function(t) {
                                    return {
                                        number: Number(t.block.header.height),
                                        timestamp: Math.round(Date.parse(t.block.header.time) / 1e3)
                                    }
                                }))]
                            }))
                        }))
                    }
                },
                m = {
                    getBlock: function(t) {
                        return o(void 0, void 0, void 0, (function() {
                            return a(this, (function(e) {
                                return "latest" !== t ? [2, (0, c.default)("https://algoindexer.algoexplorerapi.io/v2/blocks/".concat(t)).then((function(t) {
                                    return t.json()
                                })).then((function(t) {
                                    return {
                                        number: t.round,
                                        timestamp: t.timestamp
                                    }
                                }))] : [2, (0, c.default)("https://algoindexer.algoexplorerapi.io/health").then((function(t) {
                                    return t.json()
                                })).then((function(t) {
                                    return m.getBlock(t.round)
                                }))]
                            }))
                        }))
                    }
                };

            function b(t, e, r) {
                return o(this, void 0, void 0, (function() {
                    var n;
                    return a(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                return [4, t.getBlock(e)];
                            case 1:
                                if (null === (n = o.sent())) throw new Error("Can't get block of chain ".concat(null !== r && void 0 !== r ? r : "ethereum"));
                                return [2, n]
                        }
                    }))
                }))
            }

            function v(t) {
                return "terra" === t ? d : "kava" === t ? f : "algorand" === t ? m : (0, s.getProvider)(t)
            }
            e.getLatestBlock = function(t) {
                return o(this, void 0, void 0, (function() {
                    return a(this, (function(e) {
                        return [2, b(v(t), "latest", t)]
                    }))
                }))
            };
            var y = {
                terra: 4724001,
                crab: 4969901
            };

            function k(t) {
                var e = t.substring(0, t.indexOf(":"));
                return ["solana", "tezos"].includes(e) ? t : t.startsWith("0x") ? "ethereum:".concat(t.toLowerCase()) : t.includes(":") ? t.toLowerCase() : "coingecko:".concat(t.toLowerCase())
            }
            e.lookupBlock = function(t, e) {
                var r, n, i;
                return void 0 === e && (e = {}), o(this, void 0, void 0, (function() {
                    var o, s, u, l, p, f, d, m, k, g, w, _, E, A, L, S, x, D, C, T, B, M, P, F, O;
                    return a(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                return "celo" !== (o = null !== (r = null === e || void 0 === e ? void 0 : e.chain) && void 0 !== r ? r : "ethereum") ? [3, 3] : (s = "https://explorer.celo.org/mainnet/api?module=block&action=getblocknobytime&timestamp=".concat(t, "&closest=before"), [4, (0, c.default)(s)]);
                            case 1:
                                return [4, a.sent().json()];
                            case 2:
                                return u = a.sent(), [2, {
                                    timestamp: t,
                                    block: +u.result.blockNumber
                                }];
                            case 3:
                                l = null !== (n = y[o]) && void 0 !== n ? n : 100, a.label = 4;
                            case 4:
                                return a.trys.push([4, 10, , 11]), d = v(o), [4, Promise.all([b(d, "latest", o), b(d, l, o)])];
                            case 5:
                                if (m = a.sent(), k = m[0], g = m[1], p = g, f = k, k.timestamp - t < -1800) throw new Error('Last block of chain "'.concat(o, '" is further than 30 minutes into the past. Provider is "').concat(null === (i = null === d || void 0 === d ? void 0 : d.connection) || void 0 === i ? void 0 : i.url, '"'));
                                if (Math.abs(k.timestamp - t) < 60) return [2, {
                                    block: k.number,
                                    timestamp: k.timestamp
                                }];
                                w = void 0, _ = 0, E = Date.now(), A = 900, L = "ethereum" === o ? 20 : 200, S = void 0, x = void 0, D = function(e) {
                                    return e.timestamp - t > 0 ? e.timestamp - t : t - e.timestamp
                                }, a.label = 6;
                            case 6:
                                return ++_, C = f.number - p.number, T = f.timestamp - p.timestamp, B = T / C, M = Math.floor(p.number + (t - p.timestamp) / B), P = Math.floor((p.number + f.number) / 2), [4, Promise.all([b(d, M, o), b(d, P, o)])];
                            case 7:
                                (F = a.sent()).push(f, p), F.sort((function(t, e) {
                                    return D(t) - D(e)
                                })), w = F[0], p = F.filter((function(e) {
                                    return e.timestamp < t
                                })).reduce((function(e, r) {
                                    return t - e.timestamp < t - r.timestamp ? e : r
                                })), f = F.filter((function(e) {
                                    return e.timestamp > t
                                })).reduce((function(e, r) {
                                    return e.timestamp - t < r.timestamp - t ? e : r
                                })), x = D(w), S = f.number - p.number, a.label = 8;
                            case 8:
                                if (x > A && S > L) return [3, 6];
                                a.label = 9;
                            case 9:
                                if ((0, h.debugLog)("chain: ".concat(o, " block: ").concat(w.number, " #calls: ").concat(_, " imprecision: ").concat(Number(x / 60).toFixed(2), " (min) Time Taken: ").concat(Number((Date.now() - E) / 1e3).toFixed(2), " (in sec)")), "bsc" !== o && Math.abs(w.timestamp - t) > 3600) throw new Error("Block selected is more than 1 hour away from the requested timestamp");
                                return [2, {
                                    block: w.number,
                                    timestamp: w.timestamp
                                }];
                            case 10:
                                throw O = a.sent(), console.log(O), new Error("Couldn't find block height for chain ".concat(o, ", RPC node rugged"));
                            case 11:
                                return [2]
                        }
                    }))
                }))
            }, e.getLogs = function(t) {
                var e;
                return o(this, void 0, void 0, (function() {
                    var r, o, i, c, l, h, p;
                    return a(this, (function(a) {
                        switch (a.label) {
                            case 0:
                                if (void 0 === t.toBlock || void 0 === t.fromBlock) throw new Error("toBlock and fromBlock need to be defined in all calls to getLogs");
                                r = {
                                    address: t.target,
                                    topics: null !== (e = t.topics) && void 0 !== e ? e : [u.utils.id(t.topic)],
                                    fromBlock: t.fromBlock,
                                    toBlock: t.toBlock
                                }, o = [], i = t.toBlock - t.fromBlock, c = t.fromBlock, a.label = 1;
                            case 1:
                                if (!(c < t.toBlock)) return [3, 6];
                                l = Math.min(t.toBlock, c + i), a.label = 2;
                            case 2:
                                return a.trys.push([2, 4, , 5]), [4, (0, s.getProvider)(t.chain).getLogs(n(n({}, r), {
                                    fromBlock: c,
                                    toBlock: l
                                }))];
                            case 3:
                                return h = a.sent(), o = o.concat(h), c = l, [3, 5];
                            case 4:
                                if (p = a.sent(), !(i >= 2e3)) throw p;
                                return i = Math.floor(i / 2), [3, 5];
                            case 5:
                                return [3, 1];
                            case 6:
                                if (t.keys.length > 0) {
                                    if ("topics" !== t.keys[0]) throw new Error("Unsupported");
                                    return [2, {
                                        output: o.map((function(t) {
                                            return t.topics
                                        }))
                                    }]
                                }
                                return [2, {
                                    output: o
                                }]
                        }
                    }))
                }))
            }, e.normalizeAddress = function(t) {
                var e = t.substring(0, t.indexOf(":"));
                return ["solana", "tezos"].includes(e) ? t : t.toLowerCase()
            }, e.normalizePrefixes = k;
            var g = "ethereum:0x0000000000000000000000000000000000000000",
                w = "ethereum:0xc02aaa39b223fe8d0a0e5c4f27ead9083c756cc2";
            e.normalizeBalances = function(t) {
                var e;
                Object.keys(t).map((function(e) {
                    if (0 !== +t[e]) {
                        var r = k(e);
                        r != e && ((0, l.sumSingleBalance)(t, r, t[e]), delete t[e])
                    } else delete t[e]
                }));
                var r = t[g];
                return void 0 !== r && (t[w] = u.BigNumber.from(null !== (e = t[w]) && void 0 !== e ? e : 0).add(r).toString(), delete t[g]), t
            }
        },
        16759: function(t, e, r) {
            var n = this && this.__awaiter || function(t, e, r, n) {
                    return new(r || (r = Promise))((function(o, a) {
                        function i(t) {
                            try {
                                c(n.next(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function s(t) {
                            try {
                                c(n.throw(t))
                            } catch (e) {
                                a(e)
                            }
                        }

                        function c(t) {
                            var e;
                            t.done ? o(t.value) : (e = t.value, e instanceof r ? e : new r((function(t) {
                                t(e)
                            }))).then(i, s)
                        }
                        c((n = n.apply(t, e || [])).next())
                    }))
                },
                o = this && this.__generator || function(t, e) {
                    var r, n, o, a, i = {
                        label: 0,
                        sent: function() {
                            if (1 & o[0]) throw o[1];
                            return o[1]
                        },
                        trys: [],
                        ops: []
                    };
                    return a = {
                        next: s(0),
                        throw: s(1),
                        return: s(2)
                    }, "function" === typeof Symbol && (a[Symbol.iterator] = function() {
                        return this
                    }), a;

                    function s(s) {
                        return function(c) {
                            return function(s) {
                                if (r) throw new TypeError("Generator is already executing.");
                                for (; a && (a = 0, s[0] && (i = 0)), i;) try {
                                    if (r = 1, n && (o = 2 & s[0] ? n.return : s[0] ? n.throw || ((o = n.return) && o.call(n), 0) : n.next) && !(o = o.call(n, s[1])).done) return o;
                                    switch (n = 0, o && (s = [2 & s[0], o.value]), s[0]) {
                                        case 0:
                                        case 1:
                                            o = s;
                                            break;
                                        case 4:
                                            return i.label++, {
                                                value: s[1],
                                                done: !1
                                            };
                                        case 5:
                                            i.label++, n = s[1], s = [0];
                                            continue;
                                        case 7:
                                            s = i.ops.pop(), i.trys.pop();
                                            continue;
                                        default:
                                            if (!(o = (o = i.trys).length > 0 && o[o.length - 1]) && (6 === s[0] || 2 === s[0])) {
                                                i = 0;
                                                continue
                                            }
                                            if (3 === s[0] && (!o || s[1] > o[0] && s[1] < o[3])) {
                                                i.label = s[1];
                                                break
                                            }
                                            if (6 === s[0] && i.label < o[1]) {
                                                i.label = o[1], o = s;
                                                break
                                            }
                                            if (o && i.label < o[2]) {
                                                i.label = o[2], i.ops.push(s);
                                                break
                                            }
                                            o[2] && i.ops.pop(), i.trys.pop();
                                            continue
                                    }
                                    s = e.call(t, i)
                                } catch (c) {
                                    s = [6, c], n = 0
                                } finally {
                                    r = o = 0
                                }
                                if (5 & s[0]) throw s[1];
                                return {
                                    value: s[0] ? s[1] : void 0,
                                    done: !0
                                }
                            }([s, c])
                        }
                    }
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            var a = r(46146);
            e.default = function(t) {
                return n(this, void 0, void 0, (function() {
                    var e, r, i, s = this;
                    return o(this, (function(c) {
                        switch (c.label) {
                            case 0:
                                return [4, a.PromisePool.withConcurrency(t.concurrency).for(t.items).process((function(e, r) {
                                    return n(s, void 0, void 0, (function() {
                                        return o(this, (function(n) {
                                            switch (n.label) {
                                                case 0:
                                                    return [4, t.processor(e, r)];
                                                case 1:
                                                    return [2, [n.sent(), r]]
                                            }
                                        }))
                                    }))
                                }))];
                            case 1:
                                if (e = c.sent(), r = e.results, (i = e.errors).length) throw i[0];
                                return [2, r.sort((function(t, e) {
                                    return t[1] - e[1]
                                })).map((function(t) {
                                    return t[0]
                                }))]
                        }
                    }))
                }))
            }
        },
        833: function(t, e, r) {
            r.r(e), r.d(e, {
                BigNumber: function() {
                    return n.O$
                },
                FixedFormat: function() {
                    return o.xO
                },
                FixedNumber: function() {
                    return o.xs
                },
                _base16To36: function() {
                    return n.t2
                },
                _base36To16: function() {
                    return n.g$
                },
                formatFixed: function() {
                    return o.S5
                },
                parseFixed: function() {
                    return o.Ox
                }
            });
            var n = r(2593),
                o = r(20335)
        },
        35863: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        46146: function(t, e, r) {
            var n = this && this.__createBinding || (Object.create ? function(t, e, r, n) {
                    void 0 === n && (n = r);
                    var o = Object.getOwnPropertyDescriptor(e, r);
                    o && !("get" in o ? !e.__esModule : o.writable || o.configurable) || (o = {
                        enumerable: !0,
                        get: function() {
                            return e[r]
                        }
                    }), Object.defineProperty(t, n, o)
                } : function(t, e, r, n) {
                    void 0 === n && (n = r), t[n] = e[r]
                }),
                o = this && this.__exportStar || function(t, e) {
                    for (var r in t) "default" === r || Object.prototype.hasOwnProperty.call(e, r) || n(e, t, r)
                };
            Object.defineProperty(e, "__esModule", {
                value: !0
            });
            const a = r(55473);
            e.default = a.PromisePool, o(r(35863), e), o(r(55473), e), o(r(83495), e), o(r(98374), e), o(r(32081), e), o(r(55300), e)
        },
        83495: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.PromisePoolError = void 0;
            class r extends Error {
                constructor(t, e) {
                    super(), this.raw = t, this.item = e, this.name = this.constructor.name, this.message = this.messageFrom(t), Error.captureStackTrace(this, this.constructor)
                }
                static createFrom(t, e) {
                    return new this(t, e)
                }
                messageFrom(t) {
                    return t instanceof Error || "object" === typeof t ? t.message : "string" === typeof t || "number" === typeof t ? t.toString() : ""
                }
            }
            e.PromisePoolError = r
        },
        20976: function(t, e, r) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.PromisePoolExecutor = void 0;
            const n = r(83495),
                o = r(32081),
                a = r(55300);
            e.PromisePoolExecutor = class {
                constructor() {
                    this.meta = {
                        tasks: [],
                        items: [],
                        errors: [],
                        results: [],
                        stopped: !1,
                        concurrency: 10,
                        processedItems: []
                    }, this.handler = () => {}, this.errorHandler = void 0, this.onTaskStartedHandlers = [], this.onTaskFinishedHandlers = []
                }
                useConcurrency(t) {
                    if (!this.isValidConcurrency(t)) throw a.ValidationError.createFrom(`"concurrency" must be a number, 1 or up. Received "${t}" (${typeof t})`);
                    return this.meta.concurrency = t, this
                }
                isValidConcurrency(t) {
                    return "number" === typeof t && t >= 1
                }
                concurrency() {
                    return this.meta.concurrency
                }
                for (t) {
                    return this.meta.items = t, this
                }
                items() {
                    return this.meta.items
                }
                itemsCount() {
                    return this.items().length
                }
                tasks() {
                    return this.meta.tasks
                }
                activeTaskCount() {
                    return this.activeTasksCount()
                }
                activeTasksCount() {
                    return this.tasks().length
                }
                processedItems() {
                    return this.meta.processedItems
                }
                processedCount() {
                    return this.processedItems().length
                }
                processedPercentage() {
                    return this.processedCount() / this.itemsCount() * 100
                }
                results() {
                    return this.meta.results
                }
                errors() {
                    return this.meta.errors
                }
                withHandler(t) {
                    return this.handler = t, this
                }
                hasErrorHandler() {
                    return !!this.errorHandler
                }
                handleError(t) {
                    return this.errorHandler = t, this
                }
                onTaskStarted(t) {
                    return this.onTaskStartedHandlers = t, this
                }
                onTaskFinished(t) {
                    return this.onTaskFinishedHandlers = t, this
                }
                hasReachedConcurrencyLimit() {
                    return this.activeTasksCount() >= this.concurrency()
                }
                stop() {
                    throw this.markAsStopped(), new o.StopThePromisePoolError
                }
                markAsStopped() {
                    return this.meta.stopped = !0, this
                }
                isStopped() {
                    return this.meta.stopped
                }
                async start() {
                    return await this.validateInputs().process()
                }
                validateInputs() {
                    if ("function" !== typeof this.handler) throw a.ValidationError.createFrom("The first parameter for the .process(fn) method must be a function");
                    if (!Array.isArray(this.items())) throw a.ValidationError.createFrom('"items" must be an array. Received ' + typeof this.items());
                    if (this.errorHandler && "function" !== typeof this.errorHandler) throw a.ValidationError.createFrom("The error handler must be a function. Received " + typeof this.errorHandler);
                    return this.onTaskStartedHandlers.forEach((t => {
                        if (t && "function" !== typeof t) throw a.ValidationError.createFrom("The onTaskStarted handler must be a function. Received " + typeof t)
                    })), this.onTaskFinishedHandlers.forEach((t => {
                        if (t && "function" !== typeof t) throw a.ValidationError.createFrom("The error handler must be a function. Received " + typeof t)
                    })), this
                }
                async process() {
                    for (const [t, e] of this.items().entries()) {
                        if (this.isStopped()) break;
                        await this.waitForProcessingSlot(), this.startProcessing(e, t)
                    }
                    return await this.drained()
                }
                async waitForProcessingSlot() {
                    for (; this.hasReachedConcurrencyLimit();) await Promise.race(this.tasks())
                }
                startProcessing(t, e) {
                    const r = this.createTaskFor(t, e).then((t => {
                        this.save(t).removeActive(r)
                    })).catch((async e => {
                        await this.handleErrorFor(e, t), this.removeActive(r)
                    })).finally((() => {
                        this.processedItems().push(t), this.runOnTaskFinishedHandlers(t)
                    }));
                    this.tasks().push(r), this.runOnTaskStartedHandlers(t)
                }
                async createTaskFor(t, e) {
                    return this.handler(t, e, this)
                }
                save(t) {
                    return this.results().push(t), this
                }
                removeActive(t) {
                    return this.tasks().splice(this.tasks().indexOf(t), 1), this
                }
                async handleErrorFor(t, e) {
                    if (!this.isStoppingThePoolError(t)) {
                        if (this.isValidationError(t)) throw this.markAsStopped(), t;
                        this.hasErrorHandler() ? await this.runErrorHandlerFor(t, e) : this.saveErrorFor(t, e)
                    }
                }
                isStoppingThePoolError(t) {
                    return t instanceof o.StopThePromisePoolError
                }
                isValidationError(t) {
                    return t instanceof a.ValidationError
                }
                async runErrorHandlerFor(t, e) {
                    var r;
                    try {
                        await (null === (r = this.errorHandler) || void 0 === r ? void 0 : r.call(this, t, e, this))
                    } catch (n) {
                        this.rethrowIfNotStoppingThePool(n)
                    }
                }
                runOnTaskStartedHandlers(t) {
                    this.onTaskStartedHandlers.forEach((e => {
                        e(t, this)
                    }))
                }
                runOnTaskFinishedHandlers(t) {
                    this.onTaskFinishedHandlers.forEach((e => {
                        e(t, this)
                    }))
                }
                rethrowIfNotStoppingThePool(t) {
                    if (!this.isStoppingThePoolError(t)) throw t
                }
                saveErrorFor(t, e) {
                    this.errors().push(n.PromisePoolError.createFrom(t, e))
                }
                async drained() {
                    return await this.drainActiveTasks(), {
                        errors: this.errors(),
                        results: this.results()
                    }
                }
                async drainActiveTasks() {
                    await Promise.all(this.tasks())
                }
            }
        },
        55473: function(t, e, r) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.PromisePool = void 0;
            const n = r(20976);
            class o {
                constructor(t) {
                    this.concurrency = 10, this.items = null !== t && void 0 !== t ? t : [], this.errorHandler = void 0, this.onTaskStartedHandlers = [], this.onTaskFinishedHandlers = []
                }
                withConcurrency(t) {
                    return this.concurrency = t, this
                }
                static withConcurrency(t) {
                    return (new this).withConcurrency(t)
                }
                for (t) {
                    return new o(t).withConcurrency(this.concurrency)
                }
                static
                for (t) {
                    return (new this).for(t)
                }
                handleError(t) {
                    return this.errorHandler = t, this
                }
                onTaskStarted(t) {
                    return this.onTaskStartedHandlers.push(t), this
                }
                onTaskFinished(t) {
                    return this.onTaskFinishedHandlers.push(t), this
                }
                async process(t) {
                    return (new n.PromisePoolExecutor).useConcurrency(this.concurrency).withHandler(t).handleError(this.errorHandler).onTaskStarted(this.onTaskStartedHandlers).onTaskFinished(this.onTaskFinishedHandlers).for(this.items).start()
                }
            }
            e.PromisePool = o
        },
        98374: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            })
        },
        32081: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.StopThePromisePoolError = void 0;
            class r extends Error {}
            e.StopThePromisePoolError = r
        },
        55300: function(t, e) {
            Object.defineProperty(e, "__esModule", {
                value: !0
            }), e.ValidationError = void 0;
            class r extends Error {
                constructor(t) {
                    super(t), Error.captureStackTrace(this, this.constructor)
                }
                static createFrom(t) {
                    return new this(t)
                }
            }
            e.ValidationError = r
        }
    }
]);