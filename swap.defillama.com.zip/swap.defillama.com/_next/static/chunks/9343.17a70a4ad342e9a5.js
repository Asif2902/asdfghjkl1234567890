"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [9343], {
        75740: function(e, t, s) {
            s.d(t, {
                t0: function() {
                    return E
                },
                zv: function() {
                    return w
                },
                uA: function() {
                    return v
                },
                uc: function() {
                    return N
                },
                jb: function() {
                    return R
                },
                zb: function() {
                    return C
                },
                AV: function() {
                    return b
                },
                Ic: function() {
                    return H
                },
                Vs: function() {
                    return J
                }
            });
            Symbol();
            const o = Symbol();
            const n = Object.getPrototypeOf,
                a = new WeakMap,
                r = e => e && (a.has(e) ? a.get(e) : n(e) === Object.prototype || n(e) === Array.prototype),
                i = (e, t = !0) => {
                    a.set(e, t)
                },
                l = e => "object" === typeof e && null !== e,
                c = new WeakMap,
                d = new WeakSet,
                u = (e = Object.is, t = ((e, t) => new Proxy(e, t)), s = (e => l(e) && !d.has(e) && (Array.isArray(e) || !(Symbol.iterator in e)) && !(e instanceof WeakMap) && !(e instanceof WeakSet) && !(e instanceof Error) && !(e instanceof Number) && !(e instanceof Date) && !(e instanceof String) && !(e instanceof RegExp) && !(e instanceof ArrayBuffer)), n = (e => {
                    switch (e.status) {
                        case "fulfilled":
                            return e.value;
                        case "rejected":
                            throw e.reason;
                        default:
                            throw e
                    }
                }), a = new WeakMap, u = ((e, t, s = n) => {
                    const o = a.get(e);
                    if ((null == o ? void 0 : o[0]) === t) return o[1];
                    const r = Array.isArray(e) ? [] : Object.create(Object.getPrototypeOf(e));
                    return i(r, !0), a.set(e, [t, r]), Reflect.ownKeys(e).forEach((t => {
                        if (Object.getOwnPropertyDescriptor(r, t)) return;
                        const o = Reflect.get(e, t),
                            n = {
                                value: o,
                                enumerable: !0,
                                configurable: !0
                            };
                        if (d.has(o)) i(o, !1);
                        else if (o instanceof Promise) delete n.value, n.get = () => s(o);
                        else if (c.has(o)) {
                            const [e, t] = c.get(o);
                            n.value = u(e, t(), s)
                        }
                        Object.defineProperty(r, t, n)
                    })), r
                }), p = new WeakMap, f = [1, 1], g = (n => {
                    if (!l(n)) throw new Error("object required");
                    const a = p.get(n);
                    if (a) return a;
                    let i = f[0];
                    const h = new Set,
                        m = (e, t = ++f[0]) => {
                            i !== t && (i = t, h.forEach((s => s(e, t))))
                        };
                    let b = f[1];
                    const w = e => (t, s) => {
                            const o = [...t];
                            o[1] = [e, ...o[1]], m(o, s)
                        },
                        y = new Map,
                        v = e => {
                            var t;
                            const s = y.get(e);
                            s && (y.delete(e), null == (t = s[1]) || t.call(s))
                        },
                        I = Array.isArray(n) ? [] : Object.create(Object.getPrototypeOf(n)),
                        C = {
                            deleteProperty(e, t) {
                                const s = Reflect.get(e, t);
                                v(t);
                                const o = Reflect.deleteProperty(e, t);
                                return o && m(["delete", [t], s]), o
                            },
                            set(t, n, a, i) {
                                const u = Reflect.has(t, n),
                                    f = Reflect.get(t, n, i);
                                if (u && (e(f, a) || p.has(a) && e(f, p.get(a)))) return !0;
                                v(n), l(a) && (a = (e => r(e) && e[o] || null)(a) || a);
                                let b = a;
                                if (a instanceof Promise) a.then((e => {
                                    a.status = "fulfilled", a.value = e, m(["resolve", [n], e])
                                })).catch((e => {
                                    a.status = "rejected", a.reason = e, m(["reject", [n], e])
                                }));
                                else {
                                    !c.has(a) && s(a) && (b = g(a));
                                    const e = !d.has(b) && c.get(b);
                                    e && ((e, t) => {
                                        if (y.has(e)) throw new Error("prop listener already exists");
                                        if (h.size) {
                                            const s = t[3](w(e));
                                            y.set(e, [t, s])
                                        } else y.set(e, [t])
                                    })(n, e)
                                }
                                return Reflect.set(t, n, b, i), m(["set", [n], a, f]), !0
                            }
                        },
                        W = t(I, C);
                    p.set(n, W);
                    const E = [I, (e = ++f[1]) => (b === e || h.size || (b = e, y.forEach((([t]) => {
                        const s = t[1](e);
                        s > i && (i = s)
                    }))), i), u, e => {
                        h.add(e), 1 === h.size && y.forEach((([e, t], s) => {
                            if (t) throw new Error("remove already exists");
                            const o = e[3](w(s));
                            y.set(s, [e, o])
                        }));
                        return () => {
                            h.delete(e), 0 === h.size && y.forEach((([e, t], s) => {
                                t && (t(), y.set(s, [e]))
                            }))
                        }
                    }];
                    return c.set(W, E), Reflect.ownKeys(n).forEach((e => {
                        const t = Object.getOwnPropertyDescriptor(n, e);
                        "value" in t && (W[e] = n[e], delete t.value, delete t.writable), Object.defineProperty(I, e, t)
                    })), W
                })) => [g, c, d, e, t, s, n, a, u, p, f],
                [p] = u();

            function f(e = {}) {
                return p(e)
            }

            function g(e, t, s) {
                const o = c.get(e);
                let n;
                o || console.warn("Please use proxy object");
                const a = [],
                    r = o[3];
                let i = !1;
                const l = r((e => {
                    a.push(e), s ? t(a.splice(0)) : n || (n = Promise.resolve().then((() => {
                        n = void 0, i && t(a.splice(0))
                    })))
                }));
                return i = !0, () => {
                    i = !1, l()
                }
            }
            var h = s(48764);
            const m = f({
                    history: ["ConnectWallet"],
                    view: "ConnectWallet",
                    data: void 0
                }),
                b = {
                    state: m,
                    subscribe: e => g(m, (() => e(m))),
                    push(e, t) {
                        e !== m.view && (m.view = e, t && (m.data = t), m.history.push(e))
                    },
                    reset(e) {
                        m.view = e, m.history = [e]
                    },
                    replace(e) {
                        m.history.length > 1 && (m.history[m.history.length - 1] = e, m.view = e)
                    },
                    goBack() {
                        if (m.history.length > 1) {
                            m.history.pop();
                            const [e] = m.history.slice(-1);
                            m.view = e
                        }
                    },
                    setData(e) {
                        m.data = e
                    }
                },
                w = {
                    WALLETCONNECT_DEEPLINK_CHOICE: "WALLETCONNECT_DEEPLINK_CHOICE",
                    WCM_VERSION: "WCM_VERSION",
                    RECOMMENDED_WALLET_AMOUNT: 9,
                    isMobile: () => typeof window < "u" && Boolean(window.matchMedia("(pointer:coarse)").matches || /Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini/u.test(navigator.userAgent)),
                    isAndroid: () => w.isMobile() && navigator.userAgent.toLowerCase().includes("android"),
                    isIos() {
                        const e = navigator.userAgent.toLowerCase();
                        return w.isMobile() && (e.includes("iphone") || e.includes("ipad"))
                    },
                    isHttpUrl: e => e.startsWith("http://") || e.startsWith("https://"),
                    isArray: e => Array.isArray(e) && e.length > 0,
                    formatNativeUrl(e, t, s) {
                        if (w.isHttpUrl(e)) return this.formatUniversalUrl(e, t, s);
                        let o = e;
                        o.includes("://") || (o = e.replaceAll("/", "").replaceAll(":", ""), o = `${o}://`), o.endsWith("/") || (o = `${o}/`), this.setWalletConnectDeepLink(o, s);
                        return `${o}wc?uri=${encodeURIComponent(t)}`
                    },
                    formatUniversalUrl(e, t, s) {
                        if (!w.isHttpUrl(e)) return this.formatNativeUrl(e, t, s);
                        let o = e;
                        o.endsWith("/") || (o = `${o}/`), this.setWalletConnectDeepLink(o, s);
                        return `${o}wc?uri=${encodeURIComponent(t)}`
                    },
                    wait: async e => new Promise((t => {
                        setTimeout(t, e)
                    })),
                    openHref(e, t) {
                        window.open(e, t, "noreferrer noopener")
                    },
                    setWalletConnectDeepLink(e, t) {
                        try {
                            localStorage.setItem(w.WALLETCONNECT_DEEPLINK_CHOICE, JSON.stringify({
                                href: e,
                                name: t
                            }))
                        } catch {
                            console.info("Unable to set WalletConnect deep link")
                        }
                    },
                    setWalletConnectAndroidDeepLink(e) {
                        try {
                            const [t] = e.split("?");
                            localStorage.setItem(w.WALLETCONNECT_DEEPLINK_CHOICE, JSON.stringify({
                                href: t,
                                name: "Android"
                            }))
                        } catch {
                            console.info("Unable to set WalletConnect android deep link")
                        }
                    },
                    removeWalletConnectDeepLink() {
                        try {
                            localStorage.removeItem(w.WALLETCONNECT_DEEPLINK_CHOICE)
                        } catch {
                            console.info("Unable to remove WalletConnect deep link")
                        }
                    },
                    setModalVersionInStorage() {
                        try {
                            typeof localStorage < "u" && localStorage.setItem(w.WCM_VERSION, "2.5.9")
                        } catch {
                            console.info("Unable to set Web3Modal version in storage")
                        }
                    },
                    getWalletRouterData() {
                        var e;
                        const t = null == (e = b.state.data) ? void 0 : e.Wallet;
                        if (!t) throw new Error('Missing "Wallet" view data');
                        return t
                    }
                },
                y = f({
                    enabled: typeof location < "u" && (location.hostname.includes("localhost") || location.protocol.includes("https")),
                    userSessionId: "",
                    events: [],
                    connectedWalletId: void 0
                }),
                v = {
                    state: y,
                    subscribe: e => g(y.events, (() => e(function(e, t) {
                        const s = c.get(e);
                        s || console.warn("Please use proxy object");
                        const [o, n, a] = s;
                        return a(o, n(), t)
                    }(y.events[y.events.length - 1])))),
                    initialize() {
                        y.enabled && typeof(null == crypto ? void 0 : crypto.randomUUID) < "u" && (y.userSessionId = crypto.randomUUID())
                    },
                    setConnectedWalletId(e) {
                        y.connectedWalletId = e
                    },
                    click(e) {
                        if (y.enabled) {
                            const t = {
                                type: "CLICK",
                                name: e.name,
                                userSessionId: y.userSessionId,
                                timestamp: Date.now(),
                                data: e
                            };
                            y.events.push(t)
                        }
                    },
                    track(e) {
                        if (y.enabled) {
                            const t = {
                                type: "TRACK",
                                name: e.name,
                                userSessionId: y.userSessionId,
                                timestamp: Date.now(),
                                data: e
                            };
                            y.events.push(t)
                        }
                    },
                    view(e) {
                        if (y.enabled) {
                            const t = {
                                type: "VIEW",
                                name: e.name,
                                userSessionId: y.userSessionId,
                                timestamp: Date.now(),
                                data: e
                            };
                            y.events.push(t)
                        }
                    }
                },
                I = f({
                    chains: void 0,
                    walletConnectUri: void 0,
                    isAuth: !1,
                    isCustomDesktop: !1,
                    isCustomMobile: !1,
                    isDataLoaded: !1,
                    isUiLoaded: !1
                }),
                C = {
                    state: I,
                    subscribe: e => g(I, (() => e(I))),
                    setChains(e) {
                        I.chains = e
                    },
                    setWalletConnectUri(e) {
                        I.walletConnectUri = e
                    },
                    setIsCustomDesktop(e) {
                        I.isCustomDesktop = e
                    },
                    setIsCustomMobile(e) {
                        I.isCustomMobile = e
                    },
                    setIsDataLoaded(e) {
                        I.isDataLoaded = e
                    },
                    setIsUiLoaded(e) {
                        I.isUiLoaded = e
                    },
                    setIsAuth(e) {
                        I.isAuth = e
                    }
                },
                W = f({
                    projectId: "",
                    mobileWallets: void 0,
                    desktopWallets: void 0,
                    walletImages: void 0,
                    chains: void 0,
                    enableAuthMode: !1,
                    enableExplorer: !0,
                    explorerExcludedWalletIds: void 0,
                    explorerRecommendedWalletIds: void 0,
                    termsOfServiceUrl: void 0,
                    privacyPolicyUrl: void 0
                }),
                E = {
                    state: W,
                    subscribe: e => g(W, (() => e(W))),
                    setConfig(e) {
                        var t, s;
                        v.initialize(), C.setChains(e.chains), C.setIsAuth(Boolean(e.enableAuthMode)), C.setIsCustomMobile(Boolean(null == (t = e.mobileWallets) ? void 0 : t.length)), C.setIsCustomDesktop(Boolean(null == (s = e.desktopWallets) ? void 0 : s.length)), w.setModalVersionInStorage(), Object.assign(W, e)
                    }
                },
                O = "https://explorer-api.walletconnect.com";
            async function L(e, t) {
                const s = new URL(e, O);
                return s.searchParams.append("projectId", E.state.projectId), Object.entries(t).forEach((([e, t]) => {
                    t && s.searchParams.append(e, String(t))
                })), (await fetch(s)).json()
            }
            const A = {
                getDesktopListings: async e => L("/w3m/v1/getDesktopListings", e),
                getMobileListings: async e => L("/w3m/v1/getMobileListings", e),
                getInjectedListings: async e => L("/w3m/v1/getInjectedListings", e),
                getAllListings: async e => L("/w3m/v1/getAllListings", e),
                getWalletImageUrl: e => `${O}/w3m/v1/getWalletImage/${e}?projectId=${E.state.projectId}`,
                getAssetImageUrl: e => `${O}/w3m/v1/getAssetImage/${e}?projectId=${E.state.projectId}`
            };
            var j = Object.defineProperty,
                M = Object.getOwnPropertySymbols,
                U = Object.prototype.hasOwnProperty,
                k = Object.prototype.propertyIsEnumerable,
                D = (e, t, s) => t in e ? j(e, t, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: s
                }) : e[t] = s;
            const P = w.isMobile(),
                S = f({
                    wallets: {
                        listings: [],
                        total: 0,
                        page: 1
                    },
                    search: {
                        listings: [],
                        total: 0,
                        page: 1
                    },
                    recomendedWallets: []
                }),
                N = {
                    state: S,
                    async getRecomendedWallets() {
                        const {
                            explorerRecommendedWalletIds: e,
                            explorerExcludedWalletIds: t
                        } = E.state;
                        if ("NONE" === e || "ALL" === t && !e) return S.recomendedWallets;
                        if (w.isArray(e)) {
                            const t = {
                                    recommendedIds: e.join(",")
                                },
                                {
                                    listings: s
                                } = await A.getAllListings(t),
                                o = Object.values(s);
                            o.sort(((t, s) => e.indexOf(t.id) - e.indexOf(s.id))), S.recomendedWallets = o
                        } else {
                            const {
                                chains: e,
                                isAuth: s
                            } = C.state, o = e ? .join(","), n = w.isArray(t), a = {
                                page: 1,
                                sdks: s ? "auth_v1" : void 0,
                                entries: w.RECOMMENDED_WALLET_AMOUNT,
                                chains: o,
                                version: 2,
                                excludedIds: n ? t.join(",") : void 0
                            }, {
                                listings: r
                            } = P ? await A.getMobileListings(a) : await A.getDesktopListings(a);
                            S.recomendedWallets = Object.values(r)
                        }
                        return S.recomendedWallets
                    },
                    async getWallets(e) {
                        const t = ((e, t) => {
                                for (var s in t || (t = {})) U.call(t, s) && D(e, s, t[s]);
                                if (M)
                                    for (var s of M(t)) k.call(t, s) && D(e, s, t[s]);
                                return e
                            })({}, e),
                            {
                                explorerRecommendedWalletIds: s,
                                explorerExcludedWalletIds: o
                            } = E.state,
                            {
                                recomendedWallets: n
                            } = S;
                        if ("ALL" === o) return S.wallets;
                        n.length ? t.excludedIds = n.map((e => e.id)).join(",") : w.isArray(s) && (t.excludedIds = s.join(",")), w.isArray(o) && (t.excludedIds = [t.excludedIds, o].filter(Boolean).join(",")), C.state.isAuth && (t.sdks = "auth_v1");
                        const {
                            page: a,
                            search: r
                        } = e, {
                            listings: i,
                            total: l
                        } = P ? await A.getMobileListings(t) : await A.getDesktopListings(t), c = Object.values(i), d = r ? "search" : "wallets";
                        return S[d] = {
                            listings: [...S[d].listings, ...c],
                            total: l,
                            page: a ? ? 1
                        }, {
                            listings: c,
                            total: l
                        }
                    },
                    getWalletImageUrl: e => A.getWalletImageUrl(e),
                    getAssetImageUrl: e => A.getAssetImageUrl(e),
                    resetSearch() {
                        S.search = {
                            listings: [],
                            total: 0,
                            page: 1
                        }
                    }
                },
                x = f({
                    open: !1
                }),
                R = {
                    state: x,
                    subscribe: e => g(x, (() => e(x))),
                    open: async e => new Promise((t => {
                        const {
                            isUiLoaded: s,
                            isDataLoaded: o
                        } = C.state;
                        if (C.setWalletConnectUri(e ? .uri), C.setChains(e ? .chains), b.reset("ConnectWallet"), s && o) x.open = !0, t();
                        else {
                            const e = setInterval((() => {
                                const s = C.state;
                                s.isUiLoaded && s.isDataLoaded && (clearInterval(e), x.open = !0, t())
                            }), 200)
                        }
                    })),
                    close() {
                        x.open = !1
                    }
                };
            var _ = Object.defineProperty,
                T = Object.getOwnPropertySymbols,
                $ = Object.prototype.hasOwnProperty,
                B = Object.prototype.propertyIsEnumerable,
                V = (e, t, s) => t in e ? _(e, t, {
                    enumerable: !0,
                    configurable: !0,
                    writable: !0,
                    value: s
                }) : e[t] = s;
            const z = f({
                    themeMode: typeof matchMedia < "u" && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"
                }),
                H = {
                    state: z,
                    subscribe: e => g(z, (() => e(z))),
                    setThemeConfig(e) {
                        const {
                            themeMode: t,
                            themeVariables: s
                        } = e;
                        t && (z.themeMode = t), s && (z.themeVariables = ((e, t) => {
                            for (var s in t || (t = {})) $.call(t, s) && V(e, s, t[s]);
                            if (T)
                                for (var s of T(t)) B.call(t, s) && V(e, s, t[s]);
                            return e
                        })({}, s))
                    }
                },
                K = f({
                    open: !1,
                    message: "",
                    variant: "success"
                }),
                J = {
                    state: K,
                    subscribe: e => g(K, (() => e(K))),
                    openToast(e, t) {
                        K.open = !0, K.message = e, K.variant = t
                    },
                    closeToast() {
                        K.open = !1
                    }
                };
            typeof window < "u" && (window.Buffer || (window.Buffer = h.Buffer), window.global || (window.global = window), window.process || (window.process = {
                env: {}
            }), window.global || (window.global = window))
        },
        59343: function(e, t, s) {
            s.r(t), s.d(t, {
                WalletConnectModal: function() {
                    return n
                }
            });
            var o = s(75740);
            class n {
                constructor(e) {
                    this.openModal = o.jb.open, this.closeModal = o.jb.close, this.subscribeModal = o.jb.subscribe, this.setTheme = o.Ic.setThemeConfig, o.Ic.setThemeConfig(e), o.t0.setConfig(e), this.initUi()
                }
                async initUi() {
                    if (typeof window < "u") {
                        await Promise.all([s.e(2592), s.e(6909)]).then(s.bind(s, 56909));
                        const e = document.createElement("wcm-modal");
                        document.body.insertAdjacentElement("beforeend", e), o.zb.setIsUiLoaded(!0)
                    }
                }
            }
        }
    }
]);