"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [5029], {
        67647: function(e, t, n) {
            n.r(t), n.d(t, {
                chainToId: function() {
                    return A
                },
                getQuote: function() {
                    return E
                },
                getTx: function() {
                    return O
                },
                getTxData: function() {
                    return C
                },
                name: function() {
                    return T
                },
                swap: function() {
                    return D
                },
                token: function() {
                    return g
                }
            });
            var a = n(47568),
                r = n(26042),
                o = n(70655),
                i = n(9279),
                u = n(64146),
                s = n(2593),
                p = n(38673),
                c = n(14481);

            function d(e) {
                return e.toHexString().replace("0x01", "0x")
            }

            function l(e, t, n, a, r, o, i) {
                var u = s.O$.from(1).shl(4).add(e).shl(1);
                t && (u = u.add(1)), u = u.shl(17);
                for (var p = 0, c = s.O$.from(n); c.gt(131071);) p++, c = c.div(2);
                c.lt(131071) && (c = c.add(1)), u = u.add(c).shl(8).add(p);
                var l = ["0.5", "0.1", "1", "5"].findIndex((function(e) {
                    return e === a
                }));
                if (-1 === l) throw new Error("Slippage number not supported");
                if (u = u.shl(2).add(l), r || o) return d(u);
                for (var m = 0, y = s.O$.from(i); y.mod(10).isZero() && !y.isZero();) m++, y = y.div(10);
                u = u.shl(5).add(m);
                var f = function(e) {
                        for (var t = 0, n = s.O$.from(e); !n.isZero();) n = n.div(2), t++;
                        return t
                    }(y),
                    b = f % 8;
                return d((u = u.shl(f + (b <= 3 ? 3 - b : 11 - b))).add(y))
            }
            var m = n(828),
                y = {
                    weth: "0x4200000000000000000000000000000000000006",
                    usdc: "0x7F5c764cBc14f9669B88837ca1490cCa17c31607",
                    op: "0x4200000000000000000000000000000000000042",
                    snx: "0x8700dAec35aF8Ff88c16BdF0418774CB3D7599B4",
                    dai: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
                    susd: "0x8c6f28f2F1A3C87F0f938b96d27520d9751ec8d9",
                    wbtc: "0x68f180fcCe6836688e9084f035309E29Bf0A2095",
                    thales: "0x217D47011b23BB961eB6D93cA9945B7501a5BB11",
                    usdt: "0x94b008aA00579c1307B0EF2c499aD98a8ce58e58",
                    perp: "0x9e1028F5F1D5eDE59748FFceE5532509976840E0",
                    velo: "0x3c8B650257cFb5f272f799F5e2b4e65093a11a05"
                },
                f = {
                    weth: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1",
                    usdc: "0xFF970A61A04b1cA14834A43f5dE4533eBDDB5CC8",
                    usdt: "0xFd086bC7CD5C481DCC9C85ebE478A1C0b69FCbb9",
                    gmx: "0xfc5A1A6EB076a2C7aD06eD22C90d7E710E35ad0a",
                    dai: "0xDA10009cBd5D07dd0CeCc66161FC93D7c9000da1",
                    wbtc: "0x2f2a2543B76A4166549F7aaB2e75Bef0aefC5B0f",
                    gns: "0x18c11FD286C5EC11c3b683Caa813B77f5163A122",
                    magic: "0x539bdE0d7Dbd336b79148AA742883198BBF60342",
                    arb: "0x912CE59144191C1204E64559FE8253a0e49E6548"
                },
                b = function(e, t) {
                    return s.O$.from(e).lt(t) ? [e.toLowerCase(), t.toLowerCase()] : [t.toLowerCase(), e.toLowerCase()]
                },
                h = function(e, t, n, a) {
                    var r = arguments.length > 4 && void 0 !== arguments[4] && arguments[4],
                        o = (0, m.Z)(b(e, t), 2),
                        i = o[0],
                        u = o[1];
                    return {
                        name: "".concat(i, "-").concat(u),
                        pairId: a,
                        token0: i,
                        token1: u,
                        fee: n,
                        mayFail: r
                    }
                },
                v = {
                    optimism: function() {
                        var e = y;
                        return [h(e.weth, e.usdc, "500", "0"), h(e.weth, e.op, "3000", "1"), h(e.op, e.usdc, "3000", "2"), h(e.weth, e.op, "500", "3"), h(e.usdc, e.dai, "100", "4"), h(e.snx, e.weth, "3000", "5"), h(e.weth, e.dai, "3000", "6")]
                    }(),
                    arbitrum: function() {
                        var e = f;
                        return [h(e.weth, e.usdc, "500", "0"), h(e.weth, e.usdt, "500", "1"), h(e.weth, e.wbtc, "500", "2"), h(e.weth, e.gmx, "3000", "3"), h(e.weth, e.gns, "3000", "4"), h(e.weth, e.magic, "10000", "5"), h(e.weth, e.dai, "3000", "6"), h(e.weth, e.arb, "10000", "7"), h(e.weth, e.arb, "3000", "8", !0), h(e.weth, e.arb, "500", "9", !0), h(e.weth, e.arb, "100", "10", !0)]
                    }()
                },
                T = "LlamaZip",
                g = "none",
                A = {
                    optimism: "0x6f9d14Cf4A06Dd9C70766Bd161cf8d4387683E1b",
                    arbitrum: "0x973bf562407766e77f885c1cd1a8060e5303C745"
                },
                w = {
                    optimism: "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6",
                    arbitrum: "0xb27308f9F90D607463bb33eA1BeBb41C27CE5AB6"
                },
                x = {
                    optimism: "0x4200000000000000000000000000000000000006",
                    arbitrum: "0x82aF49447D8a07e3bd95BD0d56f35241523fBab1"
                };

            function k(e, t) {
                return (e === i.d ? t : e).toLowerCase()
            }

            function E(e, t, n, a, r) {
                return _.apply(this, arguments)
            }

            function _() {
                return _ = (0, a.Z)((function(e, t, n, c, d) {
                    var m, y, f, h, T, g, E, _, D, F, C, O;
                    return (0, o.__generator)(this, (function(B) {
                        switch (B.label) {
                            case 0:
                                return n.toLowerCase() === x[e].toLowerCase() ? [2, {}] : (m = p.a[e], y = new u.CH(w[e], ["function quoteExactInputSingle(address tokenIn,address tokenOut,uint24 fee,uint256 amountIn,uint160 sqrtPriceLimitX96) external returns (uint256 amountOut)"], m), f = k(t, x[e]), h = k(n, x[e]), T = s.O$.from(f).lt(h), 0 === (g = v[e].filter((function(e) {
                                    return e.name === b(f, h).join("-")
                                }))).length ? [2, {}] : [4, Promise.all(g.map(function() {
                                    var e = (0, a.Z)((function(e) {
                                        var t, n;
                                        return (0, o.__generator)(this, (function(a) {
                                            switch (a.label) {
                                                case 0:
                                                    return a.trys.push([0, 2, , 3]), t = {}, [4, y.callStatic.quoteExactInputSingle(f, h, e.fee, c, 0)];
                                                case 1:
                                                    return [2, (t.output = a.sent(), t.pair = e, t)];
                                                case 2:
                                                    if (n = a.sent(), !0 === e.mayFail) return [2, null];
                                                    throw n;
                                                case 3:
                                                    return [2]
                                            }
                                        }))
                                    }));
                                    return function(t) {
                                        return e.apply(this, arguments)
                                    }
                                }()))]);
                            case 1:
                                return E = B.sent().filter((function(e) {
                                    return null !== e
                                })), _ = E.sort((function(e, t) {
                                    return t.output.gt(e.output) ? 1 : -1
                                }))[0], D = _.pair, F = _.output, C = t === i.d, (O = l(D.pairId, T, F, d.slippage, C, !1, c)).length > 66 ? [2, {}] : [2, {
                                    amountReturned: F.toString(),
                                    estimatedGas: 2e5.toString(),
                                    rawQuote: {
                                        tx: (0, r.Z)({
                                            to: A[e],
                                            data: O
                                        }, C ? {
                                            value: c
                                        } : {})
                                    },
                                    tokenApprovalAddress: A[e],
                                    logo: "https://raw.githubusercontent.com/DefiLlama/memes/master/bussin.jpg"
                                }]
                        }
                    }))
                })), _.apply(this, arguments)
            }

            function D(e) {
                return F.apply(this, arguments)
            }

            function F() {
                return (F = (0, a.Z)((function(e) {
                    var t, n, a, r;
                    return (0, o.__generator)(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, [4, t.getAddress()];
                            case 1:
                                return r = o.sent(), [4, (0, c.p)(t, a, {
                                    from: r,
                                    to: n.tx.to,
                                    data: n.tx.data,
                                    value: n.tx.value
                                })];
                            case 2:
                                return [2, o.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var C = function(e) {
                    var t, n = e.rawQuote;
                    return null === n || void 0 === n || null === (t = n.tx) || void 0 === t ? void 0 : t.data
                },
                O = function(e) {
                    var t = e.rawQuote;
                    return null === t || void 0 === t ? void 0 : t.tx
                }
        },
        35324: function(e, t, n) {
            n.d(t, {
                T: function() {
                    return o
                },
                g: function() {
                    return i
                }
            });
            var a = n(47568),
                r = n(70655),
                o = function() {
                    var e = (0, a.Z)((function(e, t, n, a, o, i) {
                        return (0, r.__generator)(this, (function(r) {
                            switch (r.label) {
                                case 0:
                                    return [4, fetch("https://swap-api.defillama.com/dexAggregatorQuote?protocol=".concat(e, "&chain=").concat(t, "&from=").concat(n, "&to=").concat(a, "&amount=").concat(o, "&api_key=zT82BQ38E5unVRDGswzgUzfM2yyaQBK8mFBrzTzX6s"), {
                                        method: "POST",
                                        body: JSON.stringify(i)
                                    }).then((function(e) {
                                        return e.json()
                                    }))];
                                case 1:
                                    return [2, r.sent()]
                            }
                        }))
                    }));
                    return function(t, n, a, r, o, i) {
                        return e.apply(this, arguments)
                    }
                }(),
                i = function() {
                    var e = (0, a.Z)((function(e) {
                        return (0, r.__generator)(this, (function(t) {
                            switch (t.label) {
                                case 0:
                                    return [4, fetch("https://api.llama.fi/storeAggregatorEvent", {
                                        method: "POST",
                                        body: JSON.stringify(e)
                                    }).then((function(e) {
                                        return e.json()
                                    }))];
                                case 1:
                                    return [2, t.sent()]
                            }
                        }))
                    }));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }()
        },
        47787: function(e, t, n) {
            n.d(t, {
                Aw: function() {
                    return b
                },
                DX: function() {
                    return f
                },
                Hi: function() {
                    return c
                },
                LD: function() {
                    return p
                },
                Ms: function() {
                    return o
                },
                O0: function() {
                    return r
                },
                Uo: function() {
                    return u
                },
                XX: function() {
                    return l
                },
                cB: function() {
                    return m
                },
                gS: function() {
                    return h
                },
                is: function() {
                    return d
                },
                pi: function() {
                    return y
                },
                r8: function() {
                    return s
                },
                yR: function() {
                    return v
                },
                zk: function() {
                    return i
                }
            });
            var a = n(828),
                r = "0x08a3c2A819E3de7ACa384c798269B3Ce1CD0e437",
                o = "0xa43C3EDe995AA058B68B882c6aF16863F18c5330",
                i = {
                    ethereum: 1,
                    bsc: 56,
                    polygon: 137,
                    optimism: 10,
                    arbitrum: 42161,
                    avax: 43114,
                    gnosis: 100,
                    fantom: 250,
                    klaytn: 8217,
                    aurora: 1313161554,
                    celo: 42220,
                    cronos: 25,
                    dogechain: 2e3,
                    moonriver: 1285,
                    bttc: 199,
                    oasis: 42262,
                    velas: 106,
                    heco: 128,
                    harmony: 16666e5,
                    boba: 288,
                    okexchain: 66,
                    fuse: 122,
                    moonbeam: 1284,
                    canto: 7700,
                    zksync: 324,
                    polygonzkevm: 1101,
                    ontology: 58,
                    kava: 2222,
                    pulse: 369,
                    metis: 1088,
                    base: 8453
                },
                u = {
                    ethereum: 1,
                    "binance-smart-chain": 56,
                    "polygon-pos": 137,
                    "optimistic-ethereum": 10,
                    "arbitrum-one": 42161,
                    avalanche: 43114,
                    xdai: 100,
                    fantom: 250,
                    "klay-token": 8217,
                    aurora: 1313161554,
                    celo: 42220,
                    cronos: 25,
                    dogechain: 2e3,
                    moonriver: 1285,
                    bittorrent: 199,
                    oasis: 42262,
                    velas: 106,
                    heco: 128,
                    "harmony-shard-0": 16666e5,
                    boba: 288,
                    "okex-chain": 66,
                    fuse: 122,
                    moonbeam: 1284,
                    canto: 7700,
                    "polygon-zkevm": 1101,
                    zksync: 324,
                    pulsechain: 369,
                    kava: 2222,
                    ontology: 58,
                    "metis-andromeda": 1088
                },
                s = {
                    ethereum: "ethereum",
                    bsc: "binancecoin",
                    polygon: "matic-network",
                    optimism: "ethereum",
                    arbitrum: "ethereum",
                    avax: "avalanche-2",
                    gnosis: "xdai",
                    fantom: "fantom",
                    klaytn: "klay-token",
                    aurora: "ethereum",
                    celo: "celo",
                    cronos: "crypto-com-chain",
                    dogechain: "dogecoin",
                    moonriver: "moonriver",
                    bttc: "bittorrent",
                    oasis: "oasis-network",
                    velas: "velas",
                    heco: "huobi-token",
                    harmony: "harmony",
                    boba: "ethereum",
                    okexchain: "oec-token",
                    fuse: "fuse-network-token",
                    moonbeam: "moonbeam",
                    canto: "canto",
                    zksync: "ethereum",
                    polygonzkevm: "ethereum",
                    ontology: "ontology",
                    kava: "kava",
                    pulse: "pulsechain",
                    metis: "metis-token",
                    base: "ethereum"
                },
                p = Object.fromEntries(Object.entries(i).map((function(e) {
                    var t = (0, a.Z)(e, 2),
                        n = t[0],
                        r = t[1],
                        o = Object.entries(u).find((function(e) {
                            return r === e[1]
                        }));
                    return o ? [n, o[0]] : null
                })).filter((function(e) {
                    return null !== e
                }))),
                c = {
                    1: "ether",
                    56: "bsc",
                    137: "polygon",
                    10: "optimism",
                    42161: "arbitrum",
                    43114: "avalanche",
                    100: "gnosis",
                    250: "fantom",
                    1313161554: "aurora",
                    42220: "celo",
                    25: "cronos",
                    2e3: "dogechain",
                    1285: "moonriver",
                    42262: "oasis",
                    106: "velas",
                    128: "heco",
                    16666e5: "harmony",
                    288: "boba",
                    66: "okc",
                    122: "fuse",
                    1284: "moonbeam",
                    199: "bittorrent",
                    8217: "klay",
                    7700: "canto",
                    2222: "kava",
                    369: "pulse",
                    1101: "polygonzkevm",
                    324: "zksync",
                    58: "ontology",
                    1088: "metis",
                    8453: "base"
                },
                d = function(e) {
                    var t;
                    return null === (t = Object.entries(i).find((function(t) {
                        var n = (0, a.Z)(t, 2)[1];
                        return String(n) === String(e)
                    }))) || void 0 === t ? void 0 : t[0]
                },
                l = {
                    bsc: "BSC",
                    avax: "Avalanche",
                    okexchain: "OKTChain",
                    bttc: "BitTorrent"
                },
                m = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE".toLowerCase(),
                y = [500, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8, 5e8],
                f = {
                    ethereum: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2".toLowerCase()
                },
                b = 5,
                h = 10,
                v = 3
        },
        59067: function(e, t, n) {
            n.d(t, {
                j$: function() {
                    return Rt
                },
                cn: function() {
                    return Pt
                },
                D2: function() {
                    return Lt
                }
            });
            var a = {};
            n.r(a), n.d(a, {
                approvalAddress: function() {
                    return _
                },
                chainToId: function() {
                    return w
                },
                getQuote: function() {
                    return F
                },
                getTx: function() {
                    return S
                },
                getTxData: function() {
                    return Z
                },
                isOutputAvailable: function() {
                    return E
                },
                name: function() {
                    return x
                },
                swap: function() {
                    return O
                },
                token: function() {
                    return k
                }
            });
            var r = {};
            n.r(r), n.d(r, {
                approvalAddress: function() {
                    return H
                },
                chainToId: function() {
                    return P
                },
                getQuote: function() {
                    return Y
                },
                getTx: function() {
                    return $
                },
                getTxData: function() {
                    return W
                },
                name: function() {
                    return j
                },
                referral: function() {
                    return z
                },
                swap: function() {
                    return U
                },
                token: function() {
                    return G
                }
            });
            var o = {};
            n.r(o), n.d(o, {
                approvalAddress: function() {
                    return ce
                },
                chainToId: function() {
                    return ae
                },
                getQuote: function() {
                    return me
                },
                getTx: function() {
                    return ve
                },
                getTxData: function() {
                    return he
                },
                isOutputAvailable: function() {
                    return pe
                },
                name: function() {
                    return ie
                },
                referral: function() {
                    return se
                },
                swap: function() {
                    return fe
                },
                token: function() {
                    return ue
                }
            });
            var i = {};
            n.r(i), n.d(i, {
                approvalAddress: function() {
                    return xe
                },
                chainToId: function() {
                    return Te
                },
                getQuote: function() {
                    return De
                },
                getTx: function() {
                    return Ze
                },
                getTxData: function() {
                    return Be
                },
                name: function() {
                    return Ae
                },
                swap: function() {
                    return Ce
                },
                token: function() {
                    return we
                }
            });
            var u = {};
            n.r(u), n.d(u, {
                approvalAddress: function() {
                    return Me
                },
                chainToId: function() {
                    return Se
                },
                getQuote: function() {
                    return Re
                },
                getTx: function() {
                    return Ge
                },
                getTxData: function() {
                    return je
                },
                name: function() {
                    return Ie
                },
                swap: function() {
                    return Pe
                },
                token: function() {
                    return qe
                }
            });
            var s = {};
            n.r(s), n.d(s, {
                chainToId: function() {
                    return Xe
                },
                getQuote: function() {
                    return We
                },
                getTx: function() {
                    return nt
                },
                getTxData: function() {
                    return tt
                },
                isOutputAvailable: function() {
                    return Ue
                },
                name: function() {
                    return Ye
                },
                swap: function() {
                    return Je
                },
                token: function() {
                    return Ve
                }
            });
            var p = {};
            n.r(p), n.d(p, {
                approvalAddress: function() {
                    return it
                },
                chainToId: function() {
                    return at
                },
                getQuote: function() {
                    return ut
                },
                getTx: function() {
                    return lt
                },
                getTxData: function() {
                    return dt
                },
                name: function() {
                    return rt
                },
                swap: function() {
                    return pt
                },
                token: function() {
                    return ot
                }
            });
            var c = {};
            n.r(c), n.d(c, {
                approvalAddress: function() {
                    return vt
                },
                chainToId: function() {
                    return mt
                },
                getQuote: function() {
                    return gt
                },
                getTx: function() {
                    return Et
                },
                getTxData: function() {
                    return kt
                },
                isOutputAvailable: function() {
                    return ht
                },
                name: function() {
                    return yt
                },
                partner: function() {
                    return bt
                },
                swap: function() {
                    return wt
                },
                token: function() {
                    return ft
                }
            });
            var d = {};
            n.r(d), n.d(d, {
                approvalAddress: function() {
                    return Bt
                },
                chainToId: function() {
                    return Ft
                },
                getQuote: function() {
                    return St
                },
                name: function() {
                    return Ct
                },
                swap: function() {
                    return qt
                },
                token: function() {
                    return Ot
                }
            });
            var l = n(14924),
                m = n(47568),
                y = n(26042),
                f = n(69396),
                b = n(70655),
                h = n(70794),
                v = n(9279),
                T = n(47787),
                g = n(14481),
                A = n(83454),
                w = {
                    ethereum: "https://api.0x.org/",
                    bsc: "https://bsc.api.0x.org/",
                    polygon: "https://polygon.api.0x.org/",
                    optimism: "https://optimism.api.0x.org/",
                    arbitrum: "https://arbitrum.api.0x.org/",
                    avax: "https://avalanche.api.0x.org/",
                    fantom: "https://fantom.api.0x.org/",
                    celo: "https://celo.api.0x.org/",
                    base: "http://base.api.0x.org "
                },
                x = "Matcha/0x",
                k = "ZRX",
                E = !0;

            function _() {
                return "0xdef1c0ded9bec7f1a1670819833240f027b25eff"
            }
            var D = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";

            function F(e, t, n, a, r) {
                return C.apply(this, arguments)
            }

            function C() {
                return (C = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p;
                    return (0, b.__generator)(this, (function(c) {
                        switch (c.label) {
                            case 0:
                                return o = t === v.d ? D : t, i = n === v.d ? D : n, u = r.amountOut && "0" !== r.amountOut ? "buyAmount=".concat(r.amountOut) : "sellAmount=".concat(a), [4, fetch("".concat(w[e], "swap/v1/quote?buyToken=").concat(i, "&").concat(u, "&sellToken=").concat(o, "&slippagePercentage=").concat(r.slippage / 100, "&affiliateAddress=").concat(T.O0, "&enableSlippageProtection=false&intentOnFilling=true&takerAddress=").concat(r.userAddress, "&skipValidation=true"), {
                                    headers: {
                                        "0x-api-key": A.env.OX_API_KEY
                                    }
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                return s = c.sent(), p = "optimism" === e ? (0, h.Z)(3.5).times(s.gas).toFixed(0, 1) : s.gas, [2, {
                                    amountReturned: (null === s || void 0 === s ? void 0 : s.buyAmount) || 0,
                                    amountIn: (null === s || void 0 === s ? void 0 : s.sellAmount) || 0,
                                    estimatedGas: p,
                                    tokenApprovalAddress: s.to,
                                    rawQuote: (0, f.Z)((0, y.Z)({}, s), {
                                        gasLimit: p
                                    }),
                                    logo: "https://www.gitbook.com/cdn-cgi/image/width=40,height=40,fit=contain,dpr=2,format=auto/https%3A%2F%2F1690203644-files.gitbook.io%2F~%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FKX9pG8rH3DbKDOvV7di7%252Ficon%252F1nKfBhLbPxd2KuXchHET%252F0x%2520logo.png%3Falt%3Dmedia%26token%3D25a85a3e-7f72-47ea-a8b2-e28c0d24074b"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function O(e) {
                return B.apply(this, arguments)
            }

            function B() {
                return (B = (0, m.Z)((function(e) {
                    var t, n, a, r;
                    return (0, b.__generator)(this, (function(o) {
                        switch (o.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, [4, t.getAddress()];
                            case 1:
                                return r = o.sent(), [4, (0, g.p)(t, a, (0, y.Z)({
                                    from: r,
                                    to: n.to,
                                    data: n.data,
                                    value: n.value
                                }, "optimism" === a && {
                                    gasLimit: n.gasLimit
                                }))];
                            case 2:
                                return [2, o.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var Z = function(e) {
                    var t = e.rawQuote;
                    return null === t || void 0 === t ? void 0 : t.data
                },
                S = function(e) {
                    var t = e.rawQuote;
                    return {
                        to: t.to,
                        data: t.data,
                        value: t.value
                    }
                },
                I = n(828),
                q = n(64146),
                M = n(38673);

            function Q(e, t, n) {
                return R.apply(this, arguments)
            }

            function R() {
                return (R = (0, m.Z)((function(e, t, n) {
                    var a;
                    return (0, b.__generator)(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return [4, new q.CH("0x00000000000000000000000000000000000000C8", ["function gasEstimateL1Component(address to,bool contractCreation,bytes calldata data) external view returns (uint64 gasEstimateForL1,uint256 baseFee,uint256 l1BaseFeeEstimate)"], M.a.arbitrum).gasEstimateL1Component(e, !1, t)];
                            case 1:
                                return a = r.sent(), [2, n = (0, h.Z)(n).plus(a.gasEstimateForL1.toNumber()).toFixed(0, 1)]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var L = n(83454),
                P = {
                    ethereum: 1,
                    bsc: 56,
                    polygon: 137,
                    optimism: 10,
                    arbitrum: 42161,
                    gnosis: 100,
                    avax: 43114,
                    fantom: 250,
                    klaytn: 8217,
                    aurora: 1313161554
                },
                N = {
                    ethereum: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    bsc: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    polygon: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    optimism: "0x1111111254760f7ab3f16433eea9304126dcd199",
                    arbitrum: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    gnosis: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    avax: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    fantom: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    klaytn: "0x1111111254fb6c44bac0bed2854e76f90643097d",
                    aurora: "0x1111111254fb6c44bac0bed2854e76f90643097d"
                },
                j = "1inch",
                G = "1INCH",
                z = !0;

            function H(e) {
                return N[e]
            }
            var X = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";

            function Y(e, t, n, a, r) {
                return V.apply(this, arguments)
            }

            function V() {
                return (V = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d, l, m, h, g;
                    return (0, b.__generator)(this, (function(b) {
                        switch (b.label) {
                            case 0:
                                return o = t === v.d ? X : t, i = n === v.d ? X : n, u = {
                                    "auth-key": L.env.INCH_API_KEY
                                }, s = N[e], [4, Promise.all([fetch("https://api-defillama.1inch.io/v4.0/".concat(P[e], "/quote?fromTokenAddress=").concat(o, "&toTokenAddress=").concat(i, "&amount=").concat(a, "&slippage=").concat(r.slippage), {
                                    headers: u
                                }).then((function(e) {
                                    return e.json()
                                })), r.userAddress !== v.d ? fetch("https://api-defillama.1inch.io/v4.0/".concat(P[e], "/swap?fromTokenAddress=").concat(o, "&toTokenAddress=").concat(i, "&amount=").concat(a, "&fromAddress=").concat(r.userAddress, "&slippage=").concat(r.slippage, "&referrerAddress=").concat(T.Ms, "&disableEstimate=true"), {
                                    headers: u
                                }).then((function(e) {
                                    return e.json()
                                })) : null])];
                            case 1:
                                return p = I.Z.apply(void 0, [b.sent(), 2]), c = p[0], d = p[1], l = c.estimatedGas || 0, m = l, "arbitrum" !== e ? [3, 5] : null !== d ? [3, 2] : (h = null, [3, 4]);
                            case 2:
                                return [4, Q(d.tx.to, d.tx.data, m)];
                            case 3:
                                h = b.sent(), b.label = 4;
                            case 4:
                                m = h, b.label = 5;
                            case 5:
                                return [2, {
                                    amountReturned: null !== (g = null === d || void 0 === d ? void 0 : d.toTokenAmount) && void 0 !== g ? g : c.toTokenAmount,
                                    estimatedGas: m,
                                    tokenApprovalAddress: s,
                                    rawQuote: null === d ? null : (0, f.Z)((0, y.Z)({}, d), {
                                        tx: d.tx
                                    }),
                                    logo: "https://icons.llamao.fi/icons/protocols/1inch-network?w=48&q=75"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function U(e) {
                return K.apply(this, arguments)
            }

            function K() {
                return (K = (0, m.Z)((function(e) {
                    var t, n, a, r, o;
                    return (0, b.__generator)(this, (function(i) {
                        switch (i.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, r = {
                                    from: n.tx.from,
                                    to: n.tx.to,
                                    data: n.tx.data,
                                    value: n.tx.value
                                }, [4, t.estimateGas(r)];
                            case 1:
                                return o = i.sent(), [4, (0, g.p)(t, a, (0, f.Z)((0, y.Z)({}, r), {
                                    gasLimit: o.mul(12).div(10).add(86e3)
                                }))];
                            case 2:
                                return [2, i.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var W = function(e) {
                    var t, n = e.rawQuote;
                    return null === n || void 0 === n || null === (t = n.tx) || void 0 === t ? void 0 : t.data
                },
                $ = function(e) {
                    var t = e.rawQuote;
                    return null === t ? {} : {
                        from: t.tx.from,
                        to: t.tx.to,
                        data: t.tx.data,
                        value: t.tx.value
                    }
                },
                J = n(1160),
                ee = n(5276),
                te = n(16441),
                ne = [{
                    inputs: [{
                        internalType: "contract ICoWSwapSettlement",
                        name: "_cowSwapSettlement",
                        type: "address"
                    }, {
                        internalType: "contract IWrappedNativeToken",
                        name: "_wrappedNativeToken",
                        type: "address"
                    }],
                    stateMutability: "nonpayable",
                    type: "constructor"
                }, {
                    inputs: [],
                    name: "EthTransferFailed",
                    type: "error"
                }, {
                    inputs: [],
                    name: "IncorrectEthAmount",
                    type: "error"
                }, {
                    inputs: [{
                        internalType: "bytes32",
                        name: "orderHash",
                        type: "bytes32"
                    }],
                    name: "NotAllowedToInvalidateOrder",
                    type: "error"
                }, {
                    inputs: [],
                    name: "NotAllowedZeroSellAmount",
                    type: "error"
                }, {
                    inputs: [],
                    name: "OrderIsAlreadyExpired",
                    type: "error"
                }, {
                    inputs: [{
                        internalType: "bytes32",
                        name: "orderHash",
                        type: "bytes32"
                    }],
                    name: "OrderIsAlreadyOwned",
                    type: "error"
                }, {
                    inputs: [],
                    name: "ReceiverMustBeSet",
                    type: "error"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "bytes",
                        name: "orderUid",
                        type: "bytes"
                    }],
                    name: "OrderInvalidation",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "sender",
                        type: "address"
                    }, {
                        components: [{
                            internalType: "contract IERC20",
                            name: "sellToken",
                            type: "address"
                        }, {
                            internalType: "contract IERC20",
                            name: "buyToken",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "receiver",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "sellAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "buyAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint32",
                            name: "validTo",
                            type: "uint32"
                        }, {
                            internalType: "bytes32",
                            name: "appData",
                            type: "bytes32"
                        }, {
                            internalType: "uint256",
                            name: "feeAmount",
                            type: "uint256"
                        }, {
                            internalType: "bytes32",
                            name: "kind",
                            type: "bytes32"
                        }, {
                            internalType: "bool",
                            name: "partiallyFillable",
                            type: "bool"
                        }, {
                            internalType: "bytes32",
                            name: "sellTokenBalance",
                            type: "bytes32"
                        }, {
                            internalType: "bytes32",
                            name: "buyTokenBalance",
                            type: "bytes32"
                        }],
                        indexed: !1,
                        internalType: "struct GPv2Order.Data",
                        name: "order",
                        type: "tuple"
                    }, {
                        components: [{
                            internalType: "enum ICoWSwapOnchainOrders.OnchainSigningScheme",
                            name: "scheme",
                            type: "uint8"
                        }, {
                            internalType: "bytes",
                            name: "data",
                            type: "bytes"
                        }],
                        indexed: !1,
                        internalType: "struct ICoWSwapOnchainOrders.OnchainSignature",
                        name: "signature",
                        type: "tuple"
                    }, {
                        indexed: !1,
                        internalType: "bytes",
                        name: "data",
                        type: "bytes"
                    }],
                    name: "OrderPlacement",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "bytes",
                        name: "orderUid",
                        type: "bytes"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "refunder",
                        type: "address"
                    }],
                    name: "OrderRefund",
                    type: "event"
                }, {
                    inputs: [],
                    name: "cowSwapSettlement",
                    outputs: [{
                        internalType: "contract ICoWSwapSettlement",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "contract IERC20",
                            name: "buyToken",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "receiver",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "sellAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "buyAmount",
                            type: "uint256"
                        }, {
                            internalType: "bytes32",
                            name: "appData",
                            type: "bytes32"
                        }, {
                            internalType: "uint256",
                            name: "feeAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint32",
                            name: "validTo",
                            type: "uint32"
                        }, {
                            internalType: "bool",
                            name: "partiallyFillable",
                            type: "bool"
                        }, {
                            internalType: "int64",
                            name: "quoteId",
                            type: "int64"
                        }],
                        internalType: "struct EthFlowOrder.Data",
                        name: "order",
                        type: "tuple"
                    }],
                    name: "createOrder",
                    outputs: [{
                        internalType: "bytes32",
                        name: "orderHash",
                        type: "bytes32"
                    }],
                    stateMutability: "payable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "contract IERC20",
                            name: "buyToken",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "receiver",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "sellAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "buyAmount",
                            type: "uint256"
                        }, {
                            internalType: "bytes32",
                            name: "appData",
                            type: "bytes32"
                        }, {
                            internalType: "uint256",
                            name: "feeAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint32",
                            name: "validTo",
                            type: "uint32"
                        }, {
                            internalType: "bool",
                            name: "partiallyFillable",
                            type: "bool"
                        }, {
                            internalType: "int64",
                            name: "quoteId",
                            type: "int64"
                        }],
                        internalType: "struct EthFlowOrder.Data",
                        name: "order",
                        type: "tuple"
                    }],
                    name: "invalidateOrder",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "contract IERC20",
                            name: "buyToken",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "receiver",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "sellAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "buyAmount",
                            type: "uint256"
                        }, {
                            internalType: "bytes32",
                            name: "appData",
                            type: "bytes32"
                        }, {
                            internalType: "uint256",
                            name: "feeAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint32",
                            name: "validTo",
                            type: "uint32"
                        }, {
                            internalType: "bool",
                            name: "partiallyFillable",
                            type: "bool"
                        }, {
                            internalType: "int64",
                            name: "quoteId",
                            type: "int64"
                        }],
                        internalType: "struct EthFlowOrder.Data[]",
                        name: "orderArray",
                        type: "tuple[]"
                    }],
                    name: "invalidateOrdersIgnoringNotAllowed",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "bytes32",
                        name: "orderHash",
                        type: "bytes32"
                    }, {
                        internalType: "bytes",
                        name: "",
                        type: "bytes"
                    }],
                    name: "isValidSignature",
                    outputs: [{
                        internalType: "bytes4",
                        name: "",
                        type: "bytes4"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "bytes32",
                        name: "",
                        type: "bytes32"
                    }],
                    name: "orders",
                    outputs: [{
                        internalType: "address",
                        name: "owner",
                        type: "address"
                    }, {
                        internalType: "uint32",
                        name: "validTo",
                        type: "uint32"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "unwrap",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "wrap",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    name: "wrapAll",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    name: "wrappedNativeToken",
                    outputs: [{
                        internalType: "contract IWrappedNativeToken",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    stateMutability: "payable",
                    type: "receive"
                }],
                ae = {
                    ethereum: "https://api.cow.fi/mainnet",
                    gnosis: "https://api.cow.fi/xdai"
                },
                re = {
                    ethereum: "0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2",
                    gnosis: "0xe91D153E0b41518A2Ce8Dd3D7944Fa863463a97d"
                },
                oe = {
                    ethereum: "0x40A50cf069e992AA4536211B23F286eF88752187",
                    gnosis: "0x40A50cf069e992AA4536211B23F286eF88752187"
                },
                ie = "CowSwap",
                ue = "COW",
                se = !0,
                pe = !0;

            function ce() {
                return "0xC92E8bdf79f0507f65a392b0ab4667716BFE0110"
            }
            var de = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE",
                le = function(e, t, n) {
                    return function() {
                        var a = (0, m.Z)((function(a) {
                            var r, o;
                            return (0, b.__generator)(this, (function(i) {
                                return r = 0, o = new q.CH("0x9008D19f58AAbD9eD0D60971565AA8510560ab41", ee.Mt, t), t.on(o.filters.Trade(n), (function(t) {
                                    t.data.includes(e.substring(2)) && 0 === r && (a(), r++)
                                })), [2]
                            }))
                        }));
                        return function(e) {
                            return a.apply(this, arguments)
                        }
                    }()
                };

            function me(e, t, n, a, r) {
                return ye.apply(this, arguments)
            }

            function ye() {
                return (ye = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d, l;
                    return (0, b.__generator)(this, (function(m) {
                        switch (m.label) {
                            case 0:
                                if (i = t === v.d, u = n === v.d ? de : n, s = i ? re[e] : t, p = r.amountOut && "0" !== r.amountOut, i && p) throw new Error("buy orders from Ether are not allowed");
                                return [4, fetch("".concat(ae[e], "/api/v1/quote"), {
                                    method: "POST",
                                    body: JSON.stringify((0, y.Z)({
                                        sellToken: s,
                                        buyToken: u,
                                        receiver: r.userAddress,
                                        appData: "0xf249b3db926aa5b5a1b18f3fec86b9cc99b9a8a99ad7e8034242d2838ae97422",
                                        partiallyFillable: !1,
                                        sellTokenBalance: "erc20",
                                        buyTokenBalance: "erc20",
                                        from: r.userAddress,
                                        signingScheme: i ? "eip1271" : "eip712",
                                        onchainOrder: !!i,
                                        kind: p ? "buy" : "sell"
                                    }, p ? {
                                        buyAmountAfterFee: r.amountOut
                                    } : {
                                        sellAmountBeforeFee: a
                                    })),
                                    headers: {
                                        "Content-Type": "application/json"
                                    }
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                if (0 === (c = m.sent()).quote.sellAmount && 0 === c.quote.buyAmount && !1 === c.quote.partiallyFillable) throw new Error("Buggy quote from cowswap");
                                return d = c.quote.buyAmount, l = (0, h.Z)(null === c || void 0 === c ? void 0 : c.quote.sellAmount).plus(c.quote.feeAmount).toFixed(0), p ? c.quote.sellAmount = (0, h.Z)(c.quote.sellAmount).times(1 + Number(r.slippage) / 100).toFixed(0) : c.quote.buyAmount = (0, h.Z)(d).times(1 - Number(r.slippage) / 100).toFixed(0), [2, {
                                    amountReturned: d,
                                    amountIn: l || "0",
                                    estimatedGas: i ? 56360 : 0,
                                    validTo: (null === (o = c.quote) || void 0 === o ? void 0 : o.validTo) || 0,
                                    rawQuote: (0, f.Z)((0, y.Z)({}, c), {
                                        slippage: r.slippage
                                    }),
                                    tokenApprovalAddress: "0xC92E8bdf79f0507f65a392b0ab4667716BFE0110",
                                    logo: "https://assets.coingecko.com/coins/images/24384/small/cow.png?1660960589",
                                    isMEVSafe: !0
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function fe(e) {
                return be.apply(this, arguments)
            }

            function be() {
                return (be = (0, m.Z)((function(e) {
                    var t, n, a, r, o, i, u, s, p, c, d;
                    return (0, b.__generator)(this, (function(l) {
                        switch (l.label) {
                            case 0:
                                return t = e.chain, n = e.signer, a = e.rawQuote, r = e.from, o = e.to, [4, n.getAddress()];
                            case 1:
                                if (i = l.sent(), r !== v.d) return [3, 3];
                                if (u = new q.CH(oe[t], ne, n), a.slippage < 2) throw {
                                    reason: "Slippage for ETH orders on CowSwap needs to be higher than 2%"
                                };
                                return [4, u.createOrder([o, i, a.quote.sellAmount, a.quote.buyAmount, a.quote.appData, a.quote.feeAmount, a.quote.validTo, a.quote.partiallyFillable, a.id], {
                                    value: (0, h.Z)(a.quote.sellAmount).plus(a.quote.feeAmount).toFixed(0)
                                })];
                            case 2:
                                return [2, l.sent()];
                            case 3:
                                return s = {
                                    sellToken: a.quote.sellToken,
                                    buyToken: a.quote.buyToken,
                                    sellAmount: a.quote.sellAmount,
                                    buyAmount: a.quote.buyAmount,
                                    validTo: a.quote.validTo,
                                    appData: a.quote.appData,
                                    receiver: i,
                                    feeAmount: a.quote.feeAmount,
                                    kind: a.quote.kind,
                                    partiallyFillable: a.quote.partiallyFillable
                                }, [4, (0, J.GP)((0, J.nw)(T.zk[t], "0x9008D19f58AAbD9eD0D60971565AA8510560ab41"), s, n, J.E6.EIP712)];
                            case 4:
                                return p = l.sent(), c = te.joinSignature(p.data), [4, fetch("".concat(ae[t], "/api/v1/orders"), {
                                    method: "POST",
                                    body: JSON.stringify((0, f.Z)((0, y.Z)({}, a.quote), {
                                        signature: c,
                                        signingScheme: "eip712"
                                    })),
                                    headers: {
                                        "Content-Type": "application/json"
                                    }
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 5:
                                if ((d = l.sent()).errorType) throw {
                                    reason: d.description
                                };
                                return [2, {
                                    id: d,
                                    waitForOrder: le(d, n.provider, i)
                                }];
                            case 6:
                                return [2]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var he = function() {
                    return ""
                },
                ve = function() {
                    return {}
                },
                Te = {
                    ethereum: T.zk.ethereum,
                    bsc: T.zk.bsc,
                    polygon: T.zk.polygon,
                    optimism: T.zk.optimism,
                    arbitrum: T.zk.arbitrum,
                    avax: T.zk.avax,
                    fantom: T.zk.fantom,
                    cronos: T.zk.cronos,
                    canto: T.zk.canto,
                    base: T.zk.base
                },
                ge = {
                    ethereum: "0xe0C38b2a8D09aAD53f1C67734B9A95E43d5981c0",
                    bsc: "0x92e4F29Be975C1B1eB72E77De24Dccf11432a5bd",
                    polygon: "0xb31D1B1eA48cE4Bf10ed697d44B747287E785Ad4",
                    optimism: "0x0c6134Abc08A1EafC3E2Dc9A5AD023Bb08Da86C3",
                    arbitrum: "0x0c6134Abc08A1EafC3E2Dc9A5AD023Bb08Da86C3",
                    avax: "0xe0C38b2a8D09aAD53f1C67734B9A95E43d5981c0",
                    fantom: "0xe0C38b2a8D09aAD53f1C67734B9A95E43d5981c0",
                    cronos: "0x4A5a7331dA84d3834C030a9b8d4f3d687A3b788b",
                    canto: "0x984742Be1901fcbed70d7B5847bee5BE006d91C8",
                    base: "0x20f0b18BDDe8e3dd0e42C173062eBdd05C421151"
                },
                Ae = "Firebird",
                we = "HOPE";

            function xe(e) {
                return ge[e]
            }
            var ke = "https://router.firebird.finance/aggregator/v2",
                Ee = {
                    "content-type": "application/json",
                    "api-key": "firebird_defillama"
                },
                _e = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";

            function De(e, t, n, a, r) {
                return Fe.apply(this, arguments)
            }

            function Fe() {
                return (Fe = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d, l, m;
                    return (0, b.__generator)(this, (function(b) {
                        switch (b.label) {
                            case 0:
                                return o = t === v.d, i = o ? _e : t, u = n === v.d ? _e : n, s = r.userAddress || T.O0, [4, fetch("".concat(ke, "/quote?chainId=").concat(Te[e], "&from=").concat(i, "&to=").concat(u, "&amount=").concat(a, "&receiver=").concat(s, "&slippage=").concat(+r.slippage / 100, "&source=defillama&ref=").concat(T.O0), {
                                    headers: Ee
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                return p = b.sent(), c = p.quoteData, [4, fetch("".concat(ke, "/encode"), {
                                    method: "POST",
                                    headers: Ee,
                                    body: JSON.stringify(p)
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 2:
                                d = b.sent().encodedData, m = o ? a : void 0, b.label = 3;
                            case 3:
                                return b.trys.push([3, 5, , 6]), [4, M.a[e].estimateGas({
                                    to: d.router,
                                    data: d.data,
                                    value: m
                                })];
                            case 4:
                                return l = b.sent().toFixed(0, 1), [3, 6];
                            case 5:
                                return b.sent(), l = c.maxReturn.totalGas, [3, 6];
                            case 6:
                                return l ? ("optimism" === e && (l = (0, h.Z)(3.5).times(l).toFixed(0, 1)), "arbitrum" !== e ? [3, 8] : [4, Q(d.router, d.data, l)]) : [3, 8];
                            case 7:
                                l = b.sent(), b.label = 8;
                            case 8:
                                return [2, {
                                    amountReturned: c.maxReturn.totalTo,
                                    estimatedGas: l,
                                    tokenApprovalAddress: d.router,
                                    rawQuote: (0, f.Z)((0, y.Z)({}, c), {
                                        tx: (0, f.Z)((0, y.Z)({}, d), {
                                            from: s,
                                            value: m,
                                            gasLimit: l
                                        })
                                    }),
                                    logo: "https://assets.coingecko.com/markets/images/730/small/firebird-finance.png?1636117048"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function Ce(e) {
                return Oe.apply(this, arguments)
            }

            function Oe() {
                return (Oe = (0, m.Z)((function(e) {
                    var t, n, a;
                    return (0, b.__generator)(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, [4, (0, g.p)(t, a, (0, y.Z)({
                                    from: n.tx.from,
                                    to: n.tx.router,
                                    data: n.tx.data,
                                    value: n.tx.value
                                }, "optimism" === a && {
                                    gasLimit: n.gasLimit
                                }))];
                            case 1:
                                return [2, r.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var Be = function(e) {
                    var t, n = e.rawQuote;
                    return null === n || void 0 === n || null === (t = n.tx) || void 0 === t ? void 0 : t.data
                },
                Ze = function(e) {
                    var t, n = e.rawQuote;
                    return (0, f.Z)((0, y.Z)({}, null === n || void 0 === n ? void 0 : n.tx), {
                        to: null === n || void 0 === n || null === (t = n.tx) || void 0 === t ? void 0 : t.router
                    })
                },
                Se = {
                    ethereum: "ethereum",
                    bsc: "bsc",
                    polygon: "polygon",
                    optimism: "optimism",
                    arbitrum: "arbitrum",
                    avax: "avalanche",
                    fantom: "fantom",
                    aurora: "aurora",
                    bttc: "bttc",
                    cronos: "cronos",
                    oasis: "oasis",
                    velas: "velas"
                },
                Ie = "KyberSwap",
                qe = "KNC";

            function Me() {
                return "0x00555513Acf282B42882420E5e5bA87b44D8fA6E"
            }
            var Qe = "0xeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee";

            function Re(e, t, n, a, r) {
                return Le.apply(this, arguments)
            }

            function Le() {
                return (Le = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s;
                    return (0, b.__generator)(this, (function(p) {
                        switch (p.label) {
                            case 0:
                                return o = t === v.d ? Qe : t, i = n === v.d ? Qe : n, [4, fetch("https://aggregator-api.kyberswap.com/".concat(Se[e], "/route/encode?tokenIn=").concat(o, "&tokenOut=").concat(i, "&amountIn=").concat(a, "&to=").concat(r.userAddress, "&saveGas=0&gasInclude=1&slippageTolerance=").concat(100 * +r.slippage, '&clientData={"source":"DefiLlama"}'), {
                                    headers: {
                                        "Accept-Version": "Latest"
                                    }
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                return u = p.sent(), s = u.totalGas, "optimism" === e && (s = (0, h.Z)(3.5).times(s).toFixed(0, 1)), "arbitrum" !== e ? [3, 3] : [4, Q(u.routerAddress, u.encodedSwapData, s)];
                            case 2:
                                s = p.sent(), p.label = 3;
                            case 3:
                                return [2, {
                                    amountReturned: u.outputAmount,
                                    estimatedGas: s,
                                    tokenApprovalAddress: u.routerAddress,
                                    rawQuote: (0, f.Z)((0, y.Z)({}, u), {
                                        gasLimit: s,
                                        slippage: r.slippage
                                    }),
                                    logo: "https://assets.coingecko.com/coins/images/14899/small/RwdVsGcw_400x400.jpg?1618923851"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function Pe(e) {
                return Ne.apply(this, arguments)
            }

            function Ne() {
                return (Ne = (0, m.Z)((function(e) {
                    var t, n, a, r, o, i;
                    return (0, b.__generator)(this, (function(u) {
                        switch (u.label) {
                            case 0:
                                if (t = e.signer, n = e.from, a = e.rawQuote, r = e.chain, a.slippage < .01) throw {
                                    reason: "Kyberswap doesn't support slippage below 0.01%"
                                };
                                return [4, t.getAddress()];
                            case 1:
                                return o = u.sent(), i = (0, y.Z)({
                                    from: o,
                                    to: a.routerAddress,
                                    data: a.encodedSwapData
                                }, "optimism" === r && {
                                    gasLimit: a.gasLimit
                                }), n === v.d && (i.value = a.inputAmount), [4, (0, g.p)(t, r, i)];
                            case 2:
                                return [2, u.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var je = function(e) {
                    var t = e.rawQuote;
                    return null === t || void 0 === t ? void 0 : t.encodedSwapData
                },
                Ge = function(e) {
                    var t = e.rawQuote;
                    return {
                        to: t.routerAddress,
                        data: t.encodedSwapData
                    }
                },
                ze = [{
                    inputs: [{
                        components: [{
                            internalType: "address",
                            name: "pool",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "externalAccount",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "trader",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "effectiveTrader",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "baseToken",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "quoteToken",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "effectiveBaseTokenAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "maxBaseTokenAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "maxQuoteTokenAmount",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "quoteExpiry",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "nonce",
                            type: "uint256"
                        }, {
                            internalType: "bytes32",
                            name: "txid",
                            type: "bytes32"
                        }, {
                            internalType: "bytes",
                            name: "signature",
                            type: "bytes"
                        }],
                        internalType: "struct IQuote.RFQTQuote",
                        name: "quote",
                        type: "tuple"
                    }],
                    name: "tradeSingleHop",
                    outputs: [],
                    stateMutability: "payable",
                    type: "function"
                }],
                He = n(83454),
                Xe = {
                    ethereum: 1
                },
                Ye = "Hashflow",
                Ve = "HFT",
                Ue = !0,
                Ke = {
                    1: "0xF6a94dfD0E6ea9ddFdFfE4762Ad4236576136613",
                    10: "0xb3999F658C0391d94A37f7FF328F3feC942BcADC",
                    56: "0x0ACFFB0fb2cddd9BD35d03d359F3D899E32FACc9",
                    137: "0x72550597dc0b2e0beC24e116ADd353599Eff2E35",
                    42161: "0x1F772fA3Bc263160ea09bB16CE1A6B8Fc0Fab36a",
                    43114: "0x64D2f9F44FE26C157d552aE7EAa613Ca6587B59e"
                };

            function We(e, t, n, a, r) {
                return $e.apply(this, arguments)
            }

            function $e() {
                return ($e = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d, l, m, T;
                    return (0, b.__generator)(this, (function(b) {
                        switch (b.label) {
                            case 0:
                                return u = r.amountOut && "0" !== r.amountOut ? {
                                    quoteTokenAmount: r.amountOut
                                } : {
                                    baseTokenAmount: a
                                }, [4, fetch("https://api.hashflow.com/taker/v2/rfq", {
                                    method: "POST",
                                    body: JSON.stringify((0, y.Z)({
                                        networkId: Xe[e],
                                        source: "defillama",
                                        rfqType: 0,
                                        baseToken: t,
                                        quoteToken: n,
                                        trader: r.userAddress
                                    }, u)),
                                    headers: {
                                        "Content-Type": "application/json",
                                        Authorization: He.env.HASHFLOW_API_KEY
                                    }
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                return s = b.sent(), p = "optimism" === e ? (0, h.Z)(3.5).times(s.gasEstimate).toFixed(0, 1) : s.gasEstimate, [4, (c = new q.CH(Ke[Xe[e]], ze, M.a[e])).populateTransaction.tradeSingleHop([s.quoteData.pool, null !== (d = s.quoteData.eoa) && void 0 !== d ? d : "0x0000000000000000000000000000000000000000", s.quoteData.trader, null !== (l = s.quoteData.effectiveTrader) && void 0 !== l ? l : s.quoteData.trader, s.quoteData.baseToken, s.quoteData.quoteToken, s.quoteData.baseTokenAmount, s.quoteData.baseTokenAmount, s.quoteData.quoteTokenAmount, s.quoteData.quoteExpiry, s.quoteData.nonce, s.quoteData.txid, s.signature])];
                            case 2:
                                return m = b.sent(), T = p, "arbitrum" !== e ? [3, 4] : [4, Q(c.address, m.data, p)];
                            case 3:
                                T = b.sent(), b.label = 4;
                            case 4:
                                if (s.quoteData.quoteExpiry - Date.now() / 1e3 < 40) throw new Error("Expiry is too close");
                                return [2, {
                                    amountReturned: (null === s || void 0 === s || null === (o = s.quoteData) || void 0 === o ? void 0 : o.quoteTokenAmount) || 0,
                                    amountIn: (null === s || void 0 === s || null === (i = s.quoteData) || void 0 === i ? void 0 : i.baseTokenAmount) || 0,
                                    estimatedGas: T,
                                    tokenApprovalAddress: Ke[Xe[e]],
                                    validTo: s.quoteData.quoteExpiry,
                                    rawQuote: (0, f.Z)((0, y.Z)({}, s), {
                                        gasLimit: T,
                                        tx: (0, y.Z)({}, m, t === v.d ? {
                                            value: s.quoteData.baseTokenAmount
                                        } : {})
                                    }),
                                    isMEVSafe: !0
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function Je(e) {
                return et.apply(this, arguments)
            }

            function et() {
                return (et = (0, m.Z)((function(e) {
                    var t, n, a;
                    return (0, b.__generator)(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, [4, (0, g.p)(t, a, (0, y.Z)({}, n.tx, "optimism" === a && {
                                    gasLimit: n.tx.gasLimit
                                }))];
                            case 1:
                                return [2, r.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var tt = function(e) {
                    var t, n = e.rawQuote;
                    return null === n || void 0 === n || null === (t = n.tx) || void 0 === t ? void 0 : t.data
                },
                nt = function(e) {
                    return e.rawQuote.tx
                },
                at = {
                    ethereum: 1,
                    bsc: 56,
                    polygon: 137,
                    optimism: 10,
                    arbitrum: 42161,
                    gnosis: 100,
                    avax: 43114,
                    fantom: 250,
                    aurora: 1313161554,
                    heco: 128,
                    boba: 288,
                    okexchain: 66,
                    cronos: 25,
                    moonriver: 1285,
                    polygonzkevm: 1101,
                    kava: 2222,
                    metis: 1088
                },
                rt = "OpenOcean",
                ot = "OOE";

            function it() {
                return "0x6352a56caadc4f1e25cd6c75970fa768a3304e64"
            }

            function ut(e, t, n, a, r) {
                return st.apply(this, arguments)
            }

            function st() {
                return (st = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d;
                    return (0, b.__generator)(this, (function(l) {
                        switch (l.label) {
                            case 0:
                                return o = r.slippage, i = r.userAddress, [4, fetch("https://ethapi.openocean.finance/v2/".concat(at[e], "/gas-price")).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                return s = l.sent(), [4, fetch("https://ethapi.openocean.finance/v2/".concat(at[e], "/swap?inTokenAddress=").concat(t, "&outTokenAddress=").concat(n, "&amount=").concat(a, "&gasPrice=").concat(null !== (p = null === (u = s.fast) || void 0 === u ? void 0 : u.maxFeePerGas) && void 0 !== p ? p : s.fast, "&slippage=").concat(100 * +o, "&account=").concat(i || v.d, "&referrer=0x5521c3dfd563d48ca64e132324024470f3498526")).then((function(e) {
                                    return e.json()
                                }))];
                            case 2:
                                return c = l.sent(), d = c.estimatedGas, "optimism" === e && (d = (0, h.Z)(3.5).times(d).toFixed(0, 1)), "arbitrum" !== e ? [3, 4] : [4, Q(c.to, c.data, d)];
                            case 3:
                                d = l.sent(), l.label = 4;
                            case 4:
                                return [2, {
                                    amountReturned: c.outAmount,
                                    estimatedGas: d,
                                    tokenApprovalAddress: "0x6352a56caadc4f1e25cd6c75970fa768a3304e64",
                                    rawQuote: (0, f.Z)((0, y.Z)({}, c), {
                                        gasLimit: d
                                    }),
                                    logo: "https://assets.coingecko.com/coins/images/17014/small/ooe_log.png?1626074195"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function pt(e) {
                return ct.apply(this, arguments)
            }

            function ct() {
                return (ct = (0, m.Z)((function(e) {
                    var t, n, a;
                    return (0, b.__generator)(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, [4, (0, g.p)(t, a, (0, y.Z)({
                                    from: n.from,
                                    to: n.to,
                                    data: n.data,
                                    value: n.value
                                }, "optimism" === a && {
                                    gasLimit: n.gasLimit
                                }))];
                            case 1:
                                return [2, r.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var dt = function(e) {
                    var t = e.rawQuote;
                    return null === t || void 0 === t ? void 0 : t.data
                },
                lt = function(e) {
                    var t = e.rawQuote;
                    return {
                        from: t.from,
                        to: t.to,
                        data: t.data,
                        value: t.value
                    }
                },
                mt = {
                    ethereum: 1,
                    bsc: 56,
                    polygon: 137,
                    avax: 43114,
                    arbitrum: 42161,
                    fantom: 250,
                    optimism: 10
                },
                yt = "ParaSwap",
                ft = "PSP",
                bt = "llamaswap",
                ht = !0;

            function vt() {
                return "0x216b4b4ba9f3e719726886d34a177484278bfcae"
            }
            var Tt = "0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE";

            function gt(e, t, n, a, r) {
                return At.apply(this, arguments)
            }

            function At() {
                return (At = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d, l, m, g, A, w, x;
                    return (0, b.__generator)(this, (function(b) {
                        switch (b.label) {
                            case 0:
                                return o = r.fromToken, i = r.toToken, u = r.userAddress, s = r.slippage, p = r.amountOut, c = t === v.d ? Tt : t, d = n === v.d ? Tt : n, m = "BUY" === (l = p && "0" !== p ? "BUY" : "SELL") ? p : a, [4, fetch("https://apiv5.paraswap.io/prices/?srcToken=".concat(c, "&destToken=").concat(d, "&amount=").concat(m, "&srcDecimals=").concat(null === o || void 0 === o ? void 0 : o.decimals, "&destDecimals=").concat(null === i || void 0 === i ? void 0 : i.decimals, "&partner=").concat(bt, "&side=").concat(l, "&network=").concat(mt[e], "&excludeDEXS=ParaSwapPool,ParaSwapLimitOrders")).then((function(e) {
                                    return e.json()
                                }))];
                            case 1:
                                return g = b.sent(), u === v.d ? [3, 3] : [4, fetch("https://apiv5.paraswap.io/transactions/".concat(mt[e], "?ignoreChecks=true"), {
                                    method: "POST",
                                    body: JSON.stringify((0, y.Z)({
                                        srcToken: g.priceRoute.srcToken,
                                        srcDecimals: g.priceRoute.srcDecimals,
                                        destToken: g.priceRoute.destToken,
                                        destDecimals: g.priceRoute.destDecimals,
                                        slippage: 100 * s,
                                        userAddress: u,
                                        partner: bt,
                                        partnerAddress: T.O0,
                                        positiveSlippageToUser: !1,
                                        priceRoute: g.priceRoute
                                    }, "BUY" === l ? {
                                        destAmount: g.priceRoute.destAmount
                                    } : {
                                        srcAmount: g.priceRoute.srcAmount
                                    })),
                                    headers: {
                                        "Content-Type": "application/json"
                                    }
                                }).then((function(e) {
                                    return e.json()
                                }))];
                            case 2:
                                return w = b.sent(), [3, 4];
                            case 3:
                                w = null, b.label = 4;
                            case 4:
                                return A = w, x = g.priceRoute.gasCost, "optimism" === e && (x = (0, h.Z)(3.5).times(x).toFixed(0, 1)), "arbitrum" !== e ? [3, 6] : [4, Q(A.to, A.data, x)];
                            case 5:
                                x = b.sent(), b.label = 6;
                            case 6:
                                return [2, {
                                    amountReturned: g.priceRoute.destAmount,
                                    amountIn: g.priceRoute.srcAmount || 0,
                                    estimatedGas: x,
                                    tokenApprovalAddress: g.priceRoute.tokenTransferProxy,
                                    rawQuote: (0, f.Z)((0, y.Z)({}, A), {
                                        gasLimit: x
                                    }),
                                    logo: "https://assets.coingecko.com/coins/images/20403/small/ep7GqM19_400x400.jpg?1636979120"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function wt(e) {
                return xt.apply(this, arguments)
            }

            function xt() {
                return (xt = (0, m.Z)((function(e) {
                    var t, n, a;
                    return (0, b.__generator)(this, (function(r) {
                        switch (r.label) {
                            case 0:
                                return t = e.signer, n = e.rawQuote, a = e.chain, [4, (0, g.p)(t, a, (0, y.Z)({
                                    from: n.from,
                                    to: n.to,
                                    data: n.data,
                                    value: n.value
                                }, "optimism" === a && {
                                    gasLimit: n.gasLimit
                                }))];
                            case 1:
                                return [2, r.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var kt = function(e) {
                    var t = e.rawQuote;
                    return null === t || void 0 === t ? void 0 : t.data
                },
                Et = function(e) {
                    var t = e.rawQuote;
                    return {
                        from: t.from,
                        to: t.to,
                        data: t.data,
                        value: t.value
                    }
                },
                _t = n(2593),
                Dt = [{
                    inputs: [{
                        internalType: "address[]",
                        name: "_adapters",
                        type: "address[]"
                    }, {
                        internalType: "address[]",
                        name: "_trustedTokens",
                        type: "address[]"
                    }, {
                        internalType: "address",
                        name: "_feeClaimer",
                        type: "address"
                    }],
                    stateMutability: "nonpayable",
                    type: "constructor"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "previousOwner",
                        type: "address"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "newOwner",
                        type: "address"
                    }],
                    name: "OwnershipTransferred",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "_asset",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "amount",
                        type: "uint256"
                    }],
                    name: "Recovered",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "address[]",
                        name: "_newAdapters",
                        type: "address[]"
                    }],
                    name: "UpdatedAdapters",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "address",
                        name: "_oldFeeClaimer",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "address",
                        name: "_newFeeClaimer",
                        type: "address"
                    }],
                    name: "UpdatedFeeClaimer",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "uint256",
                        name: "_oldMinFee",
                        type: "uint256"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "_newMinFee",
                        type: "uint256"
                    }],
                    name: "UpdatedMinFee",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !1,
                        internalType: "address[]",
                        name: "_newTrustedTokens",
                        type: "address[]"
                    }],
                    name: "UpdatedTrustedTokens",
                    type: "event"
                }, {
                    anonymous: !1,
                    inputs: [{
                        indexed: !0,
                        internalType: "address",
                        name: "_tokenIn",
                        type: "address"
                    }, {
                        indexed: !0,
                        internalType: "address",
                        name: "_tokenOut",
                        type: "address"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "_amountIn",
                        type: "uint256"
                    }, {
                        indexed: !1,
                        internalType: "uint256",
                        name: "_amountOut",
                        type: "uint256"
                    }],
                    name: "YakSwap",
                    type: "event"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "ADAPTERS",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "AVAX",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "FEE_CLAIMER",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "FEE_DENOMINATOR",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "MIN_FEE",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "NAME",
                    outputs: [{
                        internalType: "string",
                        name: "",
                        type: "string"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    name: "TRUSTED_TOKENS",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "WAVAX",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "adaptersCount",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_amountIn",
                        type: "uint256"
                    }, {
                        internalType: "address",
                        name: "_tokenIn",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "_tokenOut",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_maxSteps",
                        type: "uint256"
                    }],
                    name: "findBestPath",
                    outputs: [{
                        components: [{
                            internalType: "uint256[]",
                            name: "amounts",
                            type: "uint256[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }],
                        internalType: "struct YakRouter.FormattedOffer",
                        name: "",
                        type: "tuple"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_amountIn",
                        type: "uint256"
                    }, {
                        internalType: "address",
                        name: "_tokenIn",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "_tokenOut",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_maxSteps",
                        type: "uint256"
                    }, {
                        internalType: "uint256",
                        name: "_gasPrice",
                        type: "uint256"
                    }],
                    name: "findBestPathWithGas",
                    outputs: [{
                        components: [{
                            internalType: "uint256[]",
                            name: "amounts",
                            type: "uint256[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }, {
                            internalType: "uint256",
                            name: "gasEstimate",
                            type: "uint256"
                        }],
                        internalType: "struct YakRouter.FormattedOfferWithGas",
                        name: "",
                        type: "tuple"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [],
                    name: "owner",
                    outputs: [{
                        internalType: "address",
                        name: "",
                        type: "address"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_amountIn",
                        type: "uint256"
                    }, {
                        internalType: "address",
                        name: "_tokenIn",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "_tokenOut",
                        type: "address"
                    }, {
                        internalType: "uint8",
                        name: "_index",
                        type: "uint8"
                    }],
                    name: "queryAdapter",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_amountIn",
                        type: "uint256"
                    }, {
                        internalType: "address",
                        name: "_tokenIn",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "_tokenOut",
                        type: "address"
                    }, {
                        internalType: "uint8[]",
                        name: "_options",
                        type: "uint8[]"
                    }],
                    name: "queryNoSplit",
                    outputs: [{
                        components: [{
                            internalType: "address",
                            name: "adapter",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "tokenIn",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "tokenOut",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }],
                        internalType: "struct YakRouter.Query",
                        name: "",
                        type: "tuple"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_amountIn",
                        type: "uint256"
                    }, {
                        internalType: "address",
                        name: "_tokenIn",
                        type: "address"
                    }, {
                        internalType: "address",
                        name: "_tokenOut",
                        type: "address"
                    }],
                    name: "queryNoSplit",
                    outputs: [{
                        components: [{
                            internalType: "address",
                            name: "adapter",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "tokenIn",
                            type: "address"
                        }, {
                            internalType: "address",
                            name: "tokenOut",
                            type: "address"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }],
                        internalType: "struct YakRouter.Query",
                        name: "",
                        type: "tuple"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_amount",
                        type: "uint256"
                    }],
                    name: "recoverAVAX",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "address",
                        name: "_tokenAddress",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_tokenAmount",
                        type: "uint256"
                    }],
                    name: "recoverERC20",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    name: "renounceOwnership",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "address[]",
                        name: "_adapters",
                        type: "address[]"
                    }],
                    name: "setAdapters",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "address",
                        name: "_claimer",
                        type: "address"
                    }],
                    name: "setFeeClaimer",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "uint256",
                        name: "_fee",
                        type: "uint256"
                    }],
                    name: "setMinFee",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "address[]",
                        name: "_trustedTokens",
                        type: "address[]"
                    }],
                    name: "setTrustedTokens",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "uint256",
                            name: "amountIn",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }],
                        internalType: "struct YakRouter.Trade",
                        name: "_trade",
                        type: "tuple"
                    }, {
                        internalType: "address",
                        name: "_to",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_fee",
                        type: "uint256"
                    }],
                    name: "swapNoSplit",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "uint256",
                            name: "amountIn",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }],
                        internalType: "struct YakRouter.Trade",
                        name: "_trade",
                        type: "tuple"
                    }, {
                        internalType: "address",
                        name: "_to",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_fee",
                        type: "uint256"
                    }],
                    name: "swapNoSplitFromAVAX",
                    outputs: [],
                    stateMutability: "payable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "uint256",
                            name: "amountIn",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }],
                        internalType: "struct YakRouter.Trade",
                        name: "_trade",
                        type: "tuple"
                    }, {
                        internalType: "address",
                        name: "_to",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_fee",
                        type: "uint256"
                    }],
                    name: "swapNoSplitToAVAX",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "uint256",
                            name: "amountIn",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }],
                        internalType: "struct YakRouter.Trade",
                        name: "_trade",
                        type: "tuple"
                    }, {
                        internalType: "address",
                        name: "_to",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_fee",
                        type: "uint256"
                    }, {
                        internalType: "uint256",
                        name: "_deadline",
                        type: "uint256"
                    }, {
                        internalType: "uint8",
                        name: "_v",
                        type: "uint8"
                    }, {
                        internalType: "bytes32",
                        name: "_r",
                        type: "bytes32"
                    }, {
                        internalType: "bytes32",
                        name: "_s",
                        type: "bytes32"
                    }],
                    name: "swapNoSplitToAVAXWithPermit",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        components: [{
                            internalType: "uint256",
                            name: "amountIn",
                            type: "uint256"
                        }, {
                            internalType: "uint256",
                            name: "amountOut",
                            type: "uint256"
                        }, {
                            internalType: "address[]",
                            name: "path",
                            type: "address[]"
                        }, {
                            internalType: "address[]",
                            name: "adapters",
                            type: "address[]"
                        }],
                        internalType: "struct YakRouter.Trade",
                        name: "_trade",
                        type: "tuple"
                    }, {
                        internalType: "address",
                        name: "_to",
                        type: "address"
                    }, {
                        internalType: "uint256",
                        name: "_fee",
                        type: "uint256"
                    }, {
                        internalType: "uint256",
                        name: "_deadline",
                        type: "uint256"
                    }, {
                        internalType: "uint8",
                        name: "_v",
                        type: "uint8"
                    }, {
                        internalType: "bytes32",
                        name: "_r",
                        type: "bytes32"
                    }, {
                        internalType: "bytes32",
                        name: "_s",
                        type: "bytes32"
                    }],
                    name: "swapNoSplitWithPermit",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [{
                        internalType: "address",
                        name: "newOwner",
                        type: "address"
                    }],
                    name: "transferOwnership",
                    outputs: [],
                    stateMutability: "nonpayable",
                    type: "function"
                }, {
                    inputs: [],
                    name: "trustedTokensCount",
                    outputs: [{
                        internalType: "uint256",
                        name: "",
                        type: "uint256"
                    }],
                    stateMutability: "view",
                    type: "function"
                }, {
                    stateMutability: "payable",
                    type: "receive"
                }],
                Ft = {
                    avax: "0xC4729E56b831d74bBc18797e0e17A295fA77488c",
                    canto: "0xE9A2a22c92949d52e963E43174127BEb50739dcF"
                },
                Ct = "YieldYak",
                Ot = "YAK";

            function Bt(e) {
                return Ft[e]
            }
            var Zt = {
                avax: "0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7",
                canto: "0x826551890dc65655a0aceca109ab11abdbd7a07b"
            };

            function St(e, t, n, a, r) {
                return It.apply(this, arguments)
            }

            function It() {
                return (It = (0, m.Z)((function(e, t, n, a, r) {
                    var o, i, u, s, p, c, d, l, m, y, f;
                    return (0, b.__generator)(this, (function(b) {
                        switch (b.label) {
                            case 0:
                                return i = M.a[e], u = new q.CH(Ft[e], Dt, i), s = t === v.d ? Zt[e] : t, p = n === v.d ? Zt[e] : n, d = _t.O$.from(null !== (c = null === (o = r.gasPriceData) || void 0 === o ? void 0 : o.gasPrice) && void 0 !== c ? c : "1062500000000"), [4, u.findBestPathWithGas(a, s, p, 3, d)];
                            case 1:
                                return l = b.sent(), m = l[0][l[0].length - 1], y = (0, h.Z)(m.toString()).times(1 - Number(r.slippage) / 100).toFixed(0), f = l.gasEstimate.add(21e3), [2, {
                                    amountReturned: m.toString(),
                                    estimatedGas: f.toString(),
                                    rawQuote: {
                                        offer: l,
                                        minAmountOut: y
                                    },
                                    tokenApprovalAddress: Ft[e],
                                    logo: "https://assets.coingecko.com/coins/images/17654/small/yieldyak.png?1665824438"
                                }]
                        }
                    }))
                }))).apply(this, arguments)
            }

            function qt(e) {
                return Mt.apply(this, arguments)
            }

            function Mt() {
                return (Mt = (0, m.Z)((function(e) {
                    var t, n, a, r, o, i, u, s;
                    return (0, b.__generator)(this, (function(p) {
                        switch (p.label) {
                            case 0:
                                return t = e.chain, n = e.signer, a = e.rawQuote, r = e.from, o = e.to, [4, n.getAddress()];
                            case 1:
                                return i = p.sent(), u = new q.CH(Ft[t], Dt, n).populateTransaction, [4, (r === v.d ? u.swapNoSplitFromAVAX : o === v.d ? u.swapNoSplitToAVAX : u.swapNoSplit)([a.offer[0][0], a.minAmountOut, a.offer[2], a.offer[1]], i, 0, r === v.d ? {
                                    value: a.offer[0][0]
                                } : {})];
                            case 2:
                                return s = p.sent(), [4, (0, g.p)(n, t, s)];
                            case 3:
                                return [2, p.sent()]
                        }
                    }))
                }))).apply(this, arguments)
            }
            var Qt, Rt = [a, r, o, p, d, c, i, s, n(67647), u],
                Lt = [x, j, ie, Ie, yt],
                Pt = (Qt = {}, (0, l.Z)(Qt, x, !0), (0, l.Z)(Qt, Ye, !0), (0, l.Z)(Qt, j, !0), Qt)
        },
        45002: function(e, t, n) {
            n.d(t, {
                LF: function() {
                    return y
                },
                Mk: function() {
                    return m
                },
                SV: function() {
                    return d
                }
            });
            var a = n(47568),
                r = n(14924),
                o = n(26042),
                i = n(69396),
                u = n(70655),
                s = n(47257),
                p = n(47787),
                c = n(59067),
                d = c.j$.map((function(e) {
                    return e.name
                })),
                l = c.j$.reduce((function(e, t) {
                    return (0, i.Z)((0, o.Z)({}, e), (0, r.Z)({}, t.name, t))
                }), {});

            function m() {
                var e = new Set,
                    t = !0,
                    n = !1,
                    a = void 0;
                try {
                    for (var r, o = c.j$[Symbol.iterator](); !(t = (r = o.next()).done); t = !0) {
                        var i = r.value;
                        Object.keys(i.chainToId).forEach((function(t) {
                            return e.add(t)
                        }))
                    }
                } catch (u) {
                    n = !0, a = u
                } finally {
                    try {
                        t || null == o.return || o.return()
                    } finally {
                        if (n) throw a
                    }
                }
                return s.k.map((function(t) {
                    var n;
                    return e.has(t.network) ? {
                        value: t.network,
                        label: null !== (n = p.XX[t.network]) && void 0 !== n ? n : t.name,
                        chainId: t.id,
                        logoURI: null === t || void 0 === t ? void 0 : t.iconUrl
                    } : null
                })).filter(Boolean)
            }

            function y(e) {
                return f.apply(this, arguments)
            }

            function f() {
                return (f = (0, a.Z)((function(e) {
                    var t, n, a, r, o, i, s, p, c, d, m;
                    return (0, u.__generator)(this, (function(u) {
                        switch (u.label) {
                            case 0:
                                t = e.chain, n = e.from, a = e.to, r = e.amount, o = e.signer, i = e.slippage, s = void 0 === i ? "1" : i, p = e.adapter, c = e.rawQuote, d = e.tokens, m = l[p], u.label = 1;
                            case 1:
                                return u.trys.push([1, 3, , 4]), [4, m.swap({
                                    chain: t,
                                    from: n,
                                    to: a,
                                    amount: r,
                                    signer: o,
                                    slippage: s,
                                    rawQuote: c,
                                    tokens: d
                                })];
                            case 2:
                                return [2, u.sent()];
                            case 3:
                                throw u.sent();
                            case 4:
                                return [2]
                        }
                    }))
                }))).apply(this, arguments)
            }
        },
        14481: function(e, t, n) {
            n.d(t, {
                p: function() {
                    return o
                }
            });
            var a = n(47568),
                r = n(70655);

            function o(e, t, n) {
                return i.apply(this, arguments)
            }

            function i() {
                return (i = (0, a.Z)((function(e, t, n) {
                    var a;
                    return (0, r.__generator)(this, (function(t) {
                        switch (t.label) {
                            case 0:
                                if ("0x" === n.data || "string" !== typeof n.to) throw new Error("Malformed tx");
                                return void 0 !== n.gasLimit ? [3, 2] : [4, e.estimateGas(n)];
                            case 1:
                                a = t.sent(), n.gasLimit = a.mul(14).div(10), t.label = 2;
                            case 2:
                                return [2, e.sendTransaction(n)]
                        }
                    }))
                }))).apply(this, arguments)
            }
        }
    }
]);