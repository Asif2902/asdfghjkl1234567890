self.__SSG_MANIFEST = new Set(["\u002F", "\u002Farb", "\u002Ftoken-liquidity"]);
self.__SSG_MANIFEST_CB && self.__SSG_MANIFEST_CB()