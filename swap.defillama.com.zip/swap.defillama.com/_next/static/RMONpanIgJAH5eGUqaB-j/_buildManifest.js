self.__BUILD_MANIFEST = function(s, e, t, a, c, i, b, f, n) {
    return {
        __rewrites: {
            beforeFiles: [],
            afterFiles: [],
            fallback: []
        },
        "/": [s, e, a, c, b, f, "static/chunks/7140-4a3753f3c88e03b8.js", t, i, n, "static/chunks/pages/index-963168902dac97ed.js"],
        "/_error": ["static/chunks/pages/_error-f2496e8b9fdedb89.js"],
        "/arb": [s, e, a, c, b, t, i, n, "static/chunks/pages/arb-cbb6461b9ea7c4d5.js"],
        "/testAdapters": [s, e, c, t, "static/chunks/pages/testAdapters-db2fd8f1ba6cd4c0.js"],
        "/token-liquidity": [s, e, a, f, t, i, "static/chunks/pages/token-liquidity-c69e5702456f14f0.js"],
        sortedPages: ["/", "/_app", "/_error", "/arb", "/testAdapters", "/token-liquidity"]
    }
}("static/chunks/eb61b908-acfe7959b119ac85.js", "static/chunks/7050-52ec3135b366461c.js", "static/chunks/5029-f24204b88affbd9c.js", "static/chunks/1322-fd36962a618b0d16.js", "static/chunks/2573-e738dd8652298db3.js", "static/chunks/700-b2d8b391914d3cd9.js", "static/chunks/175-41a942471b8707ff.js", "static/chunks/3838-105f01bab6a9d960.js", "static/chunks/905-200392274060ae73.js"), self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB();